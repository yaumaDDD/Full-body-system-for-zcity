if SERVER then
    hook.Add("EntityTakeDamage", "EyesAttachmentReplace", function(ent, dmginfo)
        if !IsValid(ent) || ent:GetClass() ~= "prop_ragdoll" then return end
        if !(dmginfo:IsDamageType(DMG_BULLET) || dmginfo:IsDamageType(DMG_BUCKSHOT)) then return end

        local att = ent:GetAttachment(ent:LookupAttachment("eyes"))
        if !att then return end
        local hitPos = dmginfo:GetDamagePosition()
        if hitPos:DistToSqr(att.Pos) > 50 then return end
        if !(math.random(1,2) == 1) then return end
        local side = -(hitPos - att.Pos):Dot(att.Ang:Right()) > 0 and "l" or "r"

        local stg = ent:GetNWInt("eyeee" .. string.upper(side), 0)
        if stg >= 3 then return end

        if stg == 0 then
            local m = ent:GetMaterials() or {}
            for i, mat in ipairs(m) do
                local name = string.lower(mat)
                if string.find(name, "eye") or string.find(name, "pupil") then
                    if string.find(name, "%f[%a]" .. side .. "%f[%A]") or string.find(name, "_" .. side) then
                        ent:SetSubMaterial(i - 1, "models/flesh")
                    end
                end
            end
        end

        ent:SetNWInt("eyeee" .. string.upper(side), stg + 1)
    end)
end

if CLIENT then
    local models = {}
    local laststages = {}

    local function spawneye2(rag, side, mdl)
        local att = rag:GetAttachment(rag:LookupAttachment("eyes"))
        if !att then return end

        local offset = side == "r" and Vector(-4, .25, -2) or Vector(-4, 0, -2)
        local wPos, wAng = LocalToWorld(offset, Angle(10, 0, 0), att.Pos, att.Ang)

        local prop = ents.CreateClientProp(mdl)
        if !IsValid(prop) then return end

        prop:SetPos(wPos)
        prop:SetAngles(wAng)
        prop:Spawn()

        prop:SetCollisionGroup(COLLISION_GROUP_DEBRIS)

        local phys = prop:GetPhysicsObject()
        if IsValid(phys) then
            phys:Wake()
            phys:SetVelocity(att.Ang:Forward() * math.random(25, 50) + VectorRand(-5, 5))
        end
    end

    local function glaza(rag, att, mdl, side, offset, angle)
        local stg2 = rag:GetNWInt("eyeee" .. string.upper(side), 0)
        if stg2 == 0 or stg2 >= 3 then return end

        if !IsValid(models[mdl]) then
            models[mdl] = ClientsideModel(mdl, RENDERGROUP_OPAQUE)
            if IsValid(models[mdl]) then models[mdl]:SetNoDraw(true) end
        end

        local ent = models[mdl]
        if IsValid(ent) then
            local wPos, wAng = LocalToWorld(offset, angle, att.Pos, att.Ang)
            ent:SetPos(wPos)
            ent:SetAngles(wAng)
            ent:SetupBones()
            ent:DrawModel()
        end
    end

    hook.Add("PostDrawOpaqueRenderables", "j13i4ethqqgihdva", function()
        for _, rag in ipairs(ents.FindByClass("prop_ragdoll")) do
            if !IsValid(rag) then continue end

            local att = rag:GetAttachment(rag:LookupAttachment("eyes"))
            if !att then continue end

            glaza(rag, att, "models/gore/head_eye01.mdl", "r", Vector(-4, .25, -2), Angle(10, 0, 0))
            glaza(rag, att, "models/gore/head_eye02.mdl", "l", Vector(-4, 0, -2), Angle(10, 0, 0))
        end
    end)

    hook.Add("Think", "slomaimneebnalo", function()
        for _, rag in ipairs(ents.FindByClass("prop_ragdoll")) do
            if !IsValid(rag) then continue end
            local id = rag:EntIndex()
            if id == -1 then continue end

            if !laststages[id] then laststages[id] = {r = 0, l = 0} end

            for _, side in ipairs({"r", "l"}) do
                local current = rag:GetNWInt("eyeee" .. string.upper(side), 0)
                if current >= 3 and laststages[id][side] < 3 and laststages[id][side] > 0 then
                    local mdl = side == "r" and "models/gore/head_eye01.mdl" or "models/gore/head_eye02.mdl"
                    spawneye2(rag, side, mdl)
                end
                laststages[id][side] = current
            end
        end

        for id, _ in pairs(laststages) do
            if !IsValid(Entity(id)) then laststages[id] = nil end
        end
    end)
end

//PIZDEC YA SSAT HOCHU