AddCSLuaFile()
AddCSLuaFile("autorun/client/cl_zcity_organs.lua")

hg = hg or {}
hg.organism = hg.organism or {}
hg.organism.input_list = hg.organism.input_list or {}
hg.organism.translationTbl = hg.organism.translationTbl or {}

ZCityOrgans = ZCityOrgans or {}

-- Очистка старых хуков на случай горячей перезагрузки (Lua Auto-Refresh)
hook.Remove("EntityTakeDamage", "ZCity_OrgansPlus_TraceHitboxes")
hook.Remove("EntityTakeDamage", "ZCity_OrgansPlus_RayIntersect")
hook.Remove("Think", "ZCity_OrgansPlus_PhysiologyThink")
hook.Remove("PostDrawTranslucentRenderables", "ZCity_OrgansPlus_DebugDraw")

-- Защита от краша при запросе невалидных индексов костей
do
    local ENT_META = FindMetaTable("Entity")
    if ENT_META and isfunction(ENT_META.GetBoneMatrix) and not ENT_META._zcSafeGetBoneMatrix then
        ENT_META._zcSafeGetBoneMatrix = true
        local oldGetBoneMatrix = ENT_META.GetBoneMatrix
        function ENT_META:GetBoneMatrix(boneID, ...)
            if not isnumber(boneID) or boneID < 0 then
                return nil
            end
            return oldGetBoneMatrix(self, boneID, ...)
        end
    end
end

-- Локализация названий органов
hg.organism.translationTbl["spleen"]      = "Spleen"
hg.organism.translationTbl["kidneys"]     = "Kidneys"
hg.organism.translationTbl["pancreas"]    = "Pancreas"
hg.organism.translationTbl["bladder"]     = "Bladder"
hg.organism.translationTbl["l_eye"]       = "Left eye"
hg.organism.translationTbl["r_eye"]       = "Right eye"
hg.organism.translationTbl["trachea"]     = "Trachea"
hg.organism.translationTbl["spineartery"] = "Spine artery"

local PatchedOrganTables = setmetatable({}, { __mode = "k" })

local CUSTOM_ORGAN_KEYS = {
    ["spleen"] = true,
    ["kidneys"] = true,
    ["pancreas"] = true,
    ["bladder"] = true,
    ["l_eye"] = true,
    ["r_eye"] = true
}

local function RemoveOldCustomEntries(boneList)
    if not istable(boneList) then return end
    for i = #boneList, 1, -1 do
        local entry = boneList[i]
        if istable(entry) and CUSTOM_ORGAN_KEYS[entry[1]] then
            table.remove(boneList, i)
        end
    end
end

local function ApplyAnatomicalHitboxesToTable(tbl, isFemale)
    if not istable(tbl) then return end

    for k, _ in pairs(tbl) do
        if not isstring(k) or not string.StartWith(k, "ValveBiped.") then
            tbl[k] = nil
        end
    end

    if PatchedOrganTables[tbl] then return end
    PatchedOrganTables[tbl] = true

    -- ГОЛОВА (ValveBiped.Bip01_Head1)
    if istable(tbl["ValveBiped.Bip01_Head1"]) then
        local head = tbl["ValveBiped.Bip01_Head1"]
        RemoveOldCustomEntries(head)

        local skullCount = 0
        local brainCount = 0

        for _, entry in ipairs(head) do
            if entry[1] == "skull" then
                skullCount = skullCount + 1
                if skullCount == 1 then
                    entry[3] = isFemale and Vector(4.5, 0, 0) or Vector(5.5, -1.05, 0)
                    entry[4] = Angle(0, 0, 0)
                    entry[5] = Vector(2.5, 4, 3.2)
                elseif skullCount == 2 then
                    entry[3] = isFemale and Vector(0, 3, 0) or Vector(1, 1.5, 0)
                    entry[4] = Angle(0, 0, 0)
                    entry[5] = Vector(2, 1.4, 2.5)
                end
            elseif entry[1] == "brain" then
                brainCount = brainCount + 1
                if brainCount == 1 then
                    entry[3] = isFemale and Vector(4.5, 0.45, 0) or Vector(5.5, -1.05, 0)
                    entry[4] = Angle(0, 0, 0)
                    entry[5] = isFemale and Vector(2.05, 3.85, 2.75) or Vector(2.35, 3.65, 2.75)
                elseif brainCount == 2 then
                    entry[3] = isFemale and Vector(0.7, 2.0, 0) or Vector(1.8, 0.4, 0)
                    entry[4] = Angle(0, 0, 0)
                    entry[5] = Vector(1.2, 1.45, 1.2)
                end
            elseif entry[1] == "jaw" then
                entry[3] = isFemale and Vector(0.0, -1.5, 0) or Vector(1.0, -3.0, 0)
                entry[4] = Angle(0, 0, 0)
                entry[5] = Vector(1.9, 2.9, 2.0)
            end
        end

        local eyeX = isFemale and 2.75 or 3.75
        local eyeY = isFemale and -3.85 or -5.2    
        local eyeZ = isFemale and 1.30 or 1.35
        table.insert(head, { "l_eye", nil, Vector(eyeX, eyeY,  eyeZ), Angle(0, 0, 0), Vector(0.55, 0.55, 0.6), Color(70, 200, 255) })
        table.insert(head, { "r_eye", nil, Vector(eyeX, eyeY, -eyeZ), Angle(0, 0, 0), Vector(0.55, 0.55, 0.6), Color(70, 200, 255) })
    end    

    -- ШЕЯ (ValveBiped.Bip01_Neck1)
    if istable(tbl["ValveBiped.Bip01_Neck1"]) then
        local neck = tbl["ValveBiped.Bip01_Neck1"]
        local artIdx = 0
        for _, entry in ipairs(neck) do
            if entry[1] == "trachea" then
                entry[3] = Vector(2.0, -1.85, 0)
                entry[5] = Vector(2.0, 0.5, 0.5)
            elseif entry[1] == "arteria" then
                artIdx = artIdx + 1
                local zSide = (artIdx == 1) and 1.8 or -1.8
                entry[3] = Vector(isFemale and 1.5 or 2.8, -1.5, zSide)
                entry[5] = Vector(2.3, 0.3, 0.3)
            end
        end
    end
    
    -- ГРУДНАЯ КЛЕТКА (ValveBiped.Bip01_Spine2)
    if istable(tbl["ValveBiped.Bip01_Spine2"]) then
        local spine2 = tbl["ValveBiped.Bip01_Spine2"]
        for _, entry in ipairs(spine2) do
            if entry[1] == "heart" then
                entry[3] = Vector(2.2, 3.2, 0.85)
                entry[4] = Angle(0, 0, 0)
                entry[5] = Vector(1.6, 1.5, 1.5)
            elseif entry[1] == "lungsR" then
                entry[3] = Vector(4.0, 2.9, -2.85)
                entry[5] = Vector(3.9, 2.0, 2.0)
            elseif entry[1] == "lungsL" then
                entry[3] = Vector(4.0, 2.9, 2.85)
                entry[5] = Vector(3.9, 2.0, 2.0)
            end
        end
    end

    -- БРЮШНАЯ ПОЛОСТЬ (ValveBiped.Bip01_Spine)
    if istable(tbl["ValveBiped.Bip01_Spine"]) then
        local spine = tbl["ValveBiped.Bip01_Spine"]
        RemoveOldCustomEntries(spine)

        for _, entry in ipairs(spine) do
            if entry[1] == "liver" then
                entry[3] = Vector(3.8, 3.0, -2.3)
                entry[4] = Angle(0, 0, 0)
                entry[5] = Vector(2.0, 1.9, 2.8)
            elseif entry[1] == "stomach" then
                entry[3] = Vector(3.4, 3.2, 2.0)
                entry[4] = Angle(0, 0, 0)
                entry[5] = Vector(2.1, 1.6, 2.2)
            end
        end

        table.insert(spine, { "spleen", nil, Vector(3.6, 1.2, 3.9), Angle(0, 0, 0), Vector(1.5, 1.1, 1.0), Color(160, 30, 160) })
        table.insert(spine, { "pancreas", nil, Vector(2.2, 1.3, 0.5), Angle(0, 0, 0), Vector(1.0, 0.8, 1.9), Color(255, 220, 50) })
        table.insert(spine, { "kidneys", nil, Vector(1.6, 0.3, -2.2), Angle(0, 0, 0), Vector(1.6, 0.85, 1.1), Color(180, 50, 50) })
        table.insert(spine, { "kidneys", nil, Vector(1.9, 0.3,  2.2), Angle(0, 0, 0), Vector(1.6, 0.85, 1.1), Color(180, 50, 50) })
    end

    -- ТАЗ (ValveBiped.Bip01_Pelvis)
    if istable(tbl["ValveBiped.Bip01_Pelvis"]) then
        local pelvis = tbl["ValveBiped.Bip01_Pelvis"]
        RemoveOldCustomEntries(pelvis)

        for _, entry in ipairs(pelvis) do
            if entry[1] == "intestines" then
                entry[3] = Vector(0, 2.5, 0.0)
                entry[4] = Angle(0, 0, 0)
                entry[5] = Vector(4.6, 2.6, 2.7)
            end
        end

        table.insert(pelvis, { "bladder", nil, Vector(0, -1.5, 0.8), Angle(0, 0, 0), Vector(1.7, 1.2, 1.4), Color(245, 215, 40) })
    end
end


function ZCityOrgans.PatchHitboxTables()
    if not hg or not hg.organism or not isfunction(hg.organism.GetHitBoxOrgans) then return end

    for i = 1, 10 do
        local upName, upVal = debug.getupvalue(hg.organism.GetHitBoxOrgans, i)
        if not upName then break end
        if upName == "male" and istable(upVal) then
            ApplyAnatomicalHitboxesToTable(upVal, false)
        elseif upName == "female" and istable(upVal) then
            ApplyAnatomicalHitboxesToTable(upVal, true)
        end
    end
end


-- Базовые хуки инициализации хитбоксов
hook.Add("Initialize", "ZCity_OrgansPlus_SHInit", ZCityOrgans.PatchHitboxTables)
hook.Add("PostGamemodeLoaded", "ZCity_OrgansPlus_SHPostGM", ZCityOrgans.PatchHitboxTables)
hook.Add("InitPostEntity", "ZCity_OrgansPlus_SHInitPost", ZCityOrgans.PatchHitboxTables)
hook.Add("HG_BaseHitBoxSetLoaded", "ZCity_OrgansPlus_SHHitboxLoaded", ZCityOrgans.PatchHitboxTables)