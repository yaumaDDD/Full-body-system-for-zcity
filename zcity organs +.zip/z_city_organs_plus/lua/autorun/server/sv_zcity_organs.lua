util.AddNetworkString("ZCity_OrgansPlus_Sync")

local function SyncCustomOrgans(org, targetPly)
    if not istable(org) or not IsValid(org.owner) or not org.owner:IsPlayer() then return end
    local recipient = IsValid(targetPly) and targetPly or org.owner
    net.Start("ZCity_OrgansPlus_Sync")
    net.WriteEntity(org.owner)
    net.WriteFloat(org.spleen or 0)
    net.WriteFloat(org.kidneys or 0)
    net.WriteFloat(org.pancreas or 0)
    net.WriteFloat(org.bladder or 0)
    net.WriteFloat(org.l_eye or 0)
    net.WriteFloat(org.r_eye or 0)
    net.WriteFloat(org.internalToxins or 0)
    net.Send(recipient)
end

local function EnsureAllOrganismFields(org, ownerEnt)
    if not istable(org) then return end
    if IsValid(ownerEnt) then org.owner = org.owner or ownerEnt end
    org.entindex = IsValid(org.owner) and org.owner:EntIndex() or (org.entindex or 1000001)

    if not org.blood and hg.organism and istable(hg.organism.module) then
        local m = hg.organism.module
        if m.pulse and isfunction(m.pulse[1]) then pcall(m.pulse[1], org) end
        if m.blood and isfunction(m.blood[1]) then pcall(m.blood[1], org) end
        if m.pain and isfunction(m.pain[1]) then pcall(m.pain[1], org) end
        if m.stamina and isfunction(m.stamina[1]) then pcall(m.stamina[1], org) end
        if m.lungs and isfunction(m.lungs[1]) then pcall(m.lungs[1], org) end
        if m.liver and isfunction(m.liver[1]) then pcall(m.liver[1], org) end
        if m.metabolism and isfunction(m.metabolism[1]) then pcall(m.metabolism[1], org) end
        if m.random_events and isfunction(m.random_events[1]) then pcall(m.random_events[1], org) end
    end

    org.alive          = (org.alive == nil) and true or org.alive
    org.otrub          = org.otrub or false
    org.blood          = org.blood or 5000
    org.bleed          = org.bleed or 0
    org.internalBleed  = org.internalBleed or 0
    org.pain           = org.pain or 0
    org.painadd        = org.painadd or 0
    org.avgpain        = org.avgpain or 0
    org.shock          = org.shock or 0
    org.hurt           = org.hurt or 0
    org.hurtadd        = org.hurtadd or 0
    org.stamina        = istable(org.stamina) and org.stamina or { 100, 100, max = 100, regen = 1, sub = 0, range = 100 }
    org.o2             = istable(org.o2) and org.o2 or { 30, 30, max = 30, regen = 2, curregen = 0.4, range = 30 }
    org.lungsL         = istable(org.lungsL) and org.lungsL or { 0, 0 }
    org.lungsR         = istable(org.lungsR) and org.lungsR or { 0, 0 }
    org.wounds         = istable(org.wounds) and org.wounds or {}
    org.arterialwounds = istable(org.arterialwounds) and org.arterialwounds or {}
    org.dmgstack       = istable(org.dmgstack) and org.dmgstack or {}

    org.brain          = org.brain or 0
    org.consciousness  = org.consciousness or 1
    org.disorientation = org.disorientation or 0
    org.immobilization = org.immobilization or 0
    org.adrenaline     = org.adrenaline or 0
    org.adrenalineAdd  = org.adrenalineAdd or 0
    org.analgesia      = org.analgesia or 0
    org.painkiller     = org.painkiller or 0
    org.pulse          = org.pulse or 70
    org.heartbeat      = org.heartbeat or 70
    org.temperature    = org.temperature or 36.7
    org.health         = org.health or 100
    org.canmove        = (org.canmove == nil) and true or org.canmove
    org.canmovehead    = (org.canmovehead == nil) and true or org.canmovehead
    org.recoilmul      = org.recoilmul or 1
    org.legstrength    = org.legstrength or 1
    org.meleespeed     = org.meleespeed or 1
    org.bleedingmul    = org.bleedingmul or 1
    org.stun           = org.stun or 0
    org.lightstun      = org.lightstun or 0
    org.fear           = org.fear or 0
    org.fearadd        = org.fearadd or 0
    org.assimilated    = org.assimilated or 0
    org.berserk        = org.berserk or 0
    org.noradrenaline  = org.noradrenaline or 0
    org.thiamine       = org.thiamine or 0

    org.jaw            = org.jaw or 0
    org.skull          = org.skull or 0
    org.spine1         = org.spine1 or 0
    org.spine2         = org.spine2 or 0
    org.spine3         = org.spine3 or 0
    org.chest          = org.chest or 0
    org.pelvis         = org.pelvis or 0
    org.heart          = org.heart or 0
    org.liver          = org.liver or 0
    org.stomach        = org.stomach or 0
    org.intestines     = org.intestines or 0
    org.trachea        = org.trachea or 0
    org.arteria        = org.arteria or 0
    org.spineartery    = org.spineartery or 0
    org.lleg           = org.lleg or 0
    org.rleg           = org.rleg or 0
    org.larm           = org.larm or 0
    org.rarm           = org.rarm or 0

    org.bulletwounds    = org.bulletwounds or 0
    org.stabwounds      = org.stabwounds or 0
    org.slashwounds     = org.slashwounds or 0
    org.bruises         = org.bruises or 0
    org.burns           = org.burns or 0
    org.explosionwounds = org.explosionwounds or 0

    -- Кастомные органы
    org.spleen         = org.spleen or 0
    org.kidneys        = org.kidneys or 0
    org.pancreas       = org.pancreas or 0
    org.bladder        = org.bladder or 0
    org.l_eye          = org.l_eye or 0
    org.r_eye          = org.r_eye or 0
    org.internalToxins = org.internalToxins or 0
end

local function GuaranteeEntityOrganism(ent)
    if not IsValid(ent) then return nil end
    if not istable(ent.organism) then
        if hg and hg.organism and isfunction(hg.organism.Add) then
            hg.organism.Add(ent)
        else
            ent.organism = { owner = ent }
            hg.organism.list = hg.organism.list or {}
            hg.organism.list[ent] = ent.organism
        end
        EnsureAllOrganismFields(ent.organism, ent)
        if hg and hg.organism and isfunction(hg.organism.Clear) then
            pcall(hg.organism.Clear, ent.organism)
        end
    else
        EnsureAllOrganismFields(ent.organism, ent)
    end
    return ent.organism
end

hook.Add("Org Clear", "ZCity_OrgansPlus_Clear", function(org)
    if not istable(org) then return end
    org.trachea        = 0
    org.spineartery    = 0
    org.spleen         = 0
    org.kidneys        = 0
    org.pancreas       = 0
    org.bladder        = 0
    org.l_eye          = 0
    org.r_eye          = 0
    org.internalToxins = 0

    if IsValid(org.owner) and org.owner:IsPlayer() then
        timer.Simple(0, function()
            if IsValid(org.owner) then
                SyncCustomOrgans(org, org.owner)
            end
        end)
    end
end)

local wrappedServerHooks = setmetatable({}, { __mode = "k" })

local function ApplyServerCoreFixes()
    if ZCityOrgans and ZCityOrgans.PatchHitboxTables then
        ZCityOrgans.PatchHitboxTables()
    end

    if hg.organism then
        if isfunction(hg.organism.Add) and not hg.organism._zcSafeAdd then
            hg.organism._zcSafeAdd = true
            local oldAdd = hg.organism.Add
            function hg.organism.Add(ent, ...)
                local org = oldAdd(ent, ...)
                EnsureAllOrganismFields(org, ent)
                return org
            end
        end

        if isfunction(hg.organism.Clear) and not hg.organism._zcSafeClear then
            hg.organism._zcSafeClear = true
            local oldClear = hg.organism.Clear
            function hg.organism.Clear(org, ...)
                if not istable(org) then
                    for _, ply in ipairs(player.GetAll()) do
                        if not istable(ply.organism) then
                            GuaranteeEntityOrganism(ply)
                        end
                    end
                    return
                end
                EnsureAllOrganismFields(org, org.owner)
                return oldClear(org, ...)
            end
        end

        hook.Add("PlayerInitialSpawn", "homigrad-organism", function(ply)
            GuaranteeEntityOrganism(ply)
        end)

        hook.Add("Player Spawn", "homigrad-organism", function(ply)
            local org = GuaranteeEntityOrganism(ply)
            if istable(org) and isfunction(hg.organism.Clear) then
                hg.organism.Clear(org)
            end
        end)
    end

    hook.Add("StartCommand", "hg_lol", function(ply, cmd)
        local org = ply.organism or GuaranteeEntityOrganism(ply)
        if istable(org) and org.otrub and ply:Alive() then
            cmd:ClearMovement()
        end
    end)

    local PLAYER_META = FindMetaTable("Player")
    if PLAYER_META then
        function PLAYER_META:IsBerserk()
            if not IsValid(self) then return false end
            if self:IsPlayer() and not self:Alive() then return false end
            local org = self.organism
            if not istable(org) then return false end
            return org.berserkActive2 or false
        end

        function PLAYER_META:IsStimulated()
            if not IsValid(self) then return false end
            if self:IsPlayer() and not self:Alive() then return false end
            local org = self.organism
            if not istable(org) then return false end
            return org.noradrenalineActive or false
        end
    end

    for eventName, hookList in pairs(hook.GetTable()) do
        if istable(hookList) then
            for hookName, fn in pairs(hookList) do
                if isfunction(fn) and not wrappedServerHooks[fn] then
                    local info = debug.getinfo(fn, "S")
                    if info and info.short_src and string.find(info.short_src, "abnormalty_detection/sv_plugin.lua", 1, true) then
                        local wrapper = function(...)
                            local ok, res = pcall(fn, ...)
                            if not ok then return end
                            return res
                        end
                        wrappedServerHooks[wrapper] = true
                        hookList[hookName] = wrapper
                    else
                        wrappedServerHooks[fn] = true
                    end
                end
            end
        end
    end
end

local function isCrush(dmgInfo)
    return not dmgInfo or not dmgInfo:IsDamageType(DMG_BULLET + DMG_BUCKSHOT + DMG_SLASH + DMG_BLAST)
end

local angZero, vecZero = Angle(0, 0, 0), Vector(0, 0, 0)
local function GetLocalWoundTransform(ent, bone, dir, hit)
    if IsValid(ent) and bone then
        local charEnt = IsValid(ent.FakeRagdoll) and ent.FakeRagdoll or ent
        local bonePos, boneAng = charEnt:GetBonePosition(bone)
        if not bonePos then return vecZero, angZero, Vector(1, 0, 0) end
        local dmgPos = (isvector(hit) and hit) or bonePos
        local localPos, localAng = WorldToLocal(dmgPos, angZero, bonePos, boneAng)
        local dirVec = isvector(dir) and dir or Vector(1, 0, 0)
        local _, dir2 = WorldToLocal(vecZero, dirVec:Angle(), vecZero, boneAng)
        return localPos, localAng, dir2:Forward()
    end
    return vecZero, angZero, Vector(1, 0, 0)
end

local function RegisterAllOrganHandlers()
    ApplyServerCoreFixes()

    hg.organism.input_list = hg.organism.input_list or {}
    local input_list = hg.organism.input_list

    input_list.trachea = function(org, bone, dmg, dmgInfo)
        if not istable(org) then return 0 end
        EnsureAllOrganismFields(org)

        if dmgInfo and dmgInfo:IsDamageType(DMG_BLAST) then dmg = dmg / 5 end
        local oldDmg = org.trachea
        org.trachea = math.Round(math.min(org.trachea + dmg * (isCrush(dmgInfo) and 1 or 2.5), 1), 3)

        local harmed = org.trachea - oldDmg
        if hg.AddHarmToAttacker and dmgInfo then
            hg.AddHarmToAttacker(dmgInfo, harmed * 8, "Trachea damage harm")
        end

        org.shock = (org.shock or 0) + dmg * 15
        org.painadd = (org.painadd or 0) + dmg * 25
        org.internalBleed = (org.internalBleed or 0) + harmed * 2.5

        if dmgInfo then dmgInfo:ScaleDamage(0.8) end
        return 0
    end

    input_list.spineartery = function(org, bone, dmg, dmgInfo, boneindex, dir, hit)
        if not istable(org) or not dmgInfo then return 0 end
        if isCrush(dmgInfo) or dmgInfo:IsDamageType(DMG_BLAST) then return 1 end
        if dmgInfo:IsDamageType(DMG_SLASH) and math.random(5) ~= 1 and dmg < 2 then return 0 end

        EnsureAllOrganismFields(org)
        org.painadd = (org.painadd or 0) + dmg * 2
        if org.spineartery == 1 then return 0 end

        if hg.AddHarmToAttacker then
            hg.AddHarmToAttacker(dmgInfo, 10, "Spine artery punctured harm")
        end

        org.spineartery = 1
        org.internalBleed = (org.internalBleed or 0) + 8

        local owner = org.owner
        if IsValid(owner) then
            local bName = isstring(boneindex) and boneindex or "ValveBiped.Bip01_Spine2"
            local boneID = owner:LookupBone(bName)
            if boneID then
                local localPos, localAng, dir2 = GetLocalWoundTransform(owner, boneID, dir, hit)
                table.insert(org.arterialwounds, { 10, localPos, localAng, bName, CurTime(), dir2 * 100, "spineartery" })
                owner:SetNetVar("arterialwounds", org.arterialwounds)
            end
        end
        return 0
    end

    input_list.spleen = function(org, bone, dmg, dmgInfo)
        if not istable(org) then return 0 end
        EnsureAllOrganismFields(org)

        local oldDmg = org.spleen
        local mult = isCrush(dmgInfo) and 1.5 or 2.5
        org.spleen = math.Round(math.min(org.spleen + dmg * mult, 1), 3)

        local harmed = org.spleen - oldDmg
        if hg.AddHarmToAttacker and dmgInfo then
            hg.AddHarmToAttacker(dmgInfo, harmed * 4, "Spleen damage harm")
        end

        org.shock = (org.shock or 0) + dmg * 15
        org.painadd = (org.painadd or 0) + dmg * 25
        org.internalBleed = (org.internalBleed or 0) + harmed * 6.5

        if dmgInfo then dmgInfo:ScaleDamage(0.85) end
        SyncCustomOrgans(org)
        return 0
    end

    input_list.kidneys = function(org, bone, dmg, dmgInfo)
        if not istable(org) then return 0 end
        EnsureAllOrganismFields(org)

        local oldDmg = org.kidneys
        local mult = isCrush(dmgInfo) and 1.0 or 2.2
        org.kidneys = math.Round(math.min(org.kidneys + dmg * mult, 1), 3)

        local harmed = org.kidneys - oldDmg
        if hg.AddHarmToAttacker and dmgInfo then
            hg.AddHarmToAttacker(dmgInfo, harmed * 3.5, "Kidneys damage harm")
        end

        org.shock = (org.shock or 0) + dmg * 22
        org.painadd = (org.painadd or 0) + dmg * 38
        org.disorientation = (org.disorientation or 0) + harmed * 2.0
        org.internalBleed = (org.internalBleed or 0) + harmed * 4.5

        if (org.analgesia or 0) < 0.4 and harmed >= 0.25 and IsValid(org.owner) and hg.LightStunPlayer then
            timer.Simple(0, function()
                if IsValid(org.owner) then hg.LightStunPlayer(org.owner, 2) end
            end)
        end

        if dmgInfo then dmgInfo:ScaleDamage(0.85) end
        SyncCustomOrgans(org)
        return 0
    end

    input_list.pancreas = function(org, bone, dmg, dmgInfo)
        if not istable(org) then return 0 end
        EnsureAllOrganismFields(org)

        local oldDmg = org.pancreas
        local mult = isCrush(dmgInfo) and 0.8 or 2.5
        org.pancreas = math.Round(math.min(org.pancreas + dmg * mult, 1), 3)

        local harmed = org.pancreas - oldDmg
        if hg.AddHarmToAttacker and dmgInfo then
            hg.AddHarmToAttacker(dmgInfo, harmed * 4, "Pancreas damage harm")
        end

        org.shock = (org.shock or 0) + dmg * 30
        org.painadd = (org.painadd or 0) + dmg * 50
        org.internalBleed = (org.internalBleed or 0) + harmed * 3.0

        if istable(org.stamina) and org.stamina[1] then
            org.stamina[1] = math.max(0, org.stamina[1] - harmed * 35)
        end

        if dmgInfo then dmgInfo:ScaleDamage(0.8) end
        SyncCustomOrgans(org)
        return 0
    end

    input_list.bladder = function(org, bone, dmg, dmgInfo)
        if not istable(org) then return 0 end
        EnsureAllOrganismFields(org)

        local oldDmg = org.bladder
        local mult = isCrush(dmgInfo) and 0.9 or 2.5
        org.bladder = math.Round(math.min(org.bladder + dmg * mult, 1), 3)

        local harmed = org.bladder - oldDmg
        if hg.AddHarmToAttacker and dmgInfo then
            hg.AddHarmToAttacker(dmgInfo, harmed * 2, "Bladder damage harm")
        end

        org.shock = (org.shock or 0) + dmg * 12
        org.painadd = (org.painadd or 0) + dmg * 22
        org.hurtadd = (org.hurtadd or 0) + harmed * 0.35
        org.internalBleed = (org.internalBleed or 0) + harmed * 1.5

        if dmgInfo then dmgInfo:ScaleDamage(0.85) end
        SyncCustomOrgans(org)
        return 0
    end

    local function HitEye(eyeKey, org, dmg, dmgInfo)
        if not istable(org) then return 0 end
        EnsureAllOrganismFields(org)

        local oldDmg = org[eyeKey]
        local mult = isCrush(dmgInfo) and 1.2 or 4.0
        org[eyeKey] = math.Round(math.min(org[eyeKey] + dmg * mult, 1), 3)

        local harmed = org[eyeKey] - oldDmg
        if hg.AddHarmToAttacker and dmgInfo then
            hg.AddHarmToAttacker(dmgInfo, harmed * 3, "Eye damage harm")
        end

        org.shock = (org.shock or 0) + dmg * 18
        org.painadd = (org.painadd or 0) + dmg * 32
        org.disorientation = (org.disorientation or 0) + harmed * 4.5

        if org.l_eye >= 0.85 and org.r_eye >= 0.85 then
            org.blindness = true
        end

        if dmgInfo and not isCrush(dmgInfo) then
            local bulletDmg = dmgInfo:GetDamage()
            if bulletDmg <= 22 then
                org._eyeBlockedTime = CurTime()
                dmgInfo:SetDamage(0)
            else
                dmgInfo:ScaleDamage(0.35)
            end
        end

        SyncCustomOrgans(org)
        return 0
    end

    input_list.l_eye = function(org, bone, dmg, dmgInfo) return HitEye("l_eye", org, dmg, dmgInfo) end
    input_list.r_eye = function(org, bone, dmg, dmgInfo) return HitEye("r_eye", org, dmg, dmgInfo) end

    if not input_list._zcOldBrain then
        input_list._zcOldBrain = input_list.brain
        input_list.brain = function(org, bone, dmg, dmgInfo, ...)
            if istable(org) and org._eyeBlockedTime == CurTime() then
                org.disorientation = (org.disorientation or 0) + 1.5
                return 0
            end

            if isfunction(input_list._zcOldBrain) then
                return input_list._zcOldBrain(org, bone, dmg, dmgInfo, ...)
            end
            return 0
        end
    end
end

RegisterAllOrganHandlers()
hook.Add("Initialize", "ZCity_OrgansPlus_SVInit", RegisterAllOrganHandlers)
hook.Add("PostGamemodeLoaded", "ZCity_OrgansPlus_SVPostGM", RegisterAllOrganHandlers)
hook.Add("InitPostEntity", "ZCity_OrgansPlus_SVInitPost", RegisterAllOrganHandlers)
hook.Add("HG_BaseHitBoxSetLoaded", "ZCity_OrgansPlus_SVHitboxLoaded", RegisterAllOrganHandlers)

hook.Add("OnEntityCreated", "ZCity_OrgansPlus_InstantOrg", function(ent)
    RegisterAllOrganHandlers()
    if IsValid(ent) and ent:IsPlayer() then
        GuaranteeEntityOrganism(ent)
    end
end)

hook.Add("PlayerInitialSpawn", "ZCity_OrgansPlus_GuaranteeInit", function(ply)
    RegisterAllOrganHandlers()
    GuaranteeEntityOrganism(ply)
end)

hook.Add("PlayerSpawn", "ZCity_OrgansPlus_GuaranteeSpawn", function(ply)
    RegisterAllOrganHandlers()
    GuaranteeEntityOrganism(ply)
end)

hook.Add("Org Think", "ZCity_OrgansPlus_Physiology", function(owner, org, timeValue)
    if not IsValid(owner) or not istable(org) then return end
    if owner:IsPlayer() and not owner:Alive() then return end
    if not org.alive then return end

    EnsureAllOrganismFields(org, owner)

    if org.trachea > 0.2 and istable(org.o2) and org.o2[1] then
        org.o2[1] = math.max(0, org.o2[1] - org.trachea * 1.2 * timeValue)
    end

    if org.spleen > 0.05 then
        org.internalBleed = (org.internalBleed or 0) + (org.spleen * 0.08 * timeValue)
        org.painadd = (org.painadd or 0) + (org.spleen * 0.35 * timeValue)
    end

    if org.kidneys > 0.05 then
        org.internalToxins = math.min(1, (org.internalToxins or 0) + org.kidneys * 0.008 * timeValue)
        org.painadd = (org.painadd or 0) + (org.kidneys * 0.55 * timeValue)
        org.hurtadd = (org.hurtadd or 0) + (org.kidneys * 0.015 * timeValue)
        if org.internalToxins > 0.4 then
            org.disorientation = math.min(10, (org.disorientation or 0) + org.internalToxins * 0.15 * timeValue)
        end
    elseif org.internalToxins > 0 then
        org.internalToxins = math.Approach(org.internalToxins, 0, timeValue * 0.01)
    end

    if org.pancreas > 0.05 then
        org.painadd = (org.pancreas * 1.15 * timeValue) + (org.painadd or 0)
        if org.painkiller and org.painkiller > 0 then
            org.painkiller = math.max(0, org.painkiller - (0.015 * org.pancreas * timeValue))
        end
    end

    if org.bladder > 0.05 then
        local ent = hg.GetCurrentCharacter and hg.GetCurrentCharacter(owner) or owner
        local moving = IsValid(ent) and ent:GetVelocity():Length2D() > 70
        local moveMul = moving and 1.8 or 0.4
        org.painadd = (org.painadd or 0) + (org.bladder * 0.45 * moveMul * timeValue)
    end

    if (org.brain or 0) < 0.4 then
        local naturalHeal = (org.thiamine or 0) > 0 and (timeValue / 480) or (timeValue / 1800)
        if org.trachea < 1  then org.trachea  = math.Approach(org.trachea, 0, naturalHeal) end
        if org.spleen < 1   then org.spleen   = math.Approach(org.spleen, 0, naturalHeal) end
        if org.kidneys < 1  then org.kidneys  = math.Approach(org.kidneys, 0, naturalHeal) end
        if org.pancreas < 1 then org.pancreas = math.Approach(org.pancreas, 0, naturalHeal) end
        if org.bladder < 1  then org.bladder  = math.Approach(org.bladder, 0, naturalHeal) end
    end

    if owner:IsPlayer() and owner:IsBerserk() then
        local regen = timeValue / 120 * (org.berserk or 1)
        org.trachea  = math.max(org.trachea - regen, 0)
        org.spleen   = math.max(org.spleen - regen, 0)
        org.kidneys  = math.max(org.kidneys - regen, 0)
        org.pancreas = math.max(org.pancreas - regen, 0)
        org.bladder  = math.max(org.bladder - regen, 0)
        org.l_eye    = math.max(org.l_eye - regen, 0)
        org.r_eye    = math.max(org.r_eye - regen, 0)
    end

    if owner:IsPlayer() then
        org._nextCustomSync = org._nextCustomSync or 0
        if CurTime() >= org._nextCustomSync then
            org._nextCustomSync = CurTime() + 1.0
            SyncCustomOrgans(org, owner)
        end
    end
end)