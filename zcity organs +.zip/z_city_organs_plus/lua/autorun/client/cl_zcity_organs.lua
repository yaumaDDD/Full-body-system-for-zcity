lply = IsValid(lply) and lply or LocalPlayer()

local wrappedClientHooks = setmetatable({}, { __mode = "k" })
local function ProtectClientHomigradHooks()
    if not IsValid(lply) then
        lply = LocalPlayer()
    end
    for eventName, hookList in pairs(hook.GetTable()) do
        if istable(hookList) then
            for hookName, fn in pairs(hookList) do
                if isfunction(fn) and not wrappedClientHooks[fn] then
                    local info = debug.getinfo(fn, "S")
                    if info and info.short_src and string.find(info.short_src, "lua/homigrad/", 1, true) then
                        local wrapper = function(...)
                            if not IsValid(lply) then
                                lply = LocalPlayer()
                                if not IsValid(lply) then return end
                            end
                            return fn(...)
                        end
                        wrappedClientHooks[wrapper] = true
                        hookList[hookName] = wrapper
                    else
                        wrappedClientHooks[fn] = true
                    end
                end
            end
        end
    end
end

local statsPatched = false
local function PatchClientStatisticsList()
    if statsPatched or not hg or not isfunction(hg.LerpVariables) then return end
    for i = 1, 5 do
        local upName, upVal = debug.getupvalue(hg.LerpVariables, i)
        if not upName then break end
        if upName == "list" and istable(upVal) then
            statsPatched = true
            local newStats = {
                { "spleen", 1, true },
                { "kidneys", 1, true },
                { "pancreas", 1, true },
                { "bladder", 1, true },
                { "l_eye", 1, true },
                { "r_eye", 1, true },
                { "internalToxins", 1, true }
            }
            for _, item in ipairs(newStats) do
                local exists = false
                for _, v in ipairs(upVal) do
                    if istable(v) and v[1] == item[1] then exists = true break end
                end
                if not exists then
                    table.insert(upVal, item)
                end
            end
            break
        end
    end
end

local function RunClientSetup()
    if not IsValid(lply) then lply = LocalPlayer() end
    if ZCityOrgans and ZCityOrgans.PatchHitboxTables then
        ZCityOrgans.PatchHitboxTables()
    end
    ProtectClientHomigradHooks()
    PatchClientStatisticsList()
end

RunClientSetup()
hook.Add("Initialize", "ZCity_OrgansPlus_CLInit", RunClientSetup)
hook.Add("InitPostEntity", "ZCity_OrgansPlus_CLInitPost", RunClientSetup)
hook.Add("OnEntityCreated", "ZCity_OrgansPlus_CLEntCreated", function(ent)
    if not IsValid(lply) then lply = LocalPlayer() end
    if ZCityOrgans and ZCityOrgans.PatchHitboxTables then
        ZCityOrgans.PatchHitboxTables()
    end
end)

local lEyeDamage = 0
local rEyeDamage = 0
local debugConVar = CreateClientConVar("zc_debug_organs", "0", false, false, "1 = показать внутренние органы, 2 = показать все хитбоксы тела")

net.Receive("ZCity_OrgansPlus_Sync", function()
    local ent      = net.ReadEntity()
    local spleen   = net.ReadFloat()
    local kidneys  = net.ReadFloat()
    local pancreas = net.ReadFloat()
    local bladder  = net.ReadFloat()
    local leye     = net.ReadFloat()
    local reye     = net.ReadFloat()
    local toxins   = net.ReadFloat()

    if ent == LocalPlayer() then
        lEyeDamage = leye
        rEyeDamage = reye
    end

    if IsValid(ent) then
        ent.organism = ent.organism or {}
        ent.organism.spleen         = spleen
        ent.organism.kidneys        = kidneys
        ent.organism.pancreas       = pancreas
        ent.organism.bladder        = bladder
        ent.organism.l_eye          = leye
        ent.organism.r_eye          = reye
        ent.organism.internalToxins = toxins

        if istable(ent.new_organism) then
            ent.new_organism.spleen         = spleen
            ent.new_organism.kidneys        = kidneys
            ent.new_organism.pancreas       = pancreas
            ent.new_organism.bladder        = bladder
            ent.new_organism.l_eye          = leye
            ent.new_organism.r_eye          = reye
            ent.new_organism.internalToxins = toxins
        end
    end
end)

local gradL = Material("vgui/gradient-l")
local gradR = Material("vgui/gradient-r")
local gradU = Material("vgui/gradient-u")
local gradD = Material("vgui/gradient-d")

local smoothL = 0
local smoothR = 0
local lastEyeDmg = 0

local function TriggerEyeTraumaShock(isLeft)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    ply:EmitSound("player/suit_denydevice.wav", 75, math.random(50, 65))

    local punchYaw = isLeft and math.Rand(6, 12) or math.Rand(-12, -6)
    local punchPitch = math.Rand(-6, 3)
    local punchRoll = isLeft and math.Rand(-8, -4) or math.Rand(4, 8)
    ply:ViewPunch(Angle(punchPitch, punchYaw, punchRoll))
end



hook.Add("RenderScreenspaceEffects", "ZCity_OrgansPlus_EyePostProcess", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end

        local avgDmg = (smoothL + smoothR) * 0.5
    if avgDmg <= 0.05 then return end

    if avgDmg > 0.15 and (smoothL < 0.85 or smoothR < 0.85) then
        DrawMotionBlur(0.1, math.Clamp(avgDmg * 0.6, 0.05, 0.7), 0.02)
    end

    local colorData = {
        ["$pp_colour_addr"] = (smoothL > 0.25 or smoothR > 0.25) and (avgDmg * 0.06) or 0,
        ["$pp_colour_addg"] = 0,
        ["$pp_colour_addb"] = 0,
        ["$pp_colour_brightness"] = -(avgDmg * 0.2),
        ["$pp_colour_contrast"] = 1 - (avgDmg * 0.3),
        ["$pp_colour_colour"] = 1 - (avgDmg * 0.55),
        ["$pp_colour_mulr"] = 0,
        ["$pp_colour_mulg"] = 0,
        ["$pp_colour_mulb"] = 0
    }
    DrawColorModify(colorData)
end)

hook.Add("HUDPaint", "ZCity_OrgansPlus_EyeBlindness", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end

    local org = ply.organism
    local rawL = (istable(org) and org.l_eye) or lEyeDamage or 0
    local rawR = (istable(org) and org.r_eye) or rEyeDamage or 0

    local currentMax = math.max(rawL, rawR)
    if currentMax - lastEyeDmg > 0.15 then
        TriggerEyeTraumaShock(rawL > rawR)
    end
    lastEyeDmg = currentMax

    smoothL = Lerp(FrameTime() * 6, smoothL, rawL)
    smoothR = Lerp(FrameTime() * 6, smoothR, rawR)

    if smoothL <= 0.01 and smoothR <= 0.01 then return end
    local w, h = ScrW(), ScrH()

    local padX = math.ceil(w * 0.05)
    local padY = math.ceil(h * 0.04)

    local maxEye = math.max(smoothL, smoothR)
    if maxEye > 0.05 then
        local lidAlpha = math.Clamp(maxEye * 180, 0, 180)
        local lidHeight = math.ceil(h * (0.06 + 0.04 * maxEye)) + padY

        surface.SetMaterial(gradU)
        surface.SetDrawColor(0, 0, 0, lidAlpha)
        surface.DrawTexturedRect(-padX, -padY, w + padX * 2, lidHeight)

        surface.SetMaterial(gradD)
        surface.SetDrawColor(0, 0, 0, lidAlpha)
        surface.DrawTexturedRect(-padX, h - lidHeight + padY, w + padX * 2, lidHeight)

        surface.SetDrawColor(0, 0, 0, lidAlpha)
        surface.DrawRect(-padX, -padY, w + padX * 2, padY + 3)
        surface.DrawRect(-padX, h - 3, w + padX * 2, padY + 3)
    end

    if smoothL > 0.02 then
        local a = math.Clamp(smoothL * 255, 0, 255)
        surface.SetMaterial(gradL)

        local w1 = w * (0.35 + 0.35 * smoothL) + padX
        surface.SetDrawColor(0, 0, 0, math.min(a * 0.45, 255))
        surface.DrawTexturedRect(-padX, -padY, w1, h + padY * 2)

        local w2 = w * (0.1 + 0.5 * smoothL) + padX
        surface.SetDrawColor(40, 2, 2, math.min(a * 0.35, 255))
        surface.DrawTexturedRect(-padX, -padY, w2, h + padY * 2)

        local w3 = w * (0.25 + 0.6 * smoothL) + padX
        surface.SetDrawColor(0, 0, 0, math.min(a * 2, 255))
        surface.DrawTexturedRect(-padX, -padY, w3, h + padY * 2)

        local w4 = w * (0.08 + 1.2 * smoothL) + padX
        surface.SetDrawColor(0, 0, 0, math.min(a * 2, 255))
        surface.DrawTexturedRect(-padX, -padY, w4, h + padY * 2)

        local w5 = w * (0.2 + 0.5 * smoothL) + padX * 2
        surface.SetDrawColor(0, 0, 0, a)
        surface.DrawTexturedRect(-padX * 2, -padY, w5, h + padY * 2)
    end

    if smoothR > 0.02 then
        local a = math.Clamp(smoothR * 255, 0, 255)
        surface.SetMaterial(gradR)

        local w1 = w * (0.35 + 0.35 * smoothR) + padX
        surface.SetDrawColor(0, 0, 0, math.min(a * 0.45, 255))
        surface.DrawTexturedRect(w - w1 + padX, -padY, w1, h + padY * 2)

        local w2 = w * (0.1 + 0.5 * smoothR) + padX
        surface.SetDrawColor(40, 2, 2, math.min(a * 0.35, 255))
        surface.DrawTexturedRect(w - w2 + padX, -padY, w2, h + padY * 2)

        local w3 = w * (0.25 + 0.6 * smoothR) + padX
        surface.SetDrawColor(0, 0, 0, math.min(a * 2, 255))
        surface.DrawTexturedRect(w - w3 + padX, -padY, w3, h + padY * 2)

        local w4 = w * (0.08 + 1.2 * smoothR) + padX
        surface.SetDrawColor(0, 0, 0, math.min(a * 2, 255))
        surface.DrawTexturedRect(w - w4 + padX, -padY, w4, h + padY * 2)

        local w5 = w * (0.2 + 0.5 * smoothR) + padX * 2
        surface.SetDrawColor(0, 0, 0, a)
        surface.DrawTexturedRect(w - w5 + padX * 2, -padY, w5, h + padY * 2)
    end

    if smoothL >= 0.95 and smoothR >= 0.95 then
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(-padX, -padY, w + padX * 2, h + padY * 2)
    end
end)

local INTERNAL_ORGANS_ONLY = {
    ["brain"] = true, ["skull"] = true, ["jaw"] = true,
    ["l_eye"] = true, ["r_eye"] = true,
    ["trachea"] = true, ["arteria"] = true,
    ["spine3"] = true, ["spine2"] = true, ["spine1"] = true, ["spineartery"] = true,
    ["heart"] = true, ["lungsR"] = true, ["lungsL"] = true,
    ["liver"] = true, ["stomach"] = true, ["spleen"] = true,
    ["pancreas"] = true, ["kidneys"] = true,
    ["intestines"] = true, ["bladder"] = true
}

hook.Add("PostDrawTranslucentRenderables", "ZCity_OrgansPlus_DebugDraw", function(bDepth, bSkybox)
    local mode = debugConVar:GetInt()
    if bSkybox or mode <= 0 then return end
    if not hg or not hg.organism or not isfunction(hg.organism.GetHitBoxOrgans) or not isfunction(hg.organism.ShootMatrix) then return end

    if ZCityOrgans and ZCityOrgans.PatchHitboxTables then
        ZCityOrgans.PatchHitboxTables()
    end

    cam.IgnoreZ(true)
    render.SetColorMaterial()

    for _, ent in ipairs(ents.GetAll()) do
        if IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsRagdoll()) then
            if ent:IsPlayer() and IsValid(ent.FakeRagdoll) then continue end
            if ent == LocalPlayer() and not ent:ShouldDrawLocalPlayer() then continue end

            ent:SetupBones()
            local organs = hg.organism.GetHitBoxOrgans(ent:GetModel(), ent)
            if organs then
                local boxs = hg.organism.ShootMatrix(ent, organs)
                if boxs then
                    for i = 1, #boxs do
                        local box = boxs[i]
                        if box[6] and organs[box[6]] and organs[box[6]][box[7]] then
                            local organ = organs[box[6]][box[7]]
                            local organName = organ[1]
                            local isArmor = organ[7] == true
                            if not isArmor and (mode >= 2 or INTERNAL_ORGANS_ONLY[organName]) then
                                local col = organ[6] or Color(255, 255, 255)
                                render.DrawBox(box[1], box[2], box[3], box[4], Color(col.r, col.g, col.b, 90))
                                render.DrawWireframeBox(box[1], box[2], box[3], box[4], Color(255, 255, 255, 210), false)
                            end
                        end
                    end
                end
            end
        end
    end

    cam.IgnoreZ(false)
end)