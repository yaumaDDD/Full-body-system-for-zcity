-- FreeHand: free-hand physical melee for Z-City (hands, crowbar, axes).
-- A module of the AdvancedBlood addon with its own switch (fh_enabled). It does not edit Z-City:
-- it takes over six of its weapon classes at run time and leaves everything else alone.
--
-- There is no attack in it. The mouse moves hand targets, the hands pull a rigid weapon, the
-- weapon has momentum, what it touches is found by sweeping it through the world, and what a
-- touch does follows from speed, mass and angle. Design: docs/FREEHAND_ARCHITECTURE.md.

FreeHand = FreeHand or {}
local FH = FreeHand
FH.VERSION = "0.1.0"

local ROOT = "freehand/"

-- Client modules that make many engine calls a frame run in the interpreter (the same policy and
-- the same reason as lua/autorun/advancedblood.lua).
function FH.NoJIT()
	if not (CLIENT and jit and jit.off) then return end
	if istable(ABL) and ABL.jitOff == false then return end
	local info = debug.getinfo(2, "f")
	if info and info.func then jit.off(info.func, true) end
end

-- The simulation runs in the interpreter on both sides. Compiled code does not always give the
-- same last digit as the interpreter (an arc tangent is worked out by different machine code),
-- and which loop gets compiled when is not the same on a client and on a server; two runs of the
-- same moves differed in the sixteenth digit after 30 ticks with the compiler on and in nothing
-- with it off (docs/FREEHAND_TESTING.md). The client's own hands are the server's only if both
-- do the same arithmetic.
function FH.SameOnBothSides()
	if not (jit and jit.off) then return end
	local info = debug.getinfo(2, "f")
	if info and info.func then jit.off(info.func, true) end
end

-- The test harness's marker (ten minutes and it is stale), as in the other two modules.
function FH.TestMarker()
	local t = file.Time("abl_selftest.txt", "DATA")
	return isnumber(t) and t > 0 and os.time() - t < 600
end
FH.testRun = FH.TestMarker()

function FH.Print(...)
	MsgC(Color(230, 170, 90), "[FreeHand] ", color_white, string.format(...), "\n")
end

-- Order matters: later files capture tables made by earlier ones.
local shared = {
	"sh_config.lua",
	"sh_math.lua",
	"sh_body.lua",
	"sh_weapon.lua",
	"sh_sim.lua",
	"sh_tool.lua",
	"sh_contact.lua",
	"sh_patch.lua",
}

local server = {
	"sv_main.lua",
	"sv_impact.lua",
	"sv_react.lua",
	"sv_selftest.lua",
	"sv_selftest2.lua",
	"sv_selftest3.lua",
	"sv_selftest4.lua",
}

local client = {
	"cl_input.lua",
	"cl_state.lua",
	"cl_render.lua",
	"cl_tool.lua",
	"cl_react.lua",
	"cl_camera.lua",
	"cl_menu.lua",
	"cl_selftest.lua",
}

for _, f in ipairs(shared) do
	if SERVER then AddCSLuaFile(ROOT .. f) end
	include(ROOT .. f)
end

if SERVER then
	for _, f in ipairs(client) do AddCSLuaFile(ROOT .. f) end
	for _, f in ipairs(server) do include(ROOT .. f) end
else
	for _, f in ipairs(client) do include(ROOT .. f) end
end

FH.Loaded = true
hook.Run("FH_Loaded")
