-- Wound marks on the body: the visible openings of a wound record (cl_wounds.lua).
--
-- Geometry. A projectile hit is placed on the character's own render mesh: the entry is the
-- outermost surface the bullet line meets, the exit the surface that same line leaves through (so
-- entry and exit belong to one track), and a flesh-only path that stays just under the skin is a
-- graze: one elongated mark along the path instead of two holes. A retained projectile has no exit.
-- The angle of impact, the length of the track and whether the surface is bare skin or cloth are
-- written back into the record.
--
-- Drawing. A mark is a patch of the mesh's own triangles around the wound, so it is part of the
-- surface: it follows every animation and ragdoll pose and cannot float or slide. The patch is a
-- static mesh in the space of the bone it sits on (re-baked when skin that bends between bones has
-- moved under it), drawn once per layer. Layers are textures from tools/texgen, each placed by its
-- own texture transform (size, stretch along the bullet's path, rotation, offset), so no two wounds
-- are the same picture:
--   on skin   bruise, soot, powder stippling (by range), abrasion collar (pushed towards the side the
--             bullet came from), the defect itself, wet blood, clot / crust;
--   on cloth  the hole in the fabric with its dark wipe ring, soot / stippling, torn threads at an
--             exit, and the blood soaking into the cloth around the hole as it comes.
-- What a layer shows changes continuously with the record's state: the bruise comes up, wet blood
-- loses its gloss, darkens and sets into a crust, edge first.
--
-- Depth (phase 43). The layers are paint on the surface: a painted hole has no inside, and from
-- the side it is a dark disc on the skin. A character's own mesh cannot be cut from Lua. So the
-- opening is cut out of the picture instead and something real is put behind it:
--   1. the opening is written into the stencil buffer, by drawing the patch (the skin's own
--      triangles) with the opening's outline as an alpha-tested texture, depth-tested, so that
--      it marks exactly the pixels in which that piece of skin is seen;
--   2. in those pixels the colour is set to the wound's dark ground and the depth to far;
--   3. the recess is drawn through them: a small mesh behind the skin, its mouth a little
--      wider than the opening (the skin's edge overhangs it), its walls leaning along the
--      projectile's path, its floor uneven, coloured by depth (the cut edge of the skin, fat
--      where the opening is wide enough to show it, muscle, and darker the deeper: light does
--      not get down a hole), with a surface of blood standing in it that follows the wound's
--      state (high and wet while it bleeds, sunk, dark and dull when it has set).
-- The recess is geometry in the space of the wound: it is seen in perspective, its near wall
-- hides its floor from the side and its far wall shows, and it goes with the bone like the patch.
-- abl_wound_3d 0, a mark further off than cavDist, or a mark without a patch: the painted
-- opening alone, as before.
--
-- Bleeding: Z-City's wounds linked to the record bleed from exactly these openings (cl_emission).

ABL.NoJIT()
ABL.WoundFX = ABL.WoundFX or {}
local W = ABL.WoundFX
local C, BM, L, WD = ABL.Config, ABL.BodyMesh, ABL.LOD, ABL.Wound
local WC, WR = C.WoundFX, C.Wound
local sqrt, min, max, abs, cos, sin, exp = math.sqrt, math.min, math.max, math.abs, math.cos, math.sin, math.exp
local Clamp = math.Clamp

local PASS_FILTER, PASS_COLOUR, PASS_GLOSS = 1, 2, 3

------------------------------------------------------------------------------------------
-- Layer materials (one per texture and pass, shared by all marks: placed per draw)
------------------------------------------------------------------------------------------
local mats = {}
local function LayerMat(tex, pass)
	local key = tex .. ":" .. pass
	local mt = mats[key]
	if mt then return mt end
	local kv = { ["$basetexture"] = "advancedblood/" .. tex, ["$vertexcolor"] = 1, ["$vertexalpha"] = 1, ["$nocull"] = 1 }
	if pass == PASS_GLOSS then kv["$additive"] = 1 else kv["$translucent"] = 1 end
	mt = CreateMaterial("abl_wl_" .. string.gsub(tex, "[^%w]", "_") .. "_" .. pass, "UnlitGeneric", kv)
	mats[key] = mt
	return mt
end

-- What a layer is (how its opacity, colour and size follow the wound's state).
--   FIXED   what the shot left for good: soot, stippling, abrasion, the defect itself
--   BRUISE  comes up over the first minute
--   BLOOD   the wet film around the wound: there within a second, darkens, gives way to the crust
--   CRUST   what the film sets into
--   GLOSS   reflection of the wet parts
--   SOAK    blood in the cloth around a hole: grows with what has come out of the wound
--   SOAKB   that blood's own colour over it (a soak-only mark: see PlaceSoak)
local K_FIXED, K_BRUISE, K_BLOOD, K_GLOSS, K_CRUST, K_SOAK, K_SOAKB = 1, 2, 3, 4, 5, 6, 7
--   FLUSH   reddening where a blunt blow fell: there at once, gives way as the bruise comes up
local K_FLUSH = 8

-- The kinds of mark there are (mk.kind), and what makes each (phase 44). A new kind is a branch
-- in BuildLayers (what is painted), a line here, and, if it has an opening, a profile for its
-- recess (CAV_PROFILE):
--   entry, exit, graze   a projectile: where it went in, where it came out, a furrow along the skin
--   cut                  an edged weapon along the skin: a gash with a trench behind it
--   stab                 an edged weapon into the body: a short slit, a deep narrow way in
--   blunt                a blunt weapon: a bruise, reddening, a scrape from a hard blow; no opening
--   soak                 no mark of its own: the cloth round a wound taking up blood
W.Kinds = { entry = true, exit = true, graze = true, cut = true, stab = true, blunt = true, soak = true }

-- variants per texture family (tools/texgen)
local NV = { bruise = 3, soot = 2, stipple = 3, collar = 3, wipe = 2, defect = 4, stellate = 2, tear = 4, blood = 4, crust = 3, furrow = 2, imprint = 2, clothhole = 3, clothtear = 3, soak = 2 }

local function Layer(layers, tex, pass, kind, half, st, rot, ox, oy, alpha, detail)
	local l = { mat = LayerMat("wounds/" .. tex, pass), pass = pass, kind = kind, half = half, half0 = half, st = st or 1, rot = rot or 0, ox = ox or 0, oy = oy or 0, a = alpha or 1, detail = detail or false }
	layers[#layers + 1] = l
	return l
end

-- The layer that is the wound's opening: the recess is cut where it is.
local function Hole(mk, l, name)
	mk.hole, mk.holeName = l, name
	return l
end

local function Pick(rng, family)
	return family .. (1 + math.floor(rng:Next() * NV[family]) % NV[family])
end

-- The layers of a mark, back to front, from its record. Returns the list and the half-size of
-- the patch that holds them all.
--   mk.skin    bare skin or cloth
--   mk.down    rotation that turns a layer's "down" towards where gravity pulled along the skin
--              when the wound was made (the film that welled out ran that way)
local function BuildLayers(mk, r, rng)
	local layers = {}
	local kind, skin = mk.kind, mk.skin
	local down = mk.down or 0
	local absorb = mk.absorb or 1
	-- an oblique path draws everything out along it
	local obl = Clamp(1 / (r.cosI or 1), 1, 2.4) ^ 0.7

	if kind == "soak" then
		-- No opening is drawn (a cut, a tear, a wound made by something other than a bullet): only
		-- the cloth round it taking blood up. As a filter it darkens the cloth; blood is not a dye,
		-- so its own colour lies over that (on dark or coloured cloth the patch is red-brown, not black).
		local sk = Pick(rng, "soak")
		local half, rot = mk.len or 1.6, rng:Range(-3, 3)
		Layer(layers, sk, PASS_FILTER, K_SOAK, half, 1, rot, 0, 0, absorb)
		Layer(layers, sk, PASS_COLOUR, K_SOAKB, half, 1, rot, 0, 0, 0.42 * absorb)
	elseif kind == "graze" then
		-- A furrow along the skin: as long as the path, a few projectile widths across
		local hy = Clamp(r.caliber * 2.6, 0.55, 1.3)
		local st = Clamp(((mk.len or 3) * 0.5 / 0.82) / hy, 1, 4.5)
		local rot = rng:Range(-0.05, 0.05)
		if skin then
			Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_BRUISE, hy * 1.5, st, rng:Range(-3, 3), 0, 0, 0.5, true)
			Layer(layers, Pick(rng, "blood"), PASS_COLOUR, K_BLOOD, hy * rng:Range(0.9, 1.3), 1, down, rng:Range(-0.3, 0.3) * hy * st, 0, 0.85)
			Layer(layers, Pick(rng, "crust"), PASS_COLOUR, K_CRUST, hy * 0.8, st * 0.8, rot, 0, 0, 0.9, true)
			local f = Pick(rng, "furrow")
			Hole(mk, Layer(layers, f, PASS_COLOUR, K_FIXED, hy, st, rot), f)
			Layer(layers, f .. "_g", PASS_GLOSS, K_GLOSS, hy, st, rot)
		else
			-- cloth torn open along the path, the furrow showing through it
			Layer(layers, Pick(rng, "soak"), PASS_FILTER, K_SOAK, hy * 1.7, st * 0.8, rng:Range(-3, 3), 0, 0, absorb)
			local f = Pick(rng, "furrow")
			-- (in the shade of the torn cloth, and soaked dark like it)
			Hole(mk, Layer(layers, f, PASS_COLOUR, K_FIXED, hy * 0.85, st, rot, 0, 0, 0.95), f).tint = 0.5
		end

	elseif kind == "blunt" then
		-- A blunt weapon: nothing is opened. On bare skin a bruise that comes up over the first
		-- minute, larger for a harder blow and a wider weapon; reddening that is there at once
		-- and gives way to it; and, from a hard blow, a scrape drawn along the way it went.
		-- Under cloth there is nothing to see: no mark.
		if skin then
			local dmg = r.damage or 10
			local wide = (r.diameter or 0) > 0 and r.diameter / 4 or 2
			-- (the damage of a blunt blow as it arrives is small: 1 to about 8. sh_config.lua, bluntMin)
			local size = Clamp(1.0 + dmg * 0.28 + wide * 0.14, 1.2, 3.2)
			local a = Clamp(0.5 + dmg * 0.07, 0.55, 0.95)
			Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_BRUISE, size, obl, rng:Range(-3, 3), 0, 0, a)
			Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_BRUISE, size * 0.55, obl, rng:Range(-3, 3), rng:Range(-0.2, 0.2) * size, rng:Range(-0.2, 0.2) * size, 0.75, true)
			local fl = Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_FLUSH, size * 0.7, obl, rng:Range(-3, 3), 0, 0, 0.6)
			fl.cr, fl.cg, fl.cb = 1.3, 0.62, 0.6
			if dmg >= 2 then
				local sc = Layer(layers, Pick(rng, "furrow"), PASS_COLOUR, K_FIXED, Clamp(0.5 + wide * 0.1, 0.5, 0.9), Clamp(1.2 + dmg * 0.12, 1.3, 2.4), rng:Range(-0.2, 0.2), 0, 0, 0.45, true)
				sc.tint = 0.8
			end
		end

	elseif kind == "stab" then
		-- An edged weapon into the body (phase 44): a short slit as long as the blade is wide,
		-- hardly gaping, and behind it a deep, narrow way in. The blade's width and how deep it
		-- goes are the weapon's own numbers (sv_main.lua); nothing else about it is known.
		local wide = (r.diameter or 0) > 0 and r.diameter / 4 or 1
		local hl = Clamp(0.22 + 0.2 * wide, 0.3, 0.9)
		local hw = Clamp(0.07 + 0.03 * wide, 0.08, 0.16)
		local half = hw / 0.246
		local st = hl / (half * 0.543)
		local rot = rng:Range(-0.1, 0.1)
		if skin then
			Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_BRUISE, Clamp(hl * 2.2, 0.9, 1.8), 1.3, rng:Range(-0.3, 0.3), 0, 0, 0.3, true)
			local b = Pick(rng, "blood")
			local hb = Clamp(hl * 2.0, 0.7, 1.6)
			Layer(layers, b, PASS_COLOUR, K_BLOOD, hb, 1, down)
			Layer(layers, Pick(rng, "crust"), PASS_COLOUR, K_CRUST, hb * 0.8, 1, down, 0, 0, 0.95, true)
			Hole(mk, Layer(layers, "tear1", PASS_COLOUR, K_FIXED, half, st, rot), "tear1")
			Layer(layers, b .. "_g", PASS_GLOSS, K_GLOSS, hb, 1, down, 0, 0, 0.7)
			Layer(layers, "tear1_g", PASS_GLOSS, K_GLOSS, half, st, rot)
		else
			Layer(layers, Pick(rng, "soak"), PASS_FILTER, K_SOAK, Clamp(hl * 2.6, 1.1, 2.2), 1, rng:Range(-3, 3), 0, 0, absorb)
			Hole(mk, Layer(layers, "tear1", PASS_COLOUR, K_FIXED, half, st, rot, 0, 0, 0.95), "tear1").tint = 0.55
		end

	elseif kind == "cut" then
		-- An edged weapon (phase 43): a gash, long and narrow, with clean edges and no collar.
		-- How long and how wide it gapes: by what the blow did (the damage Z-City booked for
		-- it; nothing else about the blade is known here). It lies along the way the blow went
		-- over the skin where it came at a slant; a blow straight in has no such way, and the
		-- gash then lies as the mark's own seed has it.
		local dmg = r.damage or 20
		local len = Clamp(1.3 + dmg * 0.045, 1.4, 4.2)
		local hw = Clamp(0.14 + dmg * 0.003, 0.15, 0.30)
		local half = hw / 0.246
		local st = (len * 0.5) / (half * 0.543)
		local rot = rng:Range(-0.1, 0.1)
		if skin then
			Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_BRUISE, Clamp(len * 0.55, 1.3, 2.6), 1.6, rng:Range(-0.3, 0.3), 0, 0, 0.35, true)
			local b = Pick(rng, "blood")
			local hb = Clamp(len * 0.5, 1.0, 2.4)
			Layer(layers, b, PASS_COLOUR, K_BLOOD, hb, 1, down)
			Layer(layers, Pick(rng, "crust"), PASS_COLOUR, K_CRUST, hb * 0.8, 1, down, 0, 0, 0.95, true)
			Hole(mk, Layer(layers, "tear1", PASS_COLOUR, K_FIXED, half, st, rot), "tear1")
			Layer(layers, b .. "_g", PASS_GLOSS, K_GLOSS, hb, 1, down, 0, 0, 0.7)
			Layer(layers, "tear1_g", PASS_GLOSS, K_GLOSS, half, st, rot)
		else
			-- through cloth: the cloth cut with the skin, taking up blood round the cut
			Layer(layers, Pick(rng, "soak"), PASS_FILTER, K_SOAK, Clamp(len * 0.7, 1.4, 3.4), 1, rng:Range(-3, 3), 0, 0, absorb)
			Hole(mk, Layer(layers, "tear1", PASS_COLOUR, K_FIXED, half, st, rot, 0, 0, 0.95), "tear1").tint = 0.55
		end

	elseif kind == "exit" then
		-- Torn open from inside: no abrasion, no soot, whatever the range
		local ro = r.exitOpening
		local big = ro > r.caliber * 0.85
		if skin then
			local tear = (r.boneHit and big) and (rng:Next() < 0.6 and "tear3" or "tear2") or (not big and (rng:Next() < 0.5 and "tear4" or "tear1")) or Pick(rng, "tear")
			local half = Clamp(ro / 0.36, 0.7, 3.2)
			local rot = rng:Range(-3.14, 3.14)
			Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_BRUISE, Clamp(half * 2.2, 1.8, 4), 1, rng:Range(-3, 3), 0, 0, 0.75, true)
			local b = Pick(rng, "blood")
			local hb = half * rng:Range(1.3, 1.9)
			Layer(layers, b, PASS_COLOUR, K_BLOOD, hb, 1, down)
			Layer(layers, Pick(rng, "crust"), PASS_COLOUR, K_CRUST, hb * 0.8, 1, down, 0, 0, 0.95, true)
			Hole(mk, Layer(layers, tear, PASS_COLOUR, K_FIXED, half, 1, rot), tear)
			Layer(layers, b .. "_g", PASS_GLOSS, K_GLOSS, hb, 1, down, 0, 0, 0.7)
			Layer(layers, tear .. "_g", PASS_GLOSS, K_GLOSS, half, 1, rot)
		else
			local half = Clamp(ro / 0.3, 0.8, 3.2)
			local rot = rng:Range(-3.14, 3.14)
			Layer(layers, Pick(rng, "soak"), PASS_FILTER, K_SOAK, Clamp(half * 1.9, 1.6, 4.2), 1, rng:Range(-3, 3), 0, 0, absorb)
			local t = Pick(rng, "clothtear")
			Hole(mk, Layer(layers, t, PASS_COLOUR, K_FIXED, half, 1, rot), t)
			Layer(layers, t .. "_g", PASS_GLOSS, K_GLOSS, half, 1, rot, 0, 0, 0.6)
		end

	else
		-- Entry. Around the defect lies what the shot left on the first surface it met, by range:
		-- soot (contact, near), powder stippling (near, medium), the muzzle's imprint (contact)
		local rd = r.opening
		local reach = r.reachK or 1
		local contact = r.range == WD.RANGE_CONTACT
		if r.soot > 0 then
			-- (pressed on: little escapes, a narrow dense ring. A hand away: wide and thin)
			local half = contact and Clamp(rd * 4.5 * reach, 0.9, 1.6) or Clamp(rd * 11 * reach, 2, 3.6)
			Layer(layers, Pick(rng, "soot"), PASS_COLOUR, K_FIXED, half, obl, rng:Range(-3, 3), half * 0.3 * (obl - 1), 0, (contact and 0.95 or 0.6) * r.soot)
		end
		if r.stipple > 0 then
			local half = Clamp(rd * (r.range == WD.RANGE_MEDIUM and 17 or 12) * reach, 2.4, 4.6)
			Layer(layers, Pick(rng, "stipple"), PASS_COLOUR, K_FIXED, half, obl, rng:Range(-3, 3), half * 0.25 * (obl - 1), 0, r.stipple * (skin and 1 or 0.4), true)
		end
		if skin then
			Layer(layers, Pick(rng, "bruise"), PASS_COLOUR, K_BRUISE, Clamp(rd * (6 + 9 * r.cavity), 1.5, 3.6), obl, rng:Range(-3, 3), 0, 0, 0.45 + 0.4 * r.cavity, true)
			if contact and r.imprint > 0.45 then
				Layer(layers, Pick(rng, "imprint"), PASS_COLOUR, K_FIXED, Clamp(rd * 3.6, 0.8, 1.3), 1, rng:Range(-3, 3), 0, 0, 0.85 * r.imprint, true)
			end
			-- abrasion collar: wider on the side the bullet came from
			local cr = rd * (1.35 + 0.5 * r.collar)
			Layer(layers, Pick(rng, "collar"), PASS_COLOUR, K_FIXED, cr / 0.72, obl ^ 1.25, rng:Range(-3, 3), -rd * 0.9 * (obl - 1), 0, 0.9)
			if r.wipe > 0 then
				Layer(layers, Pick(rng, "wipe"), PASS_COLOUR, K_FIXED, rd * 1.25 / 0.74, obl, 0, 0, 0, 0.55 * r.wipe, true)
			end
			local b = Pick(rng, "blood")
			local hb = Clamp(rd * rng:Range(3.6, 5.2), 0.8, 1.7)
			Layer(layers, b, PASS_COLOUR, K_BLOOD, hb, 1, down)
			Layer(layers, Pick(rng, "crust"), PASS_COLOUR, K_CRUST, hb * 0.8, 1, down, 0, 0, 0.95, true)
			local hole, half
			if r.stellate > 0 then
				-- a contact wound over bone, burst open by the gas
				hole, half = Pick(rng, "stellate"), rd * (3 + 2.2 * r.stellate)
			else
				hole, half = Pick(rng, "defect"), rd / 0.5
			end
			local rot = rng:Range(-0.15, 0.15) + (r.stellate > 0 and rng:Range(-3, 3) or 0)
			local st = r.stellate > 0 and 1 or obl
			Hole(mk, Layer(layers, hole, PASS_COLOUR, K_FIXED, half, st, rot), hole)
			Layer(layers, b .. "_g", PASS_GLOSS, K_GLOSS, hb, 1, down, 0, 0, 0.7)
			Layer(layers, hole .. "_g", PASS_GLOSS, K_GLOSS, half, st, rot)
		else
			-- through cloth: the hole in the weave (its dark rim is the bullet wipe), blood coming
			-- up into the cloth around it
			Layer(layers, Pick(rng, "soak"), PASS_FILTER, K_SOAK, Clamp(rd * 7, 1.3, 2.4), 1, rng:Range(-3, 3), 0, 0, absorb)
			local h = Pick(rng, "clothhole")
			local half = rd / 0.29
			Hole(mk, Layer(layers, h, PASS_COLOUR, K_FIXED, half, obl, rng:Range(-3, 3)), h)
			Layer(layers, h .. "_g", PASS_GLOSS, K_GLOSS, half, obl, 0, 0, 0, 0.5)
		end
	end

	local S = 0
	for i = 1, #layers do
		local l = layers[i]
		local ext = l.half * max(l.st, 1) + max(abs(l.ox), abs(l.oy))
		if ext > S then S = ext end
	end
	return layers, S
end

------------------------------------------------------------------------------------------
-- Creation
------------------------------------------------------------------------------------------
-- Tangent frame of the mark in bind space: normal n, +x (t) along `dir` projected onto the skin.
local function Frame(m, tri, bdx, bdy, bdz)
	local nx, ny, nz = BM.BindNormal(m, tri)
	local tx, ty, tz = 0, 0, 0
	if bdx then
		local dn = bdx * nx + bdy * ny + bdz * nz
		tx, ty, tz = bdx - nx * dn, bdy - ny * dn, bdz - nz * dn
	end
	local tl = sqrt(tx * tx + ty * ty + tz * tz)
	if tl < 0.15 then
		tx, ty, tz = ABL.Perp(nx, ny, nz)
	else
		tx, ty, tz = tx / tl, ty / tl, tz / tl
	end
	local bx, by, bz = ny * tz - nz * ty, nz * tx - nx * tz, nx * ty - ny * tx
	return nx, ny, nz, tx, ty, tz, bx, by, bz
end

------------------------------------------------------------------------------------------
-- The recess: what is behind a wound's opening (see the head of this file).
-- Built once with the mark, in the wound's own space: x along the mark's tangent (the
-- projectile's direction along the skin), y across, z out of the skin, the origin on the skin
-- at the wound. Nothing in it is asked for again while the wound exists; where the wound's
-- space lies on its bone is worked out with the patch (Bake), and again when skin that bends
-- between bones has moved.
------------------------------------------------------------------------------------------
local CAV_N = 14            -- places round the wall
-- Down the wall: how deep (share of the depth) and how wide (share of the opening) each ring
-- is. An entry is a funnel: skin pushed in, narrowing to the track. An exit is undermined:
-- wider under the skin than at it, then closing. A graze is a shallow trench. The first ring
-- stands a little over the skin and wider than the opening, so that the skin's edge overhangs.
local CAV_PROFILE = {
	entry = { s = { 0, 0.10, 0.30, 0.58, 0.84, 1 }, rho = { 1.18, 1.05, 0.84, 0.62, 0.42, 0.20 } },
	exit  = { s = { 0, 0.12, 0.34, 0.62, 0.86, 1 }, rho = { 1.18, 1.28, 1.22, 0.98, 0.64, 0.28 } },
	graze = { s = { 0, 0.30, 0.70, 1 }, rho = { 1.14, 0.94, 0.64, 0.30 } },
	-- a cut: its two faces come together at the bottom
	cut   = { s = { 0, 0.22, 0.58, 1 }, rho = { 1.14, 0.80, 0.42, 0.10 } },
}
local function RhoAt(p, s)
	local S, R = p.s, p.rho
	for j = 2, #S do
		if s <= S[j] then
			local k = (s - S[j - 1]) / (S[j] - S[j - 1])
			return R[j - 1] + (R[j] - R[j - 1]) * k
		end
	end
	return R[#R]
end

-- The colour of the wall at a depth (0 at the skin, 1 at the floor), as it would be in full
-- light: the cut edge of the skin, fat under it where the opening is wide enough to show it,
-- muscle, and all of it darker the deeper it lies. Never black: a wound's inside is seen.
-- cloth: the first band is the edge of the cloth, not of skin. pale: a floor of bone.
local function WallColour(s, wide, cloth, pale, jit)
	local r, g, b
	if cloth and s < 0.06 then
		-- (the cloth's own thickness, dark with what it took up; under it the body's wound as
		-- on bare skin. All of the first band in the cloth's colour made a hole in cloth a
		-- black shape with nothing in it: run w3d3.)
		r, g, b = 0.22, 0.17, 0.16
	elseif s < 0.13 then
		local k = s / 0.13
		r, g, b = 0.55 - 0.10 * k, 0.25 - 0.08 * k, 0.23 - 0.07 * k
	elseif s < 0.33 and wide then
		local k = (s - 0.13) / 0.20
		-- (fat: pale and yellowish under the blood on it, never orange: run w3d4)
		r, g, b = 0.50 - 0.10 * k, 0.30 - 0.16 * k, 0.19 - 0.09 * k
	else
		local k = Clamp((s - 0.13) / 0.87, 0, 1)
		r, g, b = 0.50 - 0.24 * k, 0.085 - 0.04 * k, 0.085 - 0.04 * k
	end
	if pale and s > 0.8 then
		local k = (s - 0.8) / 0.2
		r, g, b = r + (0.62 - r) * k, g + (0.52 - g) * k, b + (0.42 - b) * k
	end
	local ao = (1 - 0.44 * s ^ 0.8) * (1 + jit)
	return r * ao, g * ao, b * ao
end

-- A place of the opening's layer (q: the layer's own -1..1) in the wound's space (units).
local function HoleToWound(l, qx, qy)
	local c, s = cos(l.rot), sin(l.rot)
	return l.ox + l.half * l.st * (c * qx + s * qy), l.oy + l.half * (-s * qx + c * qy)
end

local function BuildCavity(mk, r)
	local l, name = mk.hole, mk.holeName
	local ext = l and WC.open[name]
	if not ext then return end
	local kind = mk.kind
	local stellate = string.find(name, "stellate", 1, true) ~= nil
	local prof = CAV_PROFILE[(kind == "graze" and "graze") or (kind == "cut" and "cut") or ((kind == "exit" or stellate) and "exit") or "entry"]
	-- the opening's two half-widths in units, and its size
	local ru, rv = l.half * l.st * ext[1], l.half * ext[2]
	local R0 = sqrt(ru * rv)
	-- how deep: an entry is a narrow way in, deeper the more the tissue round the track was
	-- stretched; an exit is wide and shallower for its width; a wound burst open over bone is
	-- shallow with bone for a floor; a graze is a trench a projectile's width deep
	local D
	if kind == "graze" then D = Clamp(rv * 1.3, 0.10, 0.30)
	elseif kind == "cut" then D = Clamp(0.28 + (r.damage or 20) * 0.011, 0.3, 0.95)
	elseif kind == "stab" then D = Clamp(0.4 + ((r.energy or 0) * 1.5) * 0.085, 0.45, WC.cavMax)
	elseif stellate then D = Clamp(R0 * 0.8, WC.cavMin, 0.6)
	elseif kind == "exit" then D = Clamp(R0 * (1.3 + 0.9 * (r.cavity or 0)), WC.cavMin, WC.cavMax)
	else D = Clamp(R0 * (2.4 + 1.8 * (r.cavity or 0)), WC.cavMin, WC.cavMax) end
	if not mk.skin then D = D + 0.05 end
	-- which way it leans: along the projectile's path into the body (an entry: the way the
	-- projectile went; an exit: back the way it came)
	local kx, ky = 0, 0
	if mk.bdx and kind ~= "graze" then
		local dt = mk.bdx * mk.tx + mk.bdy * mk.ty + mk.bdz * mk.tz
		local db = mk.bdx * mk.bx + mk.bdy * mk.by + mk.bdz * mk.bz
		local dn = mk.bdx * mk.nx + mk.bdy * mk.ny + mk.bdz * mk.nz
		if kind == "exit" then dt, db, dn = -dt, -db, -dn end
		local inw = max(-dn, 0.45)
		kx, ky = dt / inw, db / inw
		local kl = sqrt(kx * kx + ky * ky)
		if kl > WC.cavLean then kx, ky = kx / kl * WC.cavLean, ky / kl * WC.cavLean end
	end
	local rng = ABL.RNG((r.id or 0) * 31 + (kind == "exit" and 7717 or 3301))
	local wide = R0 > 0.42 or (kind == "cut" and D > 0.5)
	local pale = stellate or (r.skull and kind ~= "graze") or false
	local S, RHO = prof.s, prof.rho
	local nr = #S
	-- rings: positions, colours, texture coordinates
	local px, py, pz, cr, cg, cb, tu, tv = {}, {}, {}, {}, {}, {}, {}, {}
	local n = 0
	-- (how far in or out each place round the wall stands: the same all the way down, with a
	-- little of its own at each ring, so that the wall has ridges and is no turned bowl)
	local ridge = {}
	for k = 1, CAV_N do ridge[k] = rng:Range(-0.13, 0.13) end
	local twist = rng:Range(0, 1)
	for j = 1, nr do
		local s = S[j]
		local z = (j == 1) and 0.07 or -D * s
		local sx, sy = (j == 1) and 0 or kx * D * s, (j == 1) and 0 or ky * D * s
		for k = 1, CAV_N do
			local th = (k - 1) / CAV_N * 6.2831853
			local rr = RHO[j] * ((j == 1) and 1 or (1 + ridge[k] + rng:Range(-0.07, 0.07)))
			local x, y = HoleToWound(l, ext[1] * cos(th) * rr, ext[2] * sin(th) * rr)
			n = n + 1
			px[n], py[n], pz[n] = x + sx, y + sy, z + ((j > 2) and rng:Range(-0.04, 0.04) * D or 0)
			cr[n], cg[n], cb[n] = WallColour(s, wide, not mk.skin, pale, rng:Range(-0.14, 0.14))
			tu[n], tv[n] = (k - 1) / CAV_N * 2 + twist, s * 1.3 + rng:Range(-0.03, 0.03)
		end
	end
	-- the floor's middle, a little deeper and off the middle
	local fx, fy = HoleToWound(l, ext[1] * rng:Range(-0.08, 0.08), ext[2] * rng:Range(-0.08, 0.08))
	n = n + 1
	px[n], py[n], pz[n] = fx + kx * D * 1.03, fy + ky * D * 1.03, -D * 1.05
	cr[n], cg[n], cb[n] = WallColour(1, wide, not mk.skin, pale, 0)
	tu[n], tv[n] = twist + 1, 1.45
	local ox, oy = HoleToWound(l, 0, 0)
	mk.cav = {
		prof = prof, D = D, kx = kx, ky = ky, R0 = R0, nr = nr, n = n, ox = ox, oy = oy,
		px = px, py = py, pz = pz, cr = cr, cg = cg, cb = cb, tu = tu, tv = tv,
		-- the outline at the opening itself, about its middle: the surface of the blood
		ex = ext[1], ey = ext[2],
		pale = pale, graze = kind == "graze",
	}
end

local cvec = Vector()
local function CV(c, i, mul)
	cvec:SetUnpacked(c.px[i], c.py[i], c.pz[i])
	mesh.Position(cvec)
	mesh.TexCoord(0, c.tu[i], c.tv[i])
	mesh.Color(min(255, c.cr[i] * 255 * mul), min(255, c.cg[i] * 255 * mul), min(255, c.cb[i] * 255 * mul), 255)
	mesh.AdvanceVertex()
end

-- The recess as two static meshes in the wound's space: the wall with its floor, and the
-- surface of the blood (a disc the size of the opening, about the opening's middle: it is put
-- at its depth, and made as wide as the wall is there, when it is drawn).
local function BakeCavity(mk)
	local c = mk.cav
	if not c or c.mesh then return end
	local N, nr = CAV_N, c.nr
	local ms = Mesh()
	mesh.Begin(ms, MATERIAL_TRIANGLES, (nr - 1) * N * 2 + N)
	for j = 1, nr - 1 do
		for k = 1, N do
			local k2 = k % N + 1
			local a, b = (j - 1) * N + k, (j - 1) * N + k2
			local d, e = j * N + k, j * N + k2
			-- (wound so that the side toward the middle is the front: the wall is seen from inside)
			CV(c, a, 1) CV(c, d, 1) CV(c, b, 1)
			CV(c, b, 1) CV(c, d, 1) CV(c, e, 1)
		end
	end
	local mid = c.n
	for k = 1, N do
		local k2 = k % N + 1
		CV(c, (nr - 1) * N + k, 1) CV(c, mid, 1) CV(c, (nr - 1) * N + k2, 1)
	end
	mesh.End()
	c.mesh = ms
	-- the blood: a fan about the middle
	local l = mk.hole
	local bs = Mesh()
	mesh.Begin(bs, MATERIAL_TRIANGLES, N)
	local function BV(x, y, u, v, lum)
		cvec:SetUnpacked(x, y, 0)
		mesh.Position(cvec)
		mesh.TexCoord(0, u, v)
		mesh.Color(255 * lum, 255 * lum, 255 * lum, 255)
		mesh.AdvanceVertex()
	end
	for k = 1, N do
		local t1, t2 = (k - 1) / N * 6.2831853, (k % N) / N * 6.2831853
		local x1, y1 = HoleToWound(l, c.ex * cos(t1), c.ey * sin(t1))
		local x2, y2 = HoleToWound(l, c.ex * cos(t2), c.ey * sin(t2))
		-- (darker toward the wall: the blood is shallower there and stands in its shade)
		BV(x1 - c.ox, y1 - c.oy, 0.5 + 0.5 * cos(t1), 0.5 + 0.5 * sin(t1), 0.62)
		BV(x2 - c.ox, y2 - c.oy, 0.5 + 0.5 * cos(t2), 0.5 + 0.5 * sin(t2), 0.62)
		BV(0, 0, 0.5, 0.5, 1)
	end
	mesh.End()
	c.blood = bs
end

local function FreeCavity(mk)
	local c = mk.cav
	if not c then return end
	if c.mesh then c.mesh:Destroy() c.mesh = nil end
	if c.blood then c.blood:Destroy() c.blood = nil end
end

-- Where the wound's space lies on its bone: a matrix from the wound's space to the bone's.
-- o: the wound's place, t, b, n: its axes, all in the bone's space.
local function SetFrame(mk, ox, oy, oz, tx, ty, tz, bx, by, bz, nx, ny, nz)
	local fm = mk.frame
	if not fm then fm = Matrix() mk.frame = fm end
	fm:SetUnpacked(tx, bx, nx, ox, ty, by, ny, oy, tz, bz, nz, oz, 0, 0, 0, 1)
end

local function AddMark(src, r, kind, tri, u, v, dx, dy, dz, rng, len)
	local m, pose = src.mesh, src.pose
	local bdx, bdy, bdz = BM.WorldDirToBind(pose, m.tb[tri], dx, dy, dz)
	local nx, ny, nz, tx, ty, tz, bx, by, bz = Frame(m, tri, bdx, bdy, bdz)
	local bone = m.tb[tri]
	local mk = {
		kind = kind, rec = r, m = m, tri = tri, u = u, v = v,
		anchor = { tri, u, v, m },
		nx = nx, ny = ny, nz = nz, tx = tx, ty = ty, tz = tz, bx = bx, by = by, bz = bz,
		born = CurTime(), tone = rng:Range(C.ToneRange[1], 1),
		bone = bone, len = len,
		absorb = (m.tabs and m.tabs[tri]) or 1,
		-- (the projectile's direction as the body stood, in the mesh's own space: the recess leans along it)
		bdx = bdx, bdy = bdy, bdz = bdz,
	}
	-- bare skin or cloth: by the material where the model names its skin (a cap on a head is not
	-- skin), else by the body part
	if (m.nskin or 0) > 0 then
		mk.skin = m.tskin[tri] == true
	else
		mk.skin = ABL.Flow.SkinBone(src, bone) or false
	end
	-- which way is down along the skin, as the body stands now: the blood that wells out of the
	-- wound in the first moments runs that way (a layer's own "down" is its +v)
	local gx, gy, gz = ABL.Gravity()
	local ggx, ggy, ggz = BM.WorldDirToBind(pose, bone, gx, gy, gz)
	local gt, gb = 0, 0
	if ggx then gt, gb = ggx * tx + ggy * ty + ggz * tz, ggx * bx + ggy * by + ggz * bz end
	mk.down = (gt * gt + gb * gb > 0.04) and math.atan2(gt, gb) or rng:Range(-3.14, 3.14)
	mk.layers, mk.S = BuildLayers(mk, r, rng)
	-- (the recess behind the opening, if this mark has one: its own generator, so that the
	-- layers are what they were before there was a recess)
	if mk.hole then BuildCavity(mk, r) end
	-- (nothing to show: a blunt blow on cloth. No mark.)
	if #mk.layers == 0 then return nil end
	mk.hitPos = Vector(pose:Point(tri, u, v))
	if C.cl.woundDebug:GetBool() then
		ABL.Print("wound mark: %s on bone %s (%s), %s, the blow %.0f degrees off the skin's normal, at (%.1f %.1f %.1f)%s", kind, tostring(src.body:GetBoneName(bone)), tostring(r.region),
			mk.skin and "bare skin" or "cloth", math.deg(math.acos(Clamp(r.cosI or 1, -1, 1))), mk.hitPos.x, mk.hitPos.y, mk.hitPos.z,
			mk.cav and string.format("; opening %.2f units, recess %.2f deep", mk.cav.R0, mk.cav.D) or "; no opening")
	end
	src.marks = src.marks or {}
	local marks = src.marks
	-- a new wound right on top of an older one replaces it
	local px, py, pz = BM.BindPoint(m, tri, u, v)
	for i = #marks, 1, -1 do
		local o = marks[i]
		if o.m == m and o.kind == kind then
			local ox2, oy2, oz2 = BM.BindPoint(m, o.tri, o.u, o.v)
			if (ox2 - px) ^ 2 + (oy2 - py) ^ 2 + (oz2 - pz) ^ 2 < 0.3 * 0.3 then o.gone = true W.FreeMark(o) table.remove(marks, i) end
		end
	end
	local most = Clamp(C.cl.woundMax:GetInt(), 2, 40)
	while #marks >= most do marks[1].gone = true W.FreeMark(marks[1]) table.remove(marks, 1) end
	marks[#marks + 1] = mk
	return mk
end

-- Place the wound of record r on the body mesh: bullet line through world point (x,y,z) near
-- `bone`, direction (dx,dy,dz). Fills in the record's surface geometry. Returns the entry (or
-- graze) mark and the exit mark; either may be nil.
function W.PlaceWound(src, r, bone, x, y, z, dx, dy, dz, rng)
	local m, pose = src.mesh, src.pose
	if not m then return nil end
	-- entry: the outermost surface the line meets (a wound belongs on the jacket, not the shirt)
	local tri, u, v = BM.AnchorOuter(pose, bone, x, y, z, -dx, -dy, -dz, 6)
	if not tri then tri, u, v = BM.Anchor(pose, bone, x, y, z, 6) end
	if not tri then return nil end
	local ex, ey, ez, nx, ny, nz = pose:Point(tri, u, v)
	local cosI = max(-(dx * nx + dy * ny + dz * nz), 0.12)
	r.cosI = cosI
	-- an edged weapon: one gash where the blow fell
	if r.cut then
		-- (into the body rather than along it: the weapon goes much deeper than it is wide, by
		-- its own numbers, and the blow did not come flat)
		local deepK, wideK = (r.energy or 0) * 1.5, (r.diameter or 0) / 4
		local stab = deepK > 0 and wideK > 0 and deepK / wideK >= WR.stabRatio and cosI >= WR.stabCos
		return AddMark(src, r, stab and "stab" or "cut", tri, u, v, dx, dy, dz, rng), nil
	end
	if r.blunt then return AddMark(src, r, "blunt", tri, u, v, dx, dy, dz, rng), nil end
	-- exit: the surface the same line leaves through, seen from beyond the far side. A retained
	-- projectile has none
	local xtri, xu, xv
	if r.pen ~= WD.PEN_RETAINED then
		xtri, xu, xv = BM.AnchorOuter(pose, bone, ex, ey, ez, dx, dy, dz, WC.exitReach)
		if xtri == tri then xtri = nil end
	end
	local len
	if xtri then
		local qx, qy, qz = pose:Point(xtri, xu, xv)
		len = sqrt((qx - ex) ^ 2 + (qy - ey) ^ 2 + (qz - ez) ^ 2)
		r.trackLen = len
		-- a graze: flesh only, and the path never gets deep under the skin
		if r.pen == WD.PEN_SOFT and len < 12 and 0.5 * len * cosI < WR.grazeDepth and cosI < WR.grazeCos then
			r.graze = true
			local mt, mu, mv = BM.Anchor(pose, bone, (ex + qx) * 0.5, (ey + qy) * 0.5, (ez + qz) * 0.5, 5)
			if not mt then mt, mu, mv = tri, u, v end
			return AddMark(src, r, "graze", mt, mu, mv, dx, dy, dz, rng, len), nil
		end
	end
	local mk = AddMark(src, r, "entry", tri, u, v, dx, dy, dz, rng)
	local mx = xtri and AddMark(src, r, "exit", xtri, xu, xv, dx, dy, dz, rng) or nil
	return mk, mx
end

-- The cloth round a wound that has no mark of its own soaking up blood (cl_flowcore.lua FC.Feed).
-- rec: the wound's stand-in for a record; rec.soak (0..1) says how full the cloth is, rec.fedT
-- when blood last came. half: half-size of the patch when it is full (units).
function W.PlaceSoak(src, wd, rec, half)
	local m = src.mesh
	if not m or not wd.tri or wd.tri > m.nt or not (half > 0 and half < 100) then return nil end
	local gx, gy, gz, gmag = ABL.Gravity()
	local mk = AddMark(src, rec, "soak", wd.tri, wd.u, wd.v, gx / gmag, gy / gmag, gz / gmag,
		ABL.RNG(ABL.Hash(tostring(wd.id)) + 977), Clamp(half * 1.25, 0.9, 2.8))
	return mk
end

-- A projectile hit (E.OnHit). entry: world position, ev.dir: bullet direction.
function W.OnHit(src, body, ev, r, entry, exitPos, rng)
	-- (a projectile, or an edged weapon: a blunt one opens nothing)
	r.cut = r.class == ABL.Net.DMG_SLASH
	r.blunt = r.class == ABL.Net.DMG_CLUB
	if not IsValid(body) or not (r.bullet or r.cut or r.blunt) or r.pen == WD.PEN_ARMOR then return nil end
	-- (the mesh is still being built, or the source has not taken up this body yet: a fake ragdoll
	-- that appeared in the tick of the hit)
	if not src.mesh or src.body ~= body then
		W.Pending(src, body, ev.bone, ev.lpos, ev.dir, r)
		return nil
	end
	local dir = ev.dir
	-- (its own generator, the same one a mark placed later gets: the event's generator then runs
	-- the same sequence on every client, whether its surface model was ready or not)
	return W.PlaceWound(src, r, ev.bone, entry.x, entry.y, entry.z, dir.x, dir.y, dir.z, ABL.RNG(r.id * 7919 + 31))
end

-- Marks placed after the hit was processed (the body mesh was still being built): hand them to
-- the record and to the wounds already bleeding through it.
local function Attach(r, mk, mx)
	r.entryMark, r.exitMark = mk, mx
	for _, wd in ipairs(r.wds) do
		local use = (wd.role == "exit") and (mx or mk) or mk
		if use then
			wd.mark = use
			wd.tri, wd.anchorTried = nil, false
		end
	end
	local sl = r.src and r.src.pendingHits
	if sl then
		for _, h in ipairs(sl) do
			if h.rec == r then h.mark = (h.role == "exit") and (mx or mk) or mk end
		end
	end
end

-- The body mesh is still being built: remember the hit in bone space (position and bullet
-- direction: the body may fall and turn before the mark can be placed) and place it once ready.
function W.Pending(src, body, bone, lpos, dir, r)
	local M = body:GetBoneMatrix(bone)
	if not M then return end
	local ldir = WorldToLocal(dir, angle_zero, vector_origin, M:GetAngles())
	src.pendingMarks = src.pendingMarks or {}
	local p = src.pendingMarks
	if #p >= 8 then table.remove(p, 1) end
	p[#p + 1] = { bone = bone, lpos = Vector(lpos), ldir = ldir, rec = r, t = CurTime() }
end

-- The body's surface model is another one (cl_sources.lua): the marks on the old one go, and each
-- wound is marked again on the new one from its record, which knows where the projectile struck
-- and which way it went in the space of the bone it struck (W.Think places it once the new surface
-- model is there). A bone of that name the new model must have; else the wound has no mark there.
-- Soaked patches come back by themselves as their wounds bleed on (cl_flowcore.lua FC.Feed).
function W.Remesh(src)
	local marks = src.marks
	if marks then
		local body = src.body
		local now = CurTime()
		local seen = {}
		for i = 1, #marks do
			local mk = marks[i]
			mk.gone = true
			W.FreeMark(mk)
			local r = mk.rec
			if r and not r.soakOnly and not r.gone and not seen[r] then
				seen[r] = true
				r.entryMark, r.exitMark = nil, nil
				local bone = IsValid(body) and r.boneName and body:LookupBone(r.boneName) or nil
				if bone and r.lentry and r.ldir then
					src.pendingMarks = src.pendingMarks or {}
					local p = src.pendingMarks
					if #p < WC.maxPerSource then p[#p + 1] = { bone = bone, lpos = Vector(r.lentry), ldir = r.ldir, rec = r, t = now } end
				end
			end
		end
		src.marks = nil
	end
	for _, wd in pairs(src.wounds) do
		if wd.mark and wd.mark.gone then wd.mark = nil end
		if wd.soakMark and wd.soakMark.gone then wd.soakMark = nil end
	end
	for _, h in ipairs(src.pendingHits or {}) do
		if h.mark and h.mark.gone then h.mark = nil end
	end
end

function W.Think(src)
	local p = src.pendingMarks
	if not p or #p == 0 or not src.mesh or not IsValid(src.body) then return end
	local now = CurTime()
	for i = #p, 1, -1 do
		local q = p[i]
		if now - q.t > 20 or q.rec.gone then
			table.remove(p, i)
		else
			local b = src.pose:Bone(q.bone)
			if b then
				local lx, ly, lz = q.lpos.x, q.lpos.y, q.lpos.z
				local x = b[1] * lx + b[2] * ly + b[3] * lz + b[4]
				local y = b[5] * lx + b[6] * ly + b[7] * lz + b[8]
				local z = b[9] * lx + b[10] * ly + b[11] * lz + b[12]
				local l = q.ldir
				local dx, dy, dz = ABL.Norm(b[1] * l.x + b[2] * l.y + b[3] * l.z, b[5] * l.x + b[6] * l.y + b[7] * l.z, b[9] * l.x + b[10] * l.y + b[11] * l.z)
				local r = q.rec
				-- (no direction: the bone has been scaled away, a destroyed head carries no mark)
				if dx ~= 0 or dy ~= 0 or dz ~= 0 then
					local mk, mx = W.PlaceWound(src, r, q.bone, x, y, z, dx, dy, dz, ABL.RNG(r.id * 7919 + 31))
					Attach(r, mk, mx)
				end
				table.remove(p, i)
			end
		end
	end
end

------------------------------------------------------------------------------------------
-- Patch: the mesh triangles around the mark, with texture coordinates (bind space, built once).
-- The patch's own coordinates span the square of half-size mk.S around the wound along its
-- tangent (u) and bitangent (v); layers are placed inside it by their texture transforms.
------------------------------------------------------------------------------------------
-- Does triangle (u, v in half-units: the patch is the square -1..1) overlap that square?
local function TriHitsSquare(u1, v1, u2, v2, u3, v3)
	if min(u1, u2, u3) > 1 or max(u1, u2, u3) < -1 or min(v1, v2, v3) > 1 or max(v1, v2, v3) < -1 then return false end
	-- separating axes: the triangle's edge normals
	for e = 1, 3 do
		local ax, ay, bx, by
		if e == 1 then ax, ay, bx, by = u1, v1, u2, v2 elseif e == 2 then ax, ay, bx, by = u2, v2, u3, v3 else ax, ay, bx, by = u3, v3, u1, v1 end
		local nx, ny = by - ay, ax - bx
		local p1, p2, p3 = u1 * nx + v1 * ny, u2 * nx + v2 * ny, u3 * nx + v3 * ny
		local r = abs(nx) + abs(ny)
		if min(p1, p2, p3) > r or max(p1, p2, p3) < -r then return false end
	end
	return true
end

local function BuildPatch(mk, m)
	local cx, cy, cz = BM.BindPoint(m, mk.tri, mk.u, mk.v)
	local S = mk.S
	local nx, ny, nz, tx, ty, tz, bx, by, bz = mk.nx, mk.ny, mk.nz, mk.tx, mk.ty, mk.tz, mk.bx, mk.by, mk.bz
	local su = 1 / S
	local ids, us, vs, as = {}, {}, {}, {}
	local vnx, vny, vnz = m.nx, m.ny, m.nz
	local vx, vy, vz, t1, t2, t3 = m.vx, m.vy, m.vz, m.t1, m.t2, m.t3
	local n = 0
	local lu, lv = {}, {}
	-- Every triangle that reaches into the square belongs to the patch, however large it is (coarse
	-- meshes have triangles bigger than a wound): the layers are transparent towards their borders
	-- and clamped beyond them, so the patch's own outline never shows.
	for _, t in ipairs(BM.TrisNear(m, cx, cy, cz, S * 1.5 + 6)) do
		-- only surface facing the same way (not the far side of the neck, not inside the mouth), and
		-- close to the wound's surface (not a collar standing off the neck); the surface may curve
		-- away from the wound's plane with distance
		local fx, fy, fz = BM.BindNormal(m, t)
		if t == mk.tri or fx * nx + fy * ny + fz * nz > 0.15 then
			local ok = true
			for k = 1, 3 do
				local id = (k == 1 and t1[t]) or (k == 2 and t2[t]) or t3[t]
				local dx, dy, dz = vx[id] - cx, vy[id] - cy, vz[id] - cz
				local h = dx * nx + dy * ny + dz * nz
				local pu, pv = dx * tx + dy * ty + dz * tz, dx * bx + dy * by + dz * bz
				local lat = sqrt(pu * pu + pv * pv)
				lu[k], lv[k] = pu * su, pv * su
				if t ~= mk.tri and (h > S * 0.37 + lat * 0.15 or h < -(S * 0.52 + lat * 0.8)) then ok = false break end
			end
			if ok and TriHitsSquare(lu[1], lv[1], lu[2], lv[2], lu[3], lv[3]) then
				for k = 1, 3 do
					n = n + 1
					ids[n] = (k == 1 and t1[t]) or (k == 2 and t2[t]) or t3[t]
					us[n] = 0.5 + 0.5 * lu[k]
					vs[n] = 0.5 + 0.5 * lv[k]
					-- Layers are laid on flat (projected along the wound's normal): where the surface turns
					-- away from it they would smear over the turned-away triangles, so they fade out there
					local id = ids[n]
					as[n] = Clamp(((vnx[id] * nx + vny[id] * ny + vnz[id] * nz) - 0.2) / 0.45, 0, 1)
				end
			end
		end
	end
	mk.patch = { n = n, ids = ids, u = us, v = vs, a = as }
	-- does the patch follow one bone rigidly? (corners out in the transparent border may bend with
	-- another bone: nothing of the wound is drawn there)
	local rigid = m.inv[mk.bone] ~= nil
	local b1, w1 = m.b1, m.w1
	local inner = 0.36 * max(1, 2.4 / S)
	for c = 1, n do
		local id = ids[c]
		if (b1[id] ~= mk.bone or w1[id] < 0.97) and abs(us[c] - 0.5) < inner and abs(vs[c] - 0.5) < inner then rigid = false break end
	end
	mk.rigid = rigid
end

------------------------------------------------------------------------------------------
-- The patch as a static mesh in the space of the mark's bone
------------------------------------------------------------------------------------------
local vec = Vector()
local function V(x, y, z, u, v, a)
	vec:SetUnpacked(x, y, z)
	mesh.Position(vec)
	mesh.TexCoord(0, u, v)
	-- (opacity through colour and alpha both: right for the blended and for the multiplied layers)
	local c = 255 * a ^ (1 / 2.2)
	mesh.Color(c, c, c, 255 * a)
	mesh.AdvanceVertex()
end

local function FreePatch(mk)
	if mk.mesh then mk.mesh:Destroy() mk.mesh = nil end
end
-- (a mark that goes: its patch and its recess. A patch that is only baked again keeps the recess.)
local function FreeMark(mk)
	FreePatch(mk)
	FreeCavity(mk)
end
W.FreeMark = FreeMark

local OFFSET = 0.06
-- Rigid skin: from the bind pose, once. Bending skin: from the current pose, and again whenever
-- the skin has moved under it (W.Draw checks a few of its corners).
local function Bake(mk, m, pose)
	FreePatch(mk)
	local P = mk.patch
	local ids, us, vs, as = P.ids, P.u, P.v, P.a
	local ms
	if mk.rigid then
		local inv = m.inv[mk.bone]
		local ox, oy, oz = mk.nx * OFFSET, mk.ny * OFFSET, mk.nz * OFFSET
		local vx, vy, vz = m.vx, m.vy, m.vz
		ms = Mesh()
		mesh.Begin(ms, MATERIAL_TRIANGLES, P.n / 3)
		for c = 1, P.n do
			local id = ids[c]
			local x, y, z = vx[id] + ox, vy[id] + oy, vz[id] + oz
			V(inv[1] * x + inv[2] * y + inv[3] * z + inv[4], inv[5] * x + inv[6] * y + inv[7] * z + inv[8], inv[9] * x + inv[10] * y + inv[11] * z + inv[12], us[c], vs[c], as[c])
		end
		mesh.End()
		if mk.cav then
			-- the wound's space on its bone, from the bind pose
			local cx, cy, cz = BM.BindPoint(m, mk.tri, mk.u, mk.v)
			local function Rot(x, y, z) return inv[1] * x + inv[2] * y + inv[3] * z, inv[5] * x + inv[6] * y + inv[7] * z, inv[9] * x + inv[10] * y + inv[11] * z end
			local tx, ty, tz = Rot(mk.tx, mk.ty, mk.tz)
			local bx, by, bz = Rot(mk.bx, mk.by, mk.bz)
			local nx, ny, nz = Rot(mk.nx, mk.ny, mk.nz)
			SetFrame(mk, inv[1] * cx + inv[2] * cy + inv[3] * cz + inv[4], inv[5] * cx + inv[6] * cy + inv[7] * cz + inv[8], inv[9] * cx + inv[10] * cy + inv[11] * cz + inv[12],
				tx, ty, tz, bx, by, bz, nx, ny, nz)
		end
	else
		local inv = pose:BoneInv(mk.bone)
		if not inv then return false end
		local _, _, _, anx, any, anz = pose:SkinPoint(mk.anchor)
		local ox, oy, oz = anx * OFFSET, any * OFFSET, anz * OFFSET
		ms = Mesh()
		mesh.Begin(ms, MATERIAL_TRIANGLES, P.n / 3)
		for c = 1, P.n do
			local x, y, z = pose:Vertex(ids[c])
			x, y, z = x + ox, y + oy, z + oz
			V(inv[1] * x + inv[2] * y + inv[3] * z + inv[4], inv[5] * x + inv[6] * y + inv[7] * z + inv[8], inv[9] * x + inv[10] * y + inv[11] * z + inv[12], us[c], vs[c], as[c])
		end
		mesh.End()
		-- three corners to watch
		local s = mk.sample
		if not s then s = {} mk.sample = s end
		for k = 1, 3 do
			local c = (k == 1 and 1) or (k == 2 and max(1, math.floor(P.n / 2))) or P.n
			local x, y, z = pose:Vertex(ids[c])
			local o = (k - 1) * 4
			s[o + 1] = ids[c]
			s[o + 2] = inv[1] * x + inv[2] * y + inv[3] * z + inv[4]
			s[o + 3] = inv[5] * x + inv[6] * y + inv[7] * z + inv[8]
			s[o + 4] = inv[9] * x + inv[10] * y + inv[11] * z + inv[12]
		end
		if mk.cav then
			-- The wound's space on its bone as the skin lies now: at the wound's place on the
			-- skin, its normal the skin's, its tangent the mark's own carried by the bone and
			-- put square to that normal.
			local wx, wy, wz, wnx, wny, wnz = pose:SkinPoint(mk.anchor)
			local bw = pose:Bone(mk.bone)
			local bi = m.inv[mk.bone]
			local tx, ty, tz = mk.tx, mk.ty, mk.tz
			if bw and bi then
				-- bind -> the bone's own space -> the world, by the rotations alone
				local lx, ly, lz = bi[1] * tx + bi[2] * ty + bi[3] * tz, bi[5] * tx + bi[6] * ty + bi[7] * tz, bi[9] * tx + bi[10] * ty + bi[11] * tz
				tx, ty, tz = bw[1] * lx + bw[2] * ly + bw[3] * lz, bw[5] * lx + bw[6] * ly + bw[7] * lz, bw[9] * lx + bw[10] * ly + bw[11] * lz
			end
			local dn = tx * wnx + ty * wny + tz * wnz
			tx, ty, tz = ABL.Norm(tx - wnx * dn, ty - wny * dn, tz - wnz * dn)
			if tx == 0 and ty == 0 and tz == 0 then tx, ty, tz = ABL.Perp(wnx, wny, wnz) end
			local bx, by, bz = wny * tz - wnz * ty, wnz * tx - wnx * tz, wnx * ty - wny * tx
			local function Rot(x, y, z) return inv[1] * x + inv[2] * y + inv[3] * z, inv[5] * x + inv[6] * y + inv[7] * z, inv[9] * x + inv[10] * y + inv[11] * z end
			local t1, t2, t3 = Rot(tx, ty, tz)
			local b1, b2, b3 = Rot(bx, by, bz)
			local n1, n2, n3 = Rot(wnx, wny, wnz)
			SetFrame(mk, inv[1] * wx + inv[2] * wy + inv[3] * wz + inv[4], inv[5] * wx + inv[6] * wy + inv[7] * wz + inv[8], inv[9] * wx + inv[10] * wy + inv[11] * wz + inv[12],
				t1, t2, t3, b1, b2, b3, n1, n2, n3)
		end
	end
	mk.mesh = ms
	mk.bakeT = RealTime()
	return true
end

-- Has bending skin moved under the baked patch (more than half a millimetre or so)?
local function Drifted(mk, pose)
	local inv = pose:BoneInv(mk.bone)
	local s = mk.sample
	if not inv or not s then return false end
	for o = 0, 8, 4 do
		local x, y, z = pose:Vertex(s[o + 1])
		local lx = inv[1] * x + inv[2] * y + inv[3] * z + inv[4]
		local ly = inv[5] * x + inv[6] * y + inv[7] * z + inv[8]
		local lz = inv[9] * x + inv[10] * y + inv[11] * z + inv[12]
		if abs(lx - s[o + 2]) + abs(ly - s[o + 3]) + abs(lz - s[o + 4]) > 0.05 then return true end
	end
	return false
end

------------------------------------------------------------------------------------------
-- Drawing (from ABL.Flow.DrawSource, before the body blood so it runs over the wound)
------------------------------------------------------------------------------------------
local colVec = Vector()
local boneMat = Matrix()
local texMat = Matrix()
local GAMMA = 1 / 2.2

-- Place a layer inside the patch: texture transform for half-size h, stretch st along the tangent,
-- rotation rot, offset (ox, oy) in units.
local function PlaceLayer(mat, S, l)
	local c, s = cos(l.rot), sin(l.rot)
	local su, sv = S / (l.half * l.st), S / l.half
	local oxp, oyp = l.ox / (2 * l.half * l.st), l.oy / (2 * l.half)
	texMat:SetField(1, 1, c * su)
	texMat:SetField(1, 2, -s * sv)
	texMat:SetField(1, 4, 0.5 - 0.5 * c * su + 0.5 * s * sv - c * oxp + s * oyp)
	texMat:SetField(2, 1, s * su)
	texMat:SetField(2, 2, c * sv)
	texMat:SetField(2, 4, 0.5 - 0.5 * s * su - 0.5 * c * sv - s * oxp - c * oyp)
	mat:SetMatrix("$basetexturetransform", texMat)
end

------------------------------------------------------------------------------------------
-- The recess, drawn (see the head of this file). Called with the bone's matrix pushed.
------------------------------------------------------------------------------------------
local maskMats = {}
local function MaskMat(name)
	local mt = maskMats[name]
	if mt then return mt end
	-- (alpha-tested: a pixel is written, into the stencil buffer, where the opening is; its
	-- colour is kept out of the picture by the blend it is drawn with)
	mt = CreateMaterial("abl_wm_" .. name, "UnlitGeneric", { ["$basetexture"] = "advancedblood/wounds/" .. name .. "_m", ["$alphatest"] = 1, ["$alphatestreference"] = 0.5, ["$nocull"] = 1 })
	maskMats[name] = mt
	return mt
end
local wallMat, bloodMat, sheenMat
local function CavMats()
	if wallMat then return end
	wallMat = CreateMaterial("abl_wcav_wall", "UnlitGeneric", { ["$basetexture"] = "advancedblood/wounds/tissue", ["$vertexcolor"] = 1 })
	bloodMat = CreateMaterial("abl_wcav_blood", "UnlitGeneric", { ["$basetexture"] = "color/white", ["$vertexcolor"] = 1 })
	sheenMat = CreateMaterial("abl_wcav_sheen", "UnlitGeneric", { ["$basetexture"] = "color/white", ["$vertexcolor"] = 1, ["$additive"] = 1 })
end
W.CavMats = CavMats

-- One stencil value for each recess of a frame (two openings that overlap do not show each
-- other's inside). The buffer is cleared before the first of a frame, and again should a
-- frame have more recesses than there are values.
local stFrame, stRef = -1, 0
local function NextRef()
	local fn = FrameNumber()
	if fn ~= stFrame or stRef >= 250 then
		stFrame, stRef = fn, 0
		render.ClearStencil()
	end
	stRef = stRef + 1
	return stRef
end

local levelMat = Matrix()
local levelVec, levelScale = Vector(), Vector()
W.cavFlip = false            -- (for a scene: the wall's triangles culled the other way round)
W.cavDrawn = 0
W.layersDrawn = 0            -- (for a scene: layers painted on skin since it was last set to nought)
local function DrawCavity(mk, ms, S, lr, lg, lb, wet, clot, dry, gk, film)
	local c = mk.cav
	CavMats()
	if not c.mesh then BakeCavity(mk) end
	if not c.mesh or not mk.frame then return end
	local ref = NextRef()
	-- 1. the opening, into the stencil buffer: where this piece of skin is seen
	render.SetStencilEnable(true)
	render.SetStencilWriteMask(255)
	render.SetStencilTestMask(255)
	render.SetStencilReferenceValue(ref)
	render.SetStencilCompareFunction(STENCIL_ALWAYS)
	render.SetStencilPassOperation(STENCIL_REPLACE)
	render.SetStencilFailOperation(STENCIL_KEEP)
	render.SetStencilZFailOperation(STENCIL_KEEP)
	local mm = MaskMat(mk.holeName)
	PlaceLayer(mm, S, mk.hole)
	render.SetMaterial(mm)
	render.OverrideBlend(true, BLEND_ZERO, BLEND_ONE, BLENDFUNC_ADD)
	ms:Draw()
	render.OverrideBlend(false)
	-- 2. in it: the wound's dark ground, and nothing in front any more
	render.SetStencilCompareFunction(STENCIL_EQUAL)
	render.SetStencilPassOperation(STENCIL_KEEP)
	render.ClearBuffersObeyStencil(min(255, 34 * lr), min(255, 7 * lg), min(255, 7 * lb), 255, true)
	-- 3. the recess through it
	cam.PushModelMatrix(mk.frame, true)
	render.CullMode(W.cavFlip and MATERIAL_CULLMODE_CW or MATERIAL_CULLMODE_CCW)
	-- (a fresh wound's wall is wet with blood: redder; dried, duller and darker)
	local wk = film * (1 - dry)
	colVec:SetUnpacked(min(1.5, lr * (1.05 - 0.18 * dry)), min(1.5, lg * (0.98 - 0.16 * wk - 0.14 * dry)), min(1.5, lb * (0.98 - 0.16 * wk - 0.14 * dry)))
	wallMat:SetVector("$color", colVec)
	render.SetMaterial(wallMat)
	c.mesh:Draw()
	-- the blood standing in it: high and wet while the wound bleeds, sunk, dark and dull once
	-- it has set (a graze holds a film at the bottom of its trench)
	local fresh = film * (1 - 0.6 * dry)
	local s = (c.graze and 0.62 or (mk.kind == "cut" and 0.34 or 0.20)) + 0.26 * dry + 0.10 * clot * (1 - dry)
	if fresh > 0.05 or clot > 0.1 then
		local rho = RhoAt(c.prof, s) * 0.99
		levelMat:Identity()
		levelVec:SetUnpacked(c.ox + c.kx * c.D * s, c.oy + c.ky * c.D * s, -c.D * s)
		levelMat:SetTranslation(levelVec)
		levelScale:SetUnpacked(rho, rho, 1)
		levelMat:SetScale(levelScale)
		cam.PushModelMatrix(levelMat, true)
		-- (fresh blood in a hole is seen by what little light comes back out of it: a deep
		-- red that is nearly black, browner and lighter as it dries)
		local k = 1 - 0.35 * clot
		colVec:SetUnpacked(min(1, lr * (0.34 * k + 0.06 * dry)), min(1, lg * (0.022 + 0.035 * dry)), min(1, lb * (0.026 + 0.02 * dry)))
		bloodMat:SetVector("$color", colVec)
		render.SetMaterial(bloodMat)
		c.blood:Draw()
		-- what the wet surface gives back of the light: a sheen, never a white spot
		local g = gk * 1.6
		if g > 0.01 then
			colVec:SetUnpacked(g * lr, g * lg, g * lb)
			sheenMat:SetVector("$color", colVec)
			render.SetMaterial(sheenMat)
			c.blood:Draw()
		end
		cam.PopModelMatrix()
	end
	render.CullMode(MATERIAL_CULLMODE_CCW)
	cam.PopModelMatrix()
	render.SetStencilEnable(false)
	W.cavDrawn = W.cavDrawn + 1
end

-- What is drawn on the skin after the wounds (the blood that runs over the body) keeps out of
-- the openings: drawn across one it lay over the hole like a lid, where it comes out of the
-- hole and runs over its lower lip. Every opening of this frame has a value in the stencil
-- buffer and the rest of it is nought: W.KeepOut(true) lets only that rest be drawn on.
function W.KeepOut(on)
	if not on then render.SetStencilEnable(false) return end
	render.SetStencilEnable(true)
	render.SetStencilWriteMask(0)
	render.SetStencilTestMask(255)
	render.SetStencilReferenceValue(0)
	render.SetStencilCompareFunction(STENCIL_EQUAL)
	render.SetStencilPassOperation(STENCIL_KEEP)
	render.SetStencilFailOperation(STENCIL_KEEP)
	render.SetStencilZFailOperation(STENCIL_KEEP)
end

local patchFrame = -1
function W.Draw(src, pose, off)
	local marks = src.marks
	local frame = FrameNumber()
	local m = src.mesh
	if not marks or #marks == 0 or not m then return end
	local body = src.body
	local R = ABL.Render
	local now, rt = CurTime(), RealTime()
	local ex, ey, ez = L.eyeX, L.eyeY, L.eyeZ
	local drawn = 0
	local deep = C.cl.wound3d:GetBool()
	local cut = false
	if not C.cl.woundMarks:GetBool() then return false end
	local drawDist, cavDist = C.cl.woundDist:GetFloat(), C.cl.wound3dDist:GetFloat()
	local inten = Clamp(C.cl.woundIntensity:GetFloat(), 0.4, 1.6)
	local dbg = C.cl.woundDebug:GetBool()
	-- abl_wound_life: a mark older than that fades and goes (the blood a cloth has soaked up
	-- has its own drying, and comes again for as long as its wound bleeds)
	local life, old = C.cl.woundLife:GetFloat(), false
	R.EndFilter()
	for i = 1, #marks do
		local mk = marks[i]
		local fade = 1
		if life > 0 and mk.kind ~= "soak" then
			fade = Clamp((life - (now - mk.born)) / WC.lifeFade, 0, 1)
			if fade <= 0 then old = true end
		end
		if mk.m == m and fade > 0 then
			-- a limb that is not drawn (a destroyed head) takes its wounds with it
			if now > (mk.hidT or 0) then
				mk.hidT = now + 0.5
				mk.hidden = ABL.ZC.BoneHidden(body, mk.bone) or (body.headexploded and ABL.ZC.BoneLimb(body:GetBoneName(mk.bone) or "") == "head")
			end
			if not mk.hidden then
				-- (one new patch per frame: several wounds made at once appear over as many frames
				-- instead of costing one long frame)
				if not mk.patch and patchFrame ~= frame then
					patchFrame = frame
					BuildPatch(mk, m)
				end
				local P = mk.patch
				if P and P.n >= 3 then
					local ax, ay, az, anx, any, anz = pose:SkinPoint(mk.anchor)
					local vx, vy, vz = ex - ax, ey - ay, ez - az
					local d = sqrt(vx * vx + vy * vy + vz * vz)
					-- (a mark facing away from the camera is behind its own body part)
					if d < drawDist and vx * anx + vy * any + vz * anz > -0.3 * d then
						if not mk.mesh or (not mk.rigid and rt - mk.bakeT > 0.07 and Drifted(mk, pose)) then
							if Bake(mk, m, pose) then ABL.Prof.Count("mark bakes", 1) end
						end
						local ms = mk.mesh
						local ok = ms ~= nil
						if ok then
							if body.CopyBoneMatrix then
								body:CopyBoneMatrix(mk.bone, boneMat)
							else
								local bm = body:GetBoneMatrix(mk.bone)
								if bm then boneMat = bm else ok = false end
							end
						end
						if ok then
							local r = mk.rec
							local lr, lg, lb = R.Light(ax + anx * 2, ay + any * 2, az + anz * 2)
							-- (a soak-only mark dries once no blood has come for a while)
							if r.soakOnly then r.dry = Clamp((now - (r.fedT or now) - 30) / 120, 0, 1) end
							local wet, clot, dry, bruise = r.wet, r.clot, r.dry, r.bruise
							-- blood around the wound darkens as it sets and dries
							local dk = 1 - 0.22 * clot - 0.28 * dry
							local cosT = (vx * anx + vy * any + vz * anz) / max(d, 1)
							-- (the reflection of a small wet patch: never a white sticker)
							local gk = (wet ^ 1.5) * (1 - 0.8 * clot) * min(WC.gloss, 0.05 + 0.6 * C.Ground.sheen * R.Fresnel(cosT))
							-- the film is there within a second, and gives way to the crust as it dries
							local film = Clamp((now - mk.born) / 0.8, 0, 1) * (1 - 0.75 * dry)
							local crust = Clamp((clot - 0.25) / 0.6, 0, 1)
							-- blood in the cloth: grows with what has come out of the wound
							local soak = r.soakOnly and r.soak or Clamp(0.3 + r.released / 14, 0, 1)
							local detailOK = d < WC.detailDist
							local layers, S = mk.layers, mk.S
							cam.PushModelMatrix(boneMat)
							for k = 1, #layers do
								local l = layers[k]
								local kind = l.kind
								local a = l.a * fade
								if l.detail and not detailOK then
									a = 0
								elseif kind == K_BRUISE then
									a = a * bruise * inten
								elseif kind == K_FLUSH then
									a = a * (1 - 0.75 * bruise) * Clamp((now - mk.born) / 0.5, 0, 1) * inten
								elseif kind == K_BLOOD then
									a = a * film * inten
								elseif kind == K_GLOSS then
									a = (d < 600) and a * gk or 0
								elseif kind == K_CRUST then
									a = a * crust
								elseif kind == K_SOAK or kind == K_SOAKB then
									if r.soakOnly then
										-- (from nothing: it starts as a spot at the opening)
										a = a * min(1, soak * 5)
										l.half = l.half0 * (0.22 + 0.78 * sqrt(soak))
									else
										a = a * (0.45 + 0.55 * soak)
										l.half = l.half0 * (0.55 + 0.45 * soak)
									end
								end
								if a > 0.02 then
									local mat = l.mat
									PlaceLayer(mat, S, l)
									if l.pass == PASS_FILTER then
										-- multiplied over the lit surface: opacity through colour and alpha.
										-- Dried blood in cloth is browner and a little lighter than wet
										local f = min(a, 1)
										colVec:SetUnpacked(min(1, f * (1 + 0.5 * dry)) ^ GAMMA, min(1, f * (1 + 0.9 * dry)) ^ GAMMA, min(1, f * (1 + 0.5 * dry)) ^ GAMMA)
										mat:SetVector("$color", colVec)
										mat:SetFloat("$alpha", f)
										render.SetMaterial(mat)
										R.BeginFilter()
										ms:Draw()
										R.EndFilter()
									elseif l.pass == PASS_GLOSS then
										colVec:SetUnpacked(a * lr, a * lg, a * lb)
										mat:SetVector("$color", colVec)
										render.SetMaterial(mat)
										ms:Draw()
									elseif kind == K_SOAKB then
										-- (what blood in cloth scatters back: a dark red, browner as it dries)
										local t = 1 - 0.3 * dry
										colVec:SetUnpacked(min(1, lr * 0.5 * t), min(1, lg * (0.07 + 0.05 * dry) * t), min(1, lb * 0.08 * t))
										mat:SetVector("$color", colVec)
										mat:SetFloat("$alpha", min(a, 1))
										render.SetMaterial(mat)
										ms:Draw()
									else
										local t = ((kind == K_BLOOD or kind == K_CRUST) and dk or 1) * (l.tint or 1)
										colVec:SetUnpacked(min(1.3, lr * (kind == K_BLOOD and mk.tone or 1) * t * (l.cr or 1)), min(1.3, lg * t * (l.cg or 1)), min(1.3, lb * t * (l.cb or 1)))
										mat:SetVector("$color", colVec)
										mat:SetFloat("$alpha", min(a, 1))
										render.SetMaterial(mat)
										ms:Draw()
									end
									drawn = drawn + 1
								end
							end
							-- the wound's inside, through its opening (after everything that is
							-- painted on the skin: it is cut out of that)
							if deep and mk.cav and d < cavDist and fade >= 1 then
								DrawCavity(mk, ms, S, lr, lg, lb, wet, clot, dry, gk, film)
								cut = true
							end
							cam.PopModelMatrix()
							-- abl_wound_debug: the wound's place and the skin's normal there
							if dbg then
								render.SetColorMaterial()
								local p0 = Vector(ax, ay, az)
								render.DrawLine(p0, Vector(ax + anx * 3, ay + any * 3, az + anz * 3), Color(60, 255, 60), false)
								render.DrawWireframeSphere(p0, 0.25, 6, 6, Color(255, 220, 40), false)
							end
						end
					end
				end
			end
		end
	end
	if drawn > 0 then ABL.Prof.Count("mark layers", drawn) end
	W.layersDrawn = W.layersDrawn + drawn
	if old then
		for i = #marks, 1, -1 do
			local mk = marks[i]
			if mk.kind ~= "soak" and now - mk.born >= life then mk.gone = true W.FreeMark(mk) table.remove(marks, i) end
		end
	end
	-- (true: an opening was cut in this frame; see W.KeepOut)
	return cut
end

function W.Clear(src)
	for _, mk in ipairs(src.marks or {}) do
		mk.gone = true
		FreeMark(mk)
	end
	src.marks = nil
	src.pendingMarks = nil
end

------------------------------------------------------------------------------------------
-- Commands (the console; all of them act on this client's picture only)
--   abl_wound_report        how many wounds are kept and drawn
--   abl_wound_clear         removes every wound mark and record (the blood stays: abl_clear)
--   abl_wound_test [kind]   a wound for looking at, on the character under the crosshair:
--                           bullet, through, cut, stab or blunt. It is made here and nowhere
--                           else: no damage is done, nobody else sees it, nothing bleeds on.
------------------------------------------------------------------------------------------
function W.Report()
	local recs, marks, withCav, built, patches = #ABL.Wounds.list, 0, 0, 0, 0
	local kinds = {}
	for _, src in ipairs(ABL.Sources.list) do
		for _, mk in ipairs(src.marks or {}) do
			marks = marks + 1
			kinds[mk.kind] = (kinds[mk.kind] or 0) + 1
			if mk.cav then withCav = withCav + 1 if mk.cav.mesh then built = built + 1 end end
			if mk.mesh then patches = patches + 1 end
		end
	end
	local parts = {}
	for k, n in pairs(kinds) do parts[#parts + 1] = n .. " " .. k end
	table.sort(parts)
	return recs, marks, withCav, built, patches, table.concat(parts, ", ")
end

concommand.Add("abl_wound_report", function()
	local recs, marks, withCav, built, patches, kinds = W.Report()
	ABL.Print("wounds: %d record(s); %d mark(s) on bodies (%s); %d with a recess, %d of those built; %d patch mesh(es) held", recs, marks, kinds ~= "" and kinds or "none", withCav, built, patches)
	local life = C.cl.woundLife:GetFloat()
	ABL.Print("settings: marks %s, recess %s, at most %d a character, drawn to %d units, recess to %d units, intensity %.2f, kept %s", tostring(C.cl.woundMarks:GetBool()), tostring(C.cl.wound3d:GetBool()),
		C.cl.woundMax:GetInt(), C.cl.woundDist:GetInt(), C.cl.wound3dDist:GetInt(), C.cl.woundIntensity:GetFloat(),
		life > 0 and string.format("for %d s", life) or "as long as the body is there")
end, nil, "AdvancedBlood: how many wounds are kept and drawn on this client")

concommand.Add("abl_wound_clear", function()
	for _, src in ipairs(ABL.Sources.list) do W.Clear(src) end
	ABL.Wounds.Clear()
	ABL.Print("wound marks and records cleared (on this client)")
end, nil, "AdvancedBlood: removes every wound mark on this client")

local TEST = {
	bullet  = function(N) return { class = N.DMG_BULLET, pen = WD.PEN_RETAINED, energy = 2, velocity = 1, diameter = 6, damage = 30 } end,
	through = function(N) return { class = N.DMG_BULLET, pen = WD.PEN_THROUGH, energy = 4, velocity = 3, diameter = 5, damage = 60 } end,
	cut     = function(N) return { class = N.DMG_SLASH, pen = WD.PEN_SOFT, energy = 3, velocity = 0, diameter = 12, damage = 40 } end,
	stab    = function(N) return { class = N.DMG_SLASH, pen = WD.PEN_SOFT, energy = 7, velocity = 0, diameter = 4, damage = 30 } end,
	blunt   = function(N) return { class = N.DMG_CLUB, pen = WD.PEN_SOFT, energy = 2, velocity = 0, diameter = 8, damage = 28 } end,
}
concommand.Add("abl_wound_test", function(_, _, args)
	local make = TEST[string.lower(args[1] or "bullet")]
	if not make then ABL.Print("abl_wound_test: one of bullet, through, cut, stab, blunt") return end
	local eye, fwd = EyePos(), EyeAngles():Forward()
	local tr = util.TraceLine({ start = eye, endpos = eye + fwd * 800, filter = LocalPlayer(), mask = MASK_SHOT })
	local ent = tr.Entity
	if not tr.Hit or not IsValid(ent) or not (ent:IsPlayer() or ent:IsNPC() or ent:IsRagdoll()) then
		ABL.Print("abl_wound_test: no character under the crosshair")
		return
	end
	-- the bone of what was hit, and the place in that bone's space
	local bone
	if ent:IsRagdoll() then bone = ent:TranslatePhysBoneToBone(tr.PhysicsBone or 0)
	elseif tr.HitBox then bone = ent:GetHitBoxBone(tr.HitBox, ent:GetHitboxSet() or 0) end
	local bm = bone and ent:GetBoneMatrix(bone)
	if not bm then ABL.Print("abl_wound_test: that place has no bone to put a wound on") return end
	local ev = make(ABL.Net)
	ev.body, ev.owner = ent, ent:IsPlayer() and ent or nil
	ev.bone = bone
	ev.lpos = WorldToLocal(tr.HitPos, angle_zero, bm:GetTranslation(), bm:GetAngles())
	ev.dir = Vector(fwd.x, fwd.y, fwd.z)
	ev.bleed, ev.hitgroup, ev.range, ev.flags = 0, tr.HitGroup or 0, WD.RANGE_DISTANT, 0
	ev.seed = math.random(0, 65535)
	local ok, err = pcall(ABL.Emission.OnHit, ev)
	if not ok then ABL.Print("abl_wound_test: %s", tostring(err)) return end
	ABL.Print("abl_wound_test: a %s on %s (this client only; nothing was damaged)", args[1] or "bullet", tostring(ent))
end, nil, "AdvancedBlood: a wound for looking at on the character under the crosshair (bullet, through, cut, stab, blunt); this client only, no damage")
