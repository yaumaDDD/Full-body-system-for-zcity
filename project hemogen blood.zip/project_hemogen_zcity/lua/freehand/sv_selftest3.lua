-- Test scenes of the free-hand module, third part: blows (developer tool; see sv_selftest.lua
-- for when these exist at all, and docs/FREEHAND_TESTING.md for what they measure).

local FH = FreeHand
if not (istable(ABL) and istable(ABL.SelfTest)) or not FH.Test then return end
local S = ABL.SelfTest
local Log, Wait = S.Log, S.Wait
local C, M, B, Sim = FH.Config, FH.Math, FH.Body, FH.Sim
local T = FH.Test
local Ask, Check, Tally, Play, Fighter, WaitFor, Rel = T.Ask, T.Check, T.Tally, T.Play, T.Fighter, T.WaitFor, T.Rel
local V = Vector
local sqrt, abs = math.sqrt, math.abs

------------------------------------------------------------------------------------------
-- A hand sent to a place in the world, by the mouse movements that take it there (a scene has
-- no mouse: it works out the counts a player would have moved). speed: counts a tick at most.
-- Returns a function that says whether the hand's target has arrived.
------------------------------------------------------------------------------------------
local function Seek(bot, i, pos, speed, other)
	local st = FH.State(bot)
	local done = false
	local a = C.Arm
	FH.TestInput[bot] = function()
		local h = st.h[i]
		local tf, tl, tu = B.ToAim(st, pos.x, pos.y, pos.z)
		local az1, el1, ex1 = B.LimitPolar(B.TargetPolar(i, tf, tl, tu))
		local az0, el0, ex0 = B.TargetPolar(i, h.tf, h.tl, h.tu)
		local mx = (az1 - az0) * B.SIDE[i] / a.degPerCount
		local my = -(el1 - el0) / a.degPerCount
		local out = (ex1 - ex0) / a.unitsPerCount
		local t = { L = i == 1 or other == true, R = i == 2 or other == true, mx = 0, my = 0 }
		if abs(mx) < 2 and abs(my) < 2 and abs(out) < 2 then done = true return t end
		-- (the reach has its own key: the angles and the reach take turns)
		if abs(out) >= 2 and (abs(mx) + abs(my) < 4 or st.tick % 2 == 0) then
			t.depth = true
			t.my = math.Round(M.Clamp(-out, -speed, speed))
		else
			t.mx, t.my = math.Round(M.Clamp(mx, -speed, speed)), math.Round(M.Clamp(my, -speed, speed))
		end
		return t
	end
	return function() return done end
end
T.Seek = Seek

-- Where the weight of a ragdoll is, and how fast that goes.
function T.RagMiddle(rag)
	local m, p, vel = 0, Vector(0, 0, 0), Vector(0, 0, 0)
	for n = 0, rag:GetPhysicsObjectCount() - 1 do
		local phys = rag:GetPhysicsObjectNum(n)
		if IsValid(phys) then
			local k = phys:GetMass()
			m, p, vel = m + k, p + phys:GetPos() * k, vel + phys:GetVelocity() * k
		end
	end
	if m <= 0 then return rag:GetPos(), Vector(0, 0, 0) end
	return p / m, vel / m
end

-- What the blows of a scene were: every contact that was not mere pressing, as it came.
local blows, heads, bodies, blocks = {}, {}, {}, {}
local function Listen()
	blows, heads, bodies, blocks = {}, {}, {}, {}
	FH.OnBlow = function(ply, c)
		if c.pressing then return end
		blows[#blows + 1] = { kind = c.kind, hand = c.hand, idx = c.idx, speed = c.speed, closing = c.closing, impulse = c.impulse, energy = c.energy, edge = c.edge,
			hitgroup = c.hitgroup, soft = c.soft, block = c.block, target = c.target, ent = c.ent, dx = c.dx, dy = c.dy, dz = c.dz, x = c.x, y = c.y, z = c.z }
	end
	FH.OnHead = function(target, attacker, c, sev, daze, dv, dOmega) heads[#heads + 1] = { sev = sev, daze = daze, dv = dv, dOmega = dOmega, target = target } end
	FH.OnBody = function(target, attacker, c, bal) bodies[#bodies + 1] = { bal = bal, impulse = c.impulse, target = target } end
	FH.OnBlock = function(ply, other, c) if not c.pressing then blocks[#blocks + 1] = { kind = c.block, arm = c.blockArm, energy = c.energy, other = other } end end
end
local function Deaf() FH.OnBlow, FH.OnHead, FH.OnBody, FH.OnBlock = nil, nil, nil, nil end

-- The strongest blow on a target since Listen().
local function Strongest(target, hitgroup)
	local best
	for _, b in ipairs(blows) do
		if (not target or b.target == target) and (not hitgroup or b.hitgroup == hitgroup) and (not best or b.energy > best.energy) then best = b end
	end
	return best
end

local function Org(ply) return istable(ply.organism) and ply.organism or {} end
local function Num(v) return tonumber(v) or 0 end

-- Somebody to hit: a bot that stands and does nothing.
local function Victim(p, yaw)
	local bot = S.NewBot()
	if not IsValid(bot) then return nil end
	Wait(0.8)
	bot:Spawn()
	Wait(0.6)
	S.Place(bot, p, yaw)
	T.Aim(bot, 0, yaw)
	for class in pairs(C.Classes) do
		if class ~= "weapon_hands_sh" and bot:HasWeapon(class) then bot:StripWeapon(class) end
	end
	if bot:HasWeapon("weapon_hands_sh") then bot:SelectWeapon("weapon_hands_sh") end
	Wait(0.5)
	local w = bot:GetActiveWeapon()
	if IsValid(w) and w.SetFists then w:SetFists(false) end
	return bot
end

-- Back on its feet, whole, and with a clear head.
local function Restore(bot, p, yaw)
	-- (spawned anew: Z-City makes it a new organism then, without the pain, the shock and the
	-- unconsciousness of what the scene did to it before)
	if IsValid(bot.FakeRagdoll) and hg and hg.FakeUp then hg.FakeUp(bot, true, true) end
	bot:Spawn()
	Wait(0.5)
	S.Place(bot, p, yaw)
	T.Aim(bot, 0, yaw)
	local w = bot:GetActiveWeapon()
	if IsValid(w) and w.SetFists and w.GetFists and w:GetFists() then w:SetFists(false) end
	local v = FH.React.State(bot)
	v.daze, v.bal, v.koUntil, v.weakUntil = 0, 0, 0, 0
	-- (what the neurotrauma module made of the blows before is not this test's business)
	if istable(NeuroTrauma) and NeuroTrauma.Reset then NeuroTrauma.Reset(bot) end
	local org = Org(bot)
	-- (nor what Z-City's own stun still holds)
	if org.consciousness then org.consciousness = 1 end
	if org.stun then org.stun = 0 end
	if org.lightstun then org.lightstun = 0 end
	Wait(0.4)
	if IsValid(bot.FakeRagdoll) then S.Place(bot, p, yaw) end
	if org.consciousness then org.consciousness = 1 end
	Wait(1.1)
end

local function HeadOf(bot)
	local bone = bot:LookupBone("ValveBiped.Bip01_Head1")
	local p = bone and bot:GetBonePosition(bone)
	if not p or p == bot:GetPos() then return bot:EyePos() end
	return p + V(0, 0, 3)
end

------------------------------------------------------------------------------------------
-- fh_impact: fists. A slow punch and a fast one, a hook, punches that add up, the body, a wall,
-- and a forearm in the way.
------------------------------------------------------------------------------------------
S.Add("fh_impact", function()
	local p = S.FindSpot({ open = 200, outdoor = true })
	local a = Fighter(p, 0)
	if not IsValid(a) then Log("no bot") return end
	if istable(a.organism) then a.organism.godmode = true end
	local vp = p + V(24, 0, 0)
	local v = Victim(vp, 180)
	if not IsValid(v) then Log("no second bot") return end
	local st = FH.State(a)
	RunConsoleCommand("fh_debug", "1")
	S.View(p + V(12, -74, 62), p + V(12, 0, 54))
	Wait(1.2)
	local function Done()
		Deaf()
		FH.TestInput[a] = nil
		RunConsoleCommand("fh_debug", "0")
		Tally("fh_impact")
	end
	if not Check("the module holds the attacker's fists", st.active == true and st.ok == true) then Done() return end
	Check("and not the hands of a player whose fists are down", FH.Applies(v) == nil)
	local head = HeadOf(v)
	local chest = v:GetPos() + V(0, 0, 48)
	Log("  the attacker at %s, the victim %s away; its head at (%.1f %.1f %.1f) from the attacker's feet; the attacker's right shoulder %.1f from it; an arm reaches %.1f and a fist %.1f more",
		tostring(a:GetPos()), tostring(v:GetPos() - a:GetPos()), head.x - p.x, head.y - p.y, head.z - p.z,
		sqrt((head.x - st.h[2].sx) ^ 2 + (head.y - st.h[2].sy) ^ 2 + (head.z - st.h[2].sz) ^ 2), B.ArmLength() * C.Body.reach, C.Body.hand)
	local org = Org(v)
	Log("  the victim before: health %d, pain %.1f, shock %.1f, consciousness %.2f, bruises %s", v:Health(), Num(org.pain), Num(org.shock), Num(org.consciousness), tostring(org.bruises))

	-- the hand drawn back to the chin, then sent through a place; returns the strongest blow
	local quick = false
	local function Punch(tag, i, through, speed, cock, shot, who)
		who = who or v
		local s = st.h[i]
		local back = cock or V(s.sx + 9, s.sy, s.sz + 3)
		WaitFor(Seek(a, i, back, quick and 1500 or 400), 2.5)
		Wait(quick and 0.3 or 0.5)
		Listen()
		local peak = 0
		FH.OnCmd = function(ply, cmd, inp, state)
			if ply ~= a then return end
			local h = state.h[i]
			peak = math.max(peak, sqrt((h.vx - state.bvx) ^ 2 + (h.vy - state.bvy) ^ 2 + (h.vz - state.bvz) ^ 2) * FH.U2M)
		end
		Seek(a, i, through, speed)
		if shot then Wait(0.22) S.Shot("fh_impact_" .. shot) Wait(0.9) else Wait(quick and 0.4 or 1.1) end
		FH.OnCmd = nil
		local b = Strongest(who)
		local daze, bal = FH.React.Daze(who)
		Log("  %s: the fist reached %.1f m/s", tag, peak)
		if b then
			Log("     struck %s (hitgroup %d) at %.1f m/s, %.1f into it: %.1f N s, %.1f J | head %s | daze now %.2f, balance %.2f | the victim %s",
				b.block and ("a " .. b.block .. " in the way") or "the body", b.hitgroup, b.speed, b.closing, b.impulse, b.energy,
				heads[#heads] and string.format("thrown %.1f m/s, turned %.0f rad/s, counts %.2f", heads[#heads].dv, heads[#heads].dOmega, heads[#heads].sev) or "not struck",
				daze, bal, IsValid(who.FakeRagdoll) and "is DOWN" or "stands")
		else
			Log("     struck nothing of the victim (%d contact(s) in all)", #blows)
		end
		FH.TestInput[a] = function() return nil end
		return b, peak
	end

	Log("-- the head: a slow punch and a fast one")
	local hp0 = v:Health()
	local pain0 = Num(org.pain) + Num(org.painadd)
	local slow = Punch("a slow straight right", 2, head + V(5, 0, 0), 40)
	local painSlow = Num(org.pain) + Num(org.painadd) - pain0
	local dazeSlow = FH.React.Daze(v)
	Restore(v, vp, 180)
	head = HeadOf(v)
	pain0 = Num(org.pain) + Num(org.painadd)
	local fast = Punch("a fast straight right", 2, head + V(5, 0, 0), 1500, nil, "straight")
	local painFast = Num(org.pain) + Num(org.painadd) - pain0
	local dazeFast = FH.React.Daze(v)
	Log("  what Z-City booked: pain +%.1f for the slow one, +%.1f for the fast one; bruises now %s", painSlow, painFast, tostring(org.bruises))
	Check("both punches arrive at the head", slow ~= nil and fast ~= nil and slow.hitgroup == HITGROUP_HEAD and fast.hitgroup == HITGROUP_HEAD,
		string.format("hitgroups %s and %s", tostring(slow and slow.hitgroup), tostring(fast and fast.hitgroup)))
	if slow and fast then
		Check("a fast punch has many times the energy of a slow one", fast.energy > slow.energy * 4, string.format("%.1f J against %.1f J", fast.energy, slow.energy))
		Check("and dazes more", dazeFast > dazeSlow + 0.05, string.format("%.2f against %.2f", dazeFast, dazeSlow))
		Check("the blow goes the way the fist went", fast.dx > 0.6, string.format("direction (%.2f %.2f %.2f), the victim is toward +x", fast.dx, fast.dy, fast.dz))
		Check("one straight punch does not fell a fresh player", not IsValid(v.FakeRagdoll))
	end

	Log("-- the head: a hook from the side")
	Restore(v, vp, 180)
	head = HeadOf(v)
	local hooked = Punch("a fast right hook", 2, head + V(0, 9, 0), 1500, V(head.x - 3, head.y - 14, head.z), "hook")
	if hooked then
		Check("a hook comes from the side", abs(hooked.dy) > 0.6, string.format("direction (%.2f %.2f %.2f)", hooked.dx, hooked.dy, hooked.dz))
		local hd = heads[#heads]
		Check("and turns the head", hd ~= nil and hd.dOmega > 3, hd and string.format("%.0f rad/s, thrown %.1f m/s", hd.dOmega, hd.dv) or "the head was not struck")
	else
		Check("a hook arrives", false)
	end

	Log("-- punches that add up: full straight rights, one a second")
	local fell, count, dazes, t0, fall
	-- (Z-City fells whoever is struck on the jaw above a damage of its own, at the first blow if
	-- it lands there. Blows that add up need a victim that stands for more than one: the row is
	-- begun again, twice at most, when the first punch was the last.)
	for attempt = 1, 3 do
	Restore(v, vp, 180)
	fell, count, dazes, fall = nil, 0, {}, nil
	quick = true
	t0 = CurTime()
	-- (the body as Z-City makes it: where its weight is, the moment it is made)
	FH.OnFall = function(ply, rag, top, age, dir)
		if ply == v then fall = { rag = rag, top = top, age = age, dir = dir, t = CurTime(), p = T.RagMiddle(rag) } end
	end
	for n = 1, 12 do
		head = HeadOf(v)
		local b = Punch("punch " .. n, 2, head + V(5, 0, 0), 1500)
		count = n
		dazes[n] = string.format("%.2f", (FH.React.Daze(v)))
		if IsValid(v.FakeRagdoll) then fell = n break end
		if not b then break end
	end
	quick = false
	Log("  daze after each punch: %s; the victim went down at punch %s, %.1f s after the first was thrown", table.concat(dazes, ", "), tostring(fell), CurTime() - t0)
	if fell ~= 1 or attempt == 3 then break end
	Log("  (down at the first punch: by Z-City's own rule for the jaw, this module's count at %s. Once more.)", dazes[1])
	FH.OnFall = nil
	end
	Check("blows to the head add up until the player goes down", fell ~= nil and fell >= 2, string.format("down at punch %s of %d", tostring(fell), count))
	FH.OnFall = nil
	if fell then
		local rag = v.FakeRagdoll
		Wait(0.25)
		S.Shot("fh_impact_down")
		local last = FH.React.State(v).last
		-- (Z-City has rules of its own for a blow to the head: one on the jaw above a damage of
		-- its own fells the player, and it lowers consciousness by chance. They often fell the
		-- player before this module's count is full. Whoever it was, the body is to fall the way
		-- of the blow.)
		Log("  the victim's own state: consciousness %.2f, unconscious %s; felled by %s (this module's daze %s of %.1f)", Num(org.consciousness), tostring(org.otrub),
			(last == "down" or last == "out") and "this module's count" or "Z-City's own answer to the blows", dazes[#dazes], C.React.knockdown)
		if fall and IsValid(rag) and rag == fall.rag then
			local p, vel = T.RagMiddle(rag)
			local moved = p - fall.p
			local along = moved.x * fall.dir.x + moved.y * fall.dir.y
			local flat = math.sqrt(moved.x * moved.x + moved.y * moved.y)
			Log("  the fall: begun %.2f s after the blow with %.0f units/s at the part that was struck; %.2f s later the body's middle has gone %.1f units over the ground, %.1f of them the way of the blow (%.2f %.2f %.2f), and moves at (%.0f %.0f %.0f)",
				fall.age, fall.top, CurTime() - fall.t, flat, along, fall.dir.x, fall.dir.y, fall.dir.z, vel.x, vel.y, vel.z)
			Check("the body falls the way it was struck", along > 3 and along > flat * 0.6, string.format("%.1f units along the blow of %.1f over the ground", along, flat))
		else
			Check("the body falls the way it was struck", false, "the ragdoll was not made within the time a blow lasts: nothing was given to it")
		end
	end

	Log("-- the body: a fast straight to the chest")
	Restore(v, vp, 180)
	v:Freeze(false)
	Wait(0.3)
	local before = v:GetPos()
	local bodyBlow = Punch("a fast right to the chest", 2, chest + V(6, 0, 0), 1500, nil, "body")
	local moved = v:GetPos() - before
	Log("  the victim was moved (%.1f %.1f %.1f)", moved.x, moved.y, moved.z)
	Check("a punch to the chest arrives at the trunk", bodyBlow ~= nil and (bodyBlow.hitgroup == HITGROUP_CHEST or bodyBlow.hitgroup == HITGROUP_STOMACH), bodyBlow and ("hitgroup " .. bodyBlow.hitgroup) or "nothing struck")
	Check("and pushes the body away", moved.x > 0.3, string.format("%.1f units", moved.x))
	v:Freeze(true)

	Log("-- a wall")
	do
		-- (a prop that does not move, an arm's length in front of a second fighter)
		local wp = p + V(0, 120, 0)
		local b2 = Fighter(wp, 0)
		local wall = ents.Create("prop_physics")
		wall:SetModel("models/hunter/plates/plate2x2.mdl")
		wall:SetPos(wp + V(22, 0, 52))
		wall:SetAngles(Angle(90, 0, 0))
		wall:Spawn()
		local phys = wall:GetPhysicsObject()
		if IsValid(phys) then phys:EnableMotion(false) end
		Wait(0.6)
		local st2 = FH.State(b2)
		local tr = util.TraceLine({ start = wp + V(0, -5.6, 57), endpos = wp + V(60, -5.6, 57), filter = b2 })
		Log("  a plate stood up in front of the second fighter: its face %.1f units from the player's middle (hit %s)", tr.HitPos.x - wp.x, tostring(tr.Entity))
		WaitFor(Seek(b2, 2, V(st2.h[2].sx + 9, st2.h[2].sy, st2.h[2].sz + 2), 400), 2.5)
		Wait(0.4)
		Listen()
		local deepest = -1e9
		-- (after everybody's commands and contacts of the tick: what is sent to the clients)
		hook.Add("Tick", "FH_TestWall", function() deepest = math.max(deepest, st2.h[2].kx - tr.HitPos.x) end)
		Seek(b2, 2, V(tr.HitPos.x + 8, st2.h[2].sy, st2.h[2].sz + 2), 1500)
		Wait(1.0)
		hook.Remove("Tick", "FH_TestWall")
		local best
		for _, b in ipairs(blows) do if not best or b.energy > best.energy then best = b end end
		Log("  the fist %s; its knuckles were at most %.2f units past the face", best and string.format("struck at %.1f m/s, %.1f N s, %.1f J (soft %s)", best.speed, best.impulse, best.energy, tostring(best.soft)) or "struck nothing", deepest)
		Check("a punch at a wall is stopped by the wall", best ~= nil and deepest < 0.3, string.format("the middle of the knuckles %.2f units past its face", deepest))
		FH.TestInput[b2] = nil
		if IsValid(wall) then wall:Remove() end

		Log("-- a forearm in the way")
		-- the second fighter now stands where the victim stood, fists up, and is hit at the head
		Restore(v, p + V(0, -160, 0), 180)
		S.Place(b2, vp, 180)
		T.Aim(b2, 0, 180)
		if istable(b2.organism) then b2.organism.godmode = false end
		Wait(1.5)
		local st3 = FH.State(b2)
		Check("the defender's fists are up and the module's", st3.active == true)
		-- its left forearm across its own face
		local hd = HeadOf(b2)
		WaitFor(Seek(b2, 1, V(hd.x - 9, hd.y + 1, hd.z + 1), 300), 3)
		Wait(0.5)
		S.View(p + V(12, -74, 62), p + V(12, 0, 54))
		local dazeB = FH.React.Daze(b2)
		local blocked = Punch("a fast straight right at a guarded head", 2, hd + V(5, 0, 0), 1500, nil, "blocked", b2)
		local dazeA = FH.React.Daze(b2)
		Log("  blocks seen: %d%s; the defender's daze %.2f -> %.2f", #blocks, blocks[1] and string.format(" (%s, arm %d, %.1f J)", blocks[1].kind, blocks[1].arm, blocks[1].energy) or "", dazeB, dazeA)
		Check("the forearm takes the punch", #blocks > 0 and blocks[1].kind == "arm")
		Check("and the head behind it is not struck", dazeA - dazeB < 0.05, string.format("daze +%.2f", dazeA - dazeB))
		FH.TestInput[b2] = nil
	end
	Done()
end)

------------------------------------------------------------------------------------------
-- fh_blows: tools. The same swing fast and slow on a head, a swing at a chest, and a weapon met
-- by a weapon. The victim is put where the swing passes: the swing is made once through empty
-- air and followed, then made again with somebody standing where it was fastest.
------------------------------------------------------------------------------------------
-- The place of a tool that strikes (its hook, or its edge), in the world, and its velocity.
local function Striker(st)
	local prof, b = st.prof, st.w
	local us = prof.usamples[#prof.usamples - (prof.edge and 1 or 0)]
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local ex, ey, ez = M.QRot(b.qw, b.qx, b.qy, b.qz, 0, 1, 0)
	local d = us.at - prof.u.com
	local rx, ry, rz = ax * d + ex * us.off, ay * d + ey * us.off, az * d + ez * us.off
	local cx, cy, cz = M.Cross(b.wx, b.wy, b.wz, rx, ry, rz)
	return V(b.x + rx, b.y + ry, b.z + rz), V(b.vx + cx, b.vy + cy, b.vz + cz)
end

local function BlowScene(name, class, victimClass)
	S.Add(name, function()
		local prof = C.Weapons[class]
		local p = S.FindSpot({ open = 220, outdoor = true })
		local a = Fighter(p, 0, class)
		if not IsValid(a) then Log("no bot") return end
		local st = FH.State(a)
		RunConsoleCommand("fh_debug", "2")
		S.View(p + V(26, -92, 72), p + V(26, 0, 54))
		Wait(1.2)
		local hurts = {}
		local function Done()
			Deaf()
			FH.OnHurt = nil
			FH.TestInput[a] = nil
			hook.Remove("Tick", "FH_TestPath")
			RunConsoleCommand("fh_debug", "0")
			Tally(name)
		end
		if not Check("the module holds the attacker's " .. prof.name, st.active == true and st.w ~= nil and st.prof == prof) then Done() return end
		FH.OnHurt = function(ply, target, dmg, dtype, cut, c) hurts[#hurts + 1] = { target = target, dmg = dmg, dtype = dtype, cut = cut, energy = c.energy } end
		local two = st.twoHand

		-- Where the hands are when a swing starts and where the right one is sent (the frame of
		-- the aim: forward, left, up from between the shoulders). With two hands the weapon lies
		-- flat and points to the right and forward; the left hand stays where it is and the right
		-- one is taken across in front of it, so the weapon turns about the left hand and its
		-- head goes round in front, far out. With one hand the hand is taken across and the wrist
		-- brings the weapon with it. The three heights put the head of the weapon at the height
		-- of a head, of a weapon held in its guard, and of a chest.
		-- (the hands stay at the chest for all three: near the face they are pushed away from
		-- it, and the weapon's head is raised by tilting the weapon instead: dz)
		local function TwoHands(h, dz)
			return { L = { 12, 2, h }, R = { 18.3, -8.8, h + dz }, to = { 18.3, 13, h + dz } }
		end
		local poses = two and { head = TwoHands(-3, 3), mid = TwoHands(-1.5, 1.3), chest = TwoHands(-9, 1.3) } or {
			head = { R = { 20, -15, -5 }, to = { 20, 9, -5 } },
			mid = { R = { 20, -15, -12 }, to = { 20, 9, -12 } },
			chest = { R = { 20, -15, -19 }, to = { 20, 9, -19 } },
		}
		local function World(t) return V(B.ToWorld(st, t[1], t[2], t[3])) end
		local function Pose(ps)
			FH.TestInput[a] = function() return nil end
			Wait(2.0)
			-- (the leading hand is sent to its place; where the other is then follows from how the
			-- mouse steers a weapon in two hands, sh_tool.lua)
			WaitFor(Seek(a, 2, World(ps.R), 300), 2.5)
			-- (and held there: a hand that is let go goes back to its guard)
			Play(a, { { L = two, R = true, n = 20 } }, true)
			Wait(0.7)
		end
		local function Sweep(ps, speed) Seek(a, 2, World(ps.to), speed) end

		-- once through the air: where the striking place is, tick by tick
		local function Path(ps, speed)
			Pose(ps)
			local path = {}
			hook.Add("Tick", "FH_TestPath", function()
				local pos, vel = Striker(st)
				path[#path + 1] = { pos = pos, vel = vel, speed = vel:Length() * FH.U2M }
			end)
			Sweep(ps, speed)
			Wait(speed > 200 and 1.0 or 4.0)
			hook.Remove("Tick", "FH_TestPath")
			return path
		end
		-- the fastest place on it between two heights where somebody can stand (not inside the
		-- attacker: two players are never nearer than their hulls let them)
		local function Pick(path, zlo, zhi)
			local best
			for _, q in ipairs(path) do
				local z = q.pos.z - p.z
				if z >= zlo and z <= zhi and q.pos.x - p.x >= 24 and q.speed > 0.5 and (not best or q.speed > best.speed) then best = q end
			end
			return best
		end

		local v = Victim(p + V(0, -220, 0), 180)
		if not IsValid(v) then Log("no second bot") Done() return end
		local off = HeadOf(v) - v:GetPos()
		local org = Org(v)
		local away = p + V(0, -220, 0)
		-- The victim with the middle of that part of it where the swing was picked. (A head is
		-- round to a blow: what passes through its middle strikes it square, what passes beside
		-- it grazes it.)
		local function Stand(q, what)
			local dir = q.vel:GetNormalized()
			local want = q.pos + dir * 1.5
			local base = what == "head" and off or V(off.x * 0.4, off.y * 0.4, 50)
			-- (and not so near that the attacker's hands are in the victim's chest)
			local vp = V(math.max(want.x - base.x, p.x + 27), want.y - base.y, p.z)
			Restore(v, vp, 180)
			return vp
		end
		-- (the victim comes to stand there when the weapon is already where the swing starts:
		-- on its way to that place the weapon would pass through where the victim stands)
		local function Swing(tag, ps, speed, shot, q, what)
			Restore(v, away, 180)
			Pose(ps)
			Listen()
			Stand(q, what)
			local touched = 0
			for _, b in ipairs(blows) do if b.target == v then touched = touched + 1 end end
			Listen()
			hurts = {}
			Sweep(ps, speed)
			if shot then Wait(0.2) S.Shot(name .. "_" .. shot) Wait(1.0) else Wait(speed > 200 and 1.2 or 4.0) end
			local b = Strongest(v)
			local daze, bal = FH.React.Daze(v)
			local h
			for _, e in ipairs(hurts) do if not h or e.dmg > h.dmg then h = e end end
			if touched > 0 then Log("  (%d contact(s) with the victim before the swing began: the weapon lay against it)", touched) end
			if b then
				Log("  %s: struck with the %s (hitgroup %d) at %.1f m/s, %.1f into it: %.1f N s, %.1f J%s | %d wound(s), the worst %s | daze %.2f balance %.2f, %s | the victim %s",
					tag, b.kind, b.hitgroup, b.speed, b.closing, b.impulse, b.energy, b.kind == "edge" and string.format(", edge leads %.2f", b.edge) or "", #hurts,
					h and string.format("%.1f %s%s", h.dmg, h.dtype == DMG_SLASH and "slash" or "club", h.cut and " (a cut)" or "") or "none",
					daze, bal, tostring(FH.React.State(v).last), IsValid(v.FakeRagdoll) and "is DOWN" or "stands")
			else
				Log("  %s: struck nothing of the victim (%d contact(s) in all)", tag, #blows)
			end
			return b, h
		end

		Log("-- the head")
		local pathHead = Path(poses.head, 1500)
		local qh = Pick(pathHead, off.z - 4.5, off.z + 4.5)
		local top
		for _, q in ipairs(pathHead) do if not top or q.speed > top.speed then top = q end end
		Log("  the swing through the air, %d ticks: fastest %.1f m/s at (%.1f %.1f %.1f) from the feet; at the height of a head (%.1f) and where somebody can stand: %s",
			#pathHead, top and top.speed or 0, top and top.pos.x - p.x or 0, top and top.pos.y - p.y or 0, top and top.pos.z - p.z or 0, off.z,
			qh and string.format("%.1f m/s at (%.1f %.1f %.1f)", qh.speed, qh.pos.x - p.x, qh.pos.y - p.y, qh.pos.z - p.z) or "nowhere")
		if not qh then Check("the swing passes the height of a head in front of the attacker", false) Done() return end
		local dirh = qh.vel:GetNormalized()
		local fast, fastHurt = Swing("a full swing at the head", poses.head, 1500, "head", qh, "head")
		local rag = v.FakeRagdoll
		local fell = IsValid(rag)
		Wait(0.2)
		local vel = IsValid(rag) and rag:GetVelocity() or Vector(0, 0, 0)
		Check("the swing arrives at the head", fast ~= nil and fast.hitgroup == HITGROUP_HEAD, fast and ("hitgroup " .. fast.hitgroup) or "nothing struck")
		if fast then
			Check("it is a blow of the weapon's weight", fast.energy > prof.damage.ref * 0.3, string.format("%.1f J, a solid blow with it is %d", fast.energy, prof.damage.ref))
			Check("the blow goes the way the weapon went", fast.dx * dirh.x + fast.dy * dirh.y + fast.dz * dirh.z > 0.6, string.format("(%.2f %.2f %.2f) against (%.2f %.2f %.2f)", fast.dx, fast.dy, fast.dz, dirh.x, dirh.y, dirh.z))
			local last = FH.React.State(v).last
			Check("a full blow of a tool to the head shakes a player or puts them down", last == "shaken" or last == "down" or last == "out", tostring(last))
			if fell then
				Log("  the body as it goes: velocity (%.0f %.0f %.0f)", vel.x, vel.y, vel.z)
				Check("the body goes the way it was struck", vel.x * fast.dx + vel.y * fast.dy > -10, string.format("%.0f units/s along the blow", vel.x * fast.dx + vel.y * fast.dy))
			end
		end
		local slow = Swing("the same swing slowly", poses.head, 25, nil, qh, "head")
		if fast and slow then
			Check("the slow one is a fraction of the fast one", slow.energy < fast.energy * 0.2, string.format("%.1f J against %.1f J", slow.energy, fast.energy))
		end
		local lastSlow = FH.React.State(v).last
		Check("a slow swing fells nobody", not IsValid(v.FakeRagdoll) and lastSlow ~= "out" and lastSlow ~= "down", tostring(lastSlow))

		Log("-- the chest")
		Restore(v, away, 180)
		local pathChest = Path(poses.chest, 1500)
		local qc = Pick(pathChest, 44, 58)
		Log("  the lower swing through the air: at the height of a chest %s", qc and string.format("%.1f m/s at (%.1f %.1f %.1f)", qc.speed, qc.pos.x - p.x, qc.pos.y - p.y, qc.pos.z - p.z) or "nowhere")
		if qc then
			local chest, chestHurt = Swing("a full swing at the chest", poses.chest, 1500, "chest", qc, "chest")
			Log("  Z-City has booked on this body: pain %.1f, cuts %d, bruises %d, bleeding %.2f", Num(org.pain) + Num(org.painadd),
				Num(org.slashwounds) + Num(org.stabwounds), Num(org.bruises), Num(org.bleed))
			Check("the swing arrives at the trunk or an arm", chest ~= nil and chest.hitgroup >= HITGROUP_CHEST and chest.hitgroup <= HITGROUP_RIGHTARM, chest and ("hitgroup " .. chest.hitgroup) or "nothing struck")
			if chest and chestHurt then
				-- (the worst wound of the swing and its strongest contact need not be the same
				-- place of the weapon: a swing lays more than one on a body)
				if chestHurt.cut then
					Check("a blade that leads cuts", chestHurt.dtype == DMG_SLASH, string.format("damage %.1f", chestHurt.dmg))
				else
					Check("what is not a leading edge bruises", chestHurt.dtype == DMG_CLUB, string.format("damage %.1f", chestHurt.dmg))
				end
				local ref = (tonumber(a:GetActiveWeapon().DamagePrimary) or 20) / 1.5
				Log("  the damage: %.1f for %.1f J; a swing of this weapon in Z-City did %.1f, and a solid blow here is %d J", chestHurt.dmg, chestHurt.energy, ref, prof.damage.ref)
			end
		else
			Check("the lower swing passes the height of a chest in front of the attacker", false)
		end

		if victimClass then
			Log("-- a weapon in the way")
			Restore(v, away, 180)
			local d = Fighter(p + V(120, 120, 0), 180, victimClass)
			if IsValid(d) then
				if istable(d.organism) then d.organism.godmode = false end
				local ds = FH.State(d)
				Wait(1.0)
				-- where a place on its weapon is from its feet; it is put so that this is on the swing's way
				local b = ds.w
				local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
				local u = ds.prof.u
				-- (Of the three swings and of four places along the defender's bar, the pair in which
				-- the swing is fastest at the place's height: the middle of a swing is where it is
				-- fast, and its end, where it is slow, misses by a hand's width.)
				local paths = {}
				for _, which in ipairs({ "mid", "head", "chest" }) do paths[which] = Path(poses[which], 1500) end
				local qm, met, mid
				for _, share in ipairs({ 0.62, 0.5, 0.4, 0.3 }) do
					local k = u.length * share - u.com
					local at = V(b.x + ax * k - ds.bx, b.y + ay * k - ds.by, b.z + az * k - ds.bz)
					for which, path in pairs(paths) do
						local q = Pick(path, at.z - 2.5, at.z + 2.5)
						if q and (not qm or q.speed > qm.speed) then qm, met, mid = q, poses[which], at end
					end
				end
				mid = mid or V(b.x - ds.bx, b.y - ds.by, b.z - ds.bz)
				Log("  the defender's weapon is %.1f above its feet where it is to be met; there the attacker's swing does %s", mid.z,
					qm and string.format("%.1f m/s at (%.1f %.1f %.1f)", qm.speed, qm.pos.x - p.x, qm.pos.y - p.y, qm.pos.z - p.z) or "not pass")
				if qm then
					local dirm = qm.vel:GetNormalized()
					local dp = V(qm.pos.x - mid.x + dirm.x * 1.5, qm.pos.y - mid.y + dirm.y * 1.5, p.z)
					Pose(met)
					Listen()
					S.Place(d, dp, 180)
					T.Aim(d, 0, 180)
					Wait(1.8)
					local touched = #blocks
					Listen()
					hurts = {}
					local spin = 0
					hook.Add("Tick", "FH_TestPath", function() if ds.w then spin = math.max(spin, math.sqrt(ds.w.wx ^ 2 + ds.w.wy ^ 2 + ds.w.wz ^ 2)) end end)
					Sweep(met, 1500)
					Wait(0.2) S.Shot(name .. "_parry") Wait(1.0)
					hook.Remove("Tick", "FH_TestPath")
					local bl
					for _, e in ipairs(blocks) do if e.kind == "tool" and (not bl or e.energy > bl.energy) then bl = e end end
					Log("  %d contact(s) of weapon on weapon before the swing; in it: blocks %d%s; the defender's weapon was set turning at up to %.1f rad/s; wounds given to the defender: %d", touched, #blocks,
						bl and string.format(" (the strongest on its weapon: %.1f J)", bl.energy) or "", spin, #hurts)
					Check("the weapon meets the weapon", bl ~= nil)
					-- (how much a bar that is held in two hands turns for a blow depends on where along it the blow lands)
					Check("and is felt by it", spin > 0.2, string.format("%.1f rad/s", spin))
				else
					Check("the swing passes where the defender's weapon is", false)
				end
				FH.TestInput[d] = nil
			end
		end
		Done()
	end)
end

BlowScene("fh_blows", "weapon_hg_crowbar", "weapon_hg_crowbar")
BlowScene("fh_blows_axe", "weapon_hg_axe", nil)
BlowScene("fh_blows_hatchet", "weapon_hatchet", nil)

------------------------------------------------------------------------------------------
-- fh_net: the player's own weapon, predicted on the client, held to the server's. What the
-- client predicted and what the server had are compared command by command: with nothing in the
-- way, with the server's state pushed aside behind the client's back, and with the correction
-- switched off (to show that it is the correction that brings the two together again).
------------------------------------------------------------------------------------------
S.Add("fh_net", function()
	local host = S.Host()
	local class = "weapon_hg_crowbar"
	if not host:HasWeapon(class) then host:Give(class) end
	host:SelectWeapon(class)
	host:SetEyeAngles(Angle(6, 0, 0))
	-- (rested: tired arms are weaker, and the client hears of that a moment late)
	if T.Rested then T.Rested(host) end
	Log("  (%s)", T.HostPlace(host, S.FindSpot({ open = 170, outdoor = true }), { ahead = 180 }))
	Wait(1.6)
	local hs = FH.State(host)
	local function Done()
		FH.OnContact = nil
		S.Client("fhinput", {})
		S.Client("fhfix", { off = false })
		host:SelectWeapon("weapon_hands_sh")
		host:StripWeapon(class)
		Tally("fh_net")
	end
	if not Check("the module holds the host's crowbar", hs.active == true and hs.w ~= nil) then Done() return end
	local server = {}
	FH.OnContact = function(ply, s)
		if ply == host and s.w then
			local a, b, c = Rel(s, 2)
			server[s.cmd] = { a, b, c, s.w.x - s.bx, s.w.y - s.by, s.w.z - s.bz, RealTime(), g = { s.bx, s.by, s.bz, s.bvx, s.bvy } }
		end
	end
	-- the client's record against the server's: the largest difference in each stretch of commands
	local function Compare(from)
		local r = Ask("fhinput", { report = true }, "pred", 3)
		local list = {}
		if r and r.list then
			for _, e in ipairs(r.list) do
				local sv = server[e[1]]
				if sv and e[8] and (not from or e[1] >= from) then
					list[#list + 1] = { cmd = e[1], d = math.max(sqrt((e[5] - sv[1]) ^ 2 + (e[6] - sv[2]) ^ 2 + (e[7] - sv[3]) ^ 2), sqrt((e[8] - sv[4]) ^ 2 + (e[9] - sv[5]) ^ 2 + (e[10] - sv[6]) ^ 2)) }
				end
			end
		end
		table.sort(list, function(x, y) return x.cmd < y.cmd end)
		return list
	end
	local function Fixes()
		local r = Ask("fhfix", { get = true }, "fix", 3)
		return r and r.fixes or -1
	end

	Log("-- nothing in the way: swings through the air")
	local f0 = Fixes()
	server = {}
	S.Client("fhinput", { record = true, moves = {
		{ R = true, mx = 30, my = -40, n = 20 }, { L = true, mx = -50, my = -20, n = 20 }, { L = true, R = true, mx = 25, my = 35, n = 25 },
		{ R = true, mx = 0, my = 400, n = 8 }, { R = true, n = 30 }, { R = true, mx = -300, my = -100, n = 10 }, { n = 40 },
	} })
	Wait(3.0)
	local list = Compare()
	local worst = 0
	for _, e in ipairs(list) do worst = math.max(worst, e.d) end
	local f1 = Fixes()
	Log("  %d commands compared: the client's weapon and the server's differ by %.4f units at the worst; corrections made meanwhile: %d (the arms' strength now: %.3f)", #list, worst, f1 - f0, host:GetNW2Float("fh_str", 1))
	Check("with nothing in the way the prediction needs no correcting", #list >= 80 and worst < 0.05 and f1 - f0 <= 1, string.format("%d corrections", f1 - f0))

	-- The server's state pushed aside: the place its right hand is wanted is moved 6 units down,
	-- once, as if a command had been lost. Returns how the difference went from then on.
	local function Shove()
		server = {}
		S.Client("fhinput", { record = true, moves = { { R = true, n = 260 } } })
		Wait(0.8)
		local at = hs.cmd
		-- (both hands' targets, the same way: in two hands the one is worked out from the other)
		hs.h[2].tu = hs.h[2].tu - 6
		hs.h[1].tu = hs.h[1].tu - 6
		Wait(2.4)
		local l = Compare(at + 1)
		local peak, last, settled = 0, 0, nil
		for i, e in ipairs(l) do
			peak = math.max(peak, e.d)
			last = e.d
		end
		-- the first command from which it stays small
		for i = #l, 1, -1 do
			if l[i].d > 0.3 then settled = l[i + 1] and (l[i + 1].cmd - at) or nil break end
			if i == 1 then settled = 1 end
		end
		return peak, last, settled, #l
	end

	Log("-- the server's state pushed aside, the correction on")
	local f2 = Fixes()
	local peak, last, settled, n = Shove()
	local f3 = Fixes()
	Log("  %d commands after the push: the two were %.2f units apart at the most, %.3f at the end; together again %s; corrections: %d", n, peak, last,
		settled and string.format("%d commands (%.0f ms) after it", settled, settled * engine.TickInterval() * 1000) or "never", f3 - f2)
	Check("the client takes the server's word", peak > 1 and last < 0.3 and settled ~= nil and settled < 40 and f3 > f2, string.format("%.3f units apart at the end", last))

	Log("-- the same push with the correction off")
	S.Client("fhfix", { off = true })
	Wait(0.3)
	local peak2, last2 = Shove()
	Log("  the two were %.2f units apart at the most and %.2f at the end", peak2, last2)
	Check("without it the two stay apart", last2 > 2, string.format("%.2f units", last2))
	S.Client("fhfix", { off = false })
	Wait(1.5)
	S.Client("fhinput", { record = true, moves = { { R = true, n = 60 } } })
	server = {}
	Wait(1.2)
	local l3 = Compare()
	local w3 = 0
	for i = math.max(#l3 - 15, 1), #l3 do w3 = math.max(w3, l3[i].d) end
	Log("  switched on again: %.3f units apart after a second", w3)
	Check("and come together when it is on again", #l3 > 20 and w3 < 0.3, string.format("%.3f units", w3))

	-- A body that moves: the two sides step the same commands from where each has the body, and
	-- how fast. (No judgement on the size yet: a number that was missing.)
	Log("-- walking and swinging")
	S.Client("fhinput", {})
	Wait(1.0)
	local f2 = Fixes()
	server = {}
	local moved0 = host:GetPos()
	S.Client("fhinput", { record = true, moves = {
		{ fwd = 10000, R = true, mx = 30, my = -40, n = 20 }, { fwd = 10000, L = true, R = true, mx = -60, my = 20, n = 25 },
		{ fwd = 10000, R = true, mx = 0, my = 300, n = 8 }, { fwd = 10000, R = true, n = 30 }, { R = true, n = 20 }, { n = 40 },
	} })
	Wait(2.8)
	local l4 = Compare()
	local w4, n4, sum4, last4 = 0, 0, 0, 0
	for _, e in ipairs(l4) do
		w4, sum4, last4 = math.max(w4, e.d), sum4 + e.d, e.d
		if e.d > 0.05 then n4 = n4 + 1 end
	end
	local f3 = Fixes()
	Log("  the host walked %.0f units; %d commands compared: the client's weapon and the server's differ by %.3f units on average, %.3f at the worst, in %d of them by more than 0.05; %.3f at the end; corrections made meanwhile: %d",
		host:GetPos():Distance(moved0), #l4, #l4 > 0 and sum4 / #l4 or -1, w4, n4, last4, f3 - f2)
	-- (how the body went on the server, and in what state the host walked)
	do
		local parts = {}
		for k, e in ipairs(l4) do
			local sv = server[e.cmd]
			if sv and sv.g and k % 12 == 1 then
				parts[#parts + 1] = string.format("%d: %.0f at %.0f", k, Vector(sv.g[1], sv.g[2], sv.g[3]):Distance(moved0), Vector(sv.g[4], sv.g[5], 0):Length())
			end
		end
		Log("  the body on the server (command: units walked, at units/s): %s", table.concat(parts, " | "))
		local ground = host:GetGroundEntity()
		Log("  the host: on the ground %s (%s), crouching %s, speeds walk %.0f run %.0f max %.0f, at (%.0f %.0f %.0f)",
			tostring(host:OnGround()), tostring(IsValid(ground) and ground:GetClass() or ground), tostring(host:Crouching()),
			host:GetWalkSpeed(), host:GetRunSpeed(), host:GetMaxSpeed(), host:GetPos().x, host:GetPos().y, host:GetPos().z)
	end
	-- (measured first in run fh36: 0.26 units on average, 1.5 at the worst. A body that walks is
	-- not at quite the same place and speed on the two sides in the same command.)
	-- (a host that did not walk has shown nothing: with a tool in its hands the scene's walking
	-- moved the host in some runs only)
	local walked = host:GetPos():Distance(moved0)
	-- (Since the mouse moves the hands further for a count, phase 41, the same counts swing the
	-- weapon further and faster: 1.3 to 2.7 units at the worst in six runs, fh43 to fh45, with
	-- 0.12 to 0.33 on average. A fist is 4.6 units across.)
	Check("walking, the client's own weapon stays within a hand's width of the server's and is with it at the end", walked > 50 and #l4 > 60 and w4 < 3.6 and last4 < 0.3,
		string.format("walked %.0f units; %.3f units at the worst, %.3f at the end", walked, w4, last4))
	Done()
end)

------------------------------------------------------------------------------------------
-- fh_perf: what it costs. Six fighters swinging at once, for six seconds: the server's time for
-- stepping them and for their contacts, and the client's time for drawing them.
------------------------------------------------------------------------------------------
S.Add("fh_perf", function()
	local p = S.FindSpot({ open = 260, outdoor = true })
	local classes = { "weapon_hg_crowbar", "weapon_hands_sh", "weapon_hg_axe", "weapon_hatchet", "weapon_hands_sh", "weapon_hg_crowbar" }
	local bots = {}
	for i, class in ipairs(classes) do
		local a = math.rad((i - 1) * 60)
		-- (in a ring, facing its middle, near enough for weapons to meet)
		local b = Fighter(p + V(math.cos(a) * 34, math.sin(a) * 34, 0), (i - 1) * 60 + 180, class)
		if IsValid(b) then bots[#bots + 1] = b end
	end
	S.View(p + V(-64, -64, 96), p + V(0, 0, 48))
	Wait(1.0)
	local active = 0
	for _, b in ipairs(bots) do if FH.State(b).active then active = active + 1 end end
	Log("  %d fighters, %d of them held by the module", #bots, active)
	-- everybody swings: up, down hard, across, back, again and again
	local moves = {}
	for _ = 1, 12 do
		moves[#moves + 1] = { L = true, R = true, mx = 0, my = -60, n = 12 }
		moves[#moves + 1] = { R = true, mx = -120, my = 420, n = 8 }
		moves[#moves + 1] = { L = true, mx = 200, my = -100, n = 8 }
		moves[#moves + 1] = { R = true, mx = 300, my = -200, n = 8 }
	end
	for _, b in ipairs(bots) do Play(b, moves, false) end
	Wait(0.5)
	FH.Perf = { step = 0, steps = 0, contact = 0, contacts = 0 }
	S.Client("fhperf", { on = true })
	local t0, tick0 = SysTime(), engine.TickCount()
	Wait(6.0)
	local pf = FH.Perf
	FH.Perf = nil
	local secs, ticks = SysTime() - t0, engine.TickCount() - tick0
	S.Shot("fh_perf")
	local r = Ask("fhperf", { get = true }, "perf", 3)
	local perStep = pf.steps > 0 and pf.step / pf.steps * 1e6 or 0
	local perContact = pf.contacts > 0 and pf.contact / pf.contacts * 1e6 or 0
	local perTick = ticks > 0 and (pf.step + pf.contact) / ticks * 1000 or 0
	Log("  server, %d ticks in %.1f s: a step of one fighter %.0f microseconds (%d steps), its contacts %.0f microseconds (%d); all %d fighters together %.3f ms a tick, %.1f %% of a tick of %.1f ms",
		ticks, secs, perStep, pf.steps, perContact, pf.contacts, active, perTick, perTick / (engine.TickInterval() * 1000) * 100, engine.TickInterval() * 1000)
	Check("stepping a fighter and its contacts stays a small part of a tick", perTick < engine.TickInterval() * 1000 * 0.12 and pf.steps > 100, string.format("%.3f ms a tick for %d fighters", perTick, active))
	if r and r.frames and r.frames > 0 then
		local fps = r.frames / r.secs
		local hands = r.handsN > 0 and r.hands / r.handsN * 1e6 or 0
		local prop = r.propN > 0 and r.prop / r.propN * 1e6 or 0
		local perFrame = (r.hands + r.prop) / r.frames * 1000
		Log("  client, %d frames in %.1f s (%.0f a second): placing one fighter's hands %.0f microseconds (%d times), drawing one weapon %.0f microseconds (%d times); all of it %.3f ms a frame",
			r.frames, r.secs, fps, hands, r.handsN, prop, r.propN, perFrame)
		Log("  (a fighter's hands are placed %.1f times a frame: once for every pass in which the game draws that player)", r.handsN / r.frames / math.max(active, 1))
		if r.shN and r.shN > 0 then
			Log("  of placing a fighter's hands, the shoulders: %.0f microseconds a fighter (%.1f a shoulder, %d times)", r.sh / math.max(r.handsN, 1) * 1e6, r.sh / r.shN * 1e6, r.shN)
		end
		Check("drawing six fighters at arm's length costs under 3 ms a frame", perFrame < 3.0 and r.handsN > 50, string.format("%.3f ms a frame", perFrame))
	else
		Check("the client measured its drawing", false)
	end
	for _, b in ipairs(bots) do FH.TestInput[b] = nil end
	Tally("fh_perf")
end)

------------------------------------------------------------------------------------------
-- fh_off: with the switch off everything is Z-City's own again. A bot with the hatchet: the
-- module does not hold it, Z-City's hold type is the class's own, a primary attack starts
-- Z-City's timed attack; a picture of the host with the weapon as Z-City shows it. Then the
-- switch on again: the module holds the weapon, and the same press starts nothing.
------------------------------------------------------------------------------------------
local function OffScene()
	-- (the hatchet: its own hold type is not the module's plain one, so the two can be told apart)
	local class = "weapon_hatchet"
	local p = S.FindSpot({ open = 170, outdoor = true })
	local bot, wep = Fighter(p, 0, class)
	if not IsValid(bot) then Log("no bot") return end
	local st = FH.State(bot)
	S.View(p + V(68, -58, 72), p + V(6, 0, 52))
	Wait(1.0)
	local own = weapons.GetStored(class).HoldType
	Check("switched on, the module holds the bot's hatchet", st.active == true and FH.Applies(bot, wep) ~= nil)
	Check("and the weapon's hold type is the module's plain one", wep:GetHoldType() == C.HoldType, string.format("%s; the class's own is %s", tostring(wep:GetHoldType()), tostring(own)))

	RunConsoleCommand("fh_enabled", "0")
	FH.TestInput[bot] = nil
	Wait(1.5)
	Check("switched off, the module holds nothing", FH.Applies(bot, wep) == nil and st.active ~= true)
	Check("the weapon's hold type is the class's own again", wep:GetHoldType() == own, string.format("%s, the class's own is %s", tostring(wep:GetHoldType()), tostring(own)))
	Check("blocking is Z-City's to allow again", wep:CanBlock() == true)
	-- the primary attack as Z-City has it: the weapon's own function, with nothing held back
	local before = wep:GetInAttack()
	wep:PrimaryAttack()
	Wait(0.1)
	local inAttack = wep:GetInAttack()
	Log("  a primary attack: in attack %s -> %s, attack type %s, the animated model plays until %.2f (now %.2f)", tostring(before), tostring(inAttack), tostring(wep:GetAttackType()), wep:GetLastAttack(), CurTime())
	Check("a press of the primary button starts Z-City's own timed attack", before ~= true and inAttack == true)
	S.Shot("fh_off_zcity_attack")
	Wait(1.6)
	-- the host, first person, as Z-City draws it
	local host = S.Host()
	if not host:HasWeapon(class) then host:Give(class) end
	host:SelectWeapon(class)
	Wait(1.0)
	S.Client("view", {})
	S.Client("zview", { on = true })
	Wait(1.5)
	S.Shot("fh_off_own_zcity")
	local hs = FH.states[host]
	Check("the host's weapon is not the module's either", FH.Applies(host) == nil and not (hs and hs.active))

	RunConsoleCommand("fh_enabled", "1")
	Wait(1.5)
	S.Shot("fh_off_own_again")
	S.Client("zview", { on = false })
	Check("switched on again, the module holds the bot's hatchet", FH.Applies(bot, wep) ~= nil and FH.State(bot).active == true)
	Check("and the host's", FH.Applies(host) ~= nil and FH.State(host).active == true)
	Check("the hold type is the plain one again", wep:GetHoldType() == C.HoldType, tostring(wep:GetHoldType()))
	wep:SetInAttack(false)
	Wait(0.2)
	wep:PrimaryAttack()
	Wait(0.1)
	Check("and the same press starts no attack", wep:GetInAttack() ~= true)
	host:SelectWeapon("weapon_hands_sh")
	host:StripWeapon(class)
end

S.Add("fh_off", function()
	-- (whatever happens in it, the switch is not left off: it is a saved setting)
	local ok, err = pcall(OffScene)
	RunConsoleCommand("fh_enabled", "1")
	S.Client("zview", { on = false })
	if not ok then Log("  the scene failed: %s", tostring(err)) Check("the scene ran through", false) end
	Tally("fh_off")
end)
