-- Client: from the simulated hands to what is seen.
--
-- Z-City draws a player's own body in first person and bends arms to hand positions it is given
-- (hg.DoTPIK, lua/homigrad/cl_tpik.lua): a weapon's SetHandPos puts the hand bones where they
-- should be, sets rhandik / lhandik, and the arm follows. Its weapons take those places from an
-- animated model. Here they come from the simulation: the hand bone goes where the simulated hand
-- is, the elbow where an arm with that hand would have it (given to Z-City's solver through its
-- IKPoleLeftArm / IKPoleRightArm hooks), and the weapon is drawn where its rigid body is.

FreeHand.NoJIT()
local FH = FreeHand
local C, M, B, W = FH.Config, FH.Math, FH.Body, FH.Weapon
FH.Render = FH.Render or {}
local R = FH.Render
local cl = FH.cl
local rad, cos, sin = math.rad, math.cos, math.sin

local NAMES = {
	{ up = "ValveBiped.Bip01_L_UpperArm", fore = "ValveBiped.Bip01_L_Forearm", hand = "ValveBiped.Bip01_L_Hand", clav = "ValveBiped.Bip01_L_Clavicle" },
	{ up = "ValveBiped.Bip01_R_UpperArm", fore = "ValveBiped.Bip01_R_Forearm", hand = "ValveBiped.Bip01_R_Hand", clav = "ValveBiped.Bip01_R_Clavicle" },
}

-- bone numbers of a model, looked up once
local boneCache = {}
local function Bones(ent)
	local mdl = ent:GetModel() or ""
	local c = boneCache[mdl]
	if c and c.n == ent:GetBoneCount() then return c end
	c = { n = ent:GetBoneCount() }
	for i = 1, 2 do
		c[i] = { up = ent:LookupBone(NAMES[i].up), fore = ent:LookupBone(NAMES[i].fore), hand = ent:LookupBone(NAMES[i].hand), clav = ent:LookupBone(NAMES[i].clav) }
	end
	c.okay = c[1].up and c[1].fore and c[1].hand and c[2].up and c[2].fore and c[2].hand and true or false
	boneCache[mdl] = c
	return c
end
R.Bones = Bones

-- The aim frame the hands were stepped in (unit vectors).
local function DrawnFrame(rs)
	local y, p = rad(rs.yaw), rad(M.Clamp(rs.pitch, -89, 89) * C.Body.pitchFollow)
	local cy, sy, cp, sp = cos(y), sin(y), cos(p), sin(p)
	return cy * cp, sy * cp, -sp, -sy, cy, 0, sp * cy, sp * sy, cp
end
R.DrawnFrame = DrawnFrame

-- The trunk of a player as it is drawn (B.Trunk), into a table that is used again.
local trunk = {}
local function DrawnTrunk(ply, rs)
	local o = ply:GetPos()
	local eyeZ = ply.GetCurrentViewOffset and ply:GetCurrentViewOffset().z or 64
	trunk[1], trunk[2], trunk[3], trunk[4], trunk[5] = B.Trunk(o.x, o.y, o.z, eyeZ, rs.yaw)
	return trunk
end
R.DrawnTrunk = DrawnTrunk

-- The fingers of a hand as another model has them (an animated pair of arms whose hands are
-- closed), carried over to a hand bone that has been placed. src: that model, already posed.
local FINGERS = {}
for i, s in ipairs({ "L", "R" }) do
	local t = { "ValveBiped.Bip01_" .. s .. "_Hand" }
	for f = 0, 4 do
		for _, j in ipairs({ "", "1", "2" }) do t[#t + 1] = "ValveBiped.Bip01_" .. s .. "_Finger" .. f .. j end
	end
	FINGERS[i] = t
end
local fingerCache = {}
local function FingerBones(ent, i)
	local mdl = ent:GetModel() or ""
	local c = fingerCache[mdl]
	if not c or c.n ~= ent:GetBoneCount() then c = { n = ent:GetBoneCount() } fingerCache[mdl] = c end
	if not c[i] then
		local t = {}
		for k, name in ipairs(FINGERS[i]) do t[k] = ent:LookupBone(name) or false end
		c[i] = t
	end
	return c[i]
end
-- (Where each finger bone of the source lies from its hand is worked out once and kept on the
-- source: a closed hand does not change. Per frame that leaves one product and one bone to set
-- for a finger bone; asking the source for its bones every time, and carrying the fingers with
-- the hand first only to replace them, cost 390 microseconds a fighter, run fh17.)
local function FingerPose(src, i)
	local all = src.FH_rel
	if not all then all = {} src.FH_rel = all end
	local rel = all[i]
	if rel ~= nil then return rel end
	local sb = FingerBones(src, i)
	local sh = sb[1] and src:GetBoneMatrix(sb[1])
	local inv = sh and sh:GetInverse()
	if not inv then return nil end
	rel = {}
	for k = 2, #sb do
		local m = sb[k] and src:GetBoneMatrix(sb[k])
		rel[k] = m and (inv * m) or false
	end
	all[i] = rel
	return rel
end

local function CopyFingers(ent, i, src, handM)
	local rel = FingerPose(src, i)
	if not rel then return false end
	local db = FingerBones(ent, i)
	for k = 2, #db do
		if rel[k] and db[k] then ent:SetBoneMatrix(db[k], handM * rel[k]) end
	end
	return true
end
R.CopyFingers = CopyFingers

-- The shoulder goes with the arm. Z-City's solver bends the upper arm and the forearm from the
-- upper arm's joint and leaves that joint where the animation has it; an arm that is raised or
-- stretched while its shoulder stays put is what reads as a hand moved about on its own. The
-- collar bone is turned about its root, before the arm is solved, so that the joint rises with
-- a raised hand and goes forward with a stretched arm (sh_config.lua, shrug and protract).
-- (which way an angle is turned about an axis, asked of the engine once)
local TURN = (function()
	local t = Angle(0, 0, 0)
	t:RotateAroundAxis(Vector(0, 0, 1), 90)
	return t.y > 0 and 1 or -1
end)()
-- What it costs (scene fh_perf): turned with Z-City's own helper, which carries every bone below
-- the one it is given, the collar bone took the upper arm, the forearm, the hand and fifteen
-- finger bones with it, for each arm of each fighter in each pass, and placing a fighter's hands
-- cost 486 microseconds where it had cost 103 (run fh46). Three things are done about that. Only
-- the bones between the collar bone and the forearm are carried (a list kept for the model): the
-- forearm and the hand are placed anew after this anyway, by Z-City's solver and by PlaceHand.
-- An arm near its guard asks for less than SHOULDER_DEAD units and its shoulder is left as the
-- animation has it. And a pass that finds the collar bone as this function left it in the same
-- frame leaves it: the turn is from where the bone is, and turned again it would go twice as far.
local SHOULDER_DEAD = 0.3
local function TurnShoulder(ent, b, i, hx, hy, hz, len, rec)
	if not b.clav or not hg or not hg.get_children then return end
	local cm, um = ent:GetBoneMatrix(b.clav), ent:GetBoneMatrix(b.up)
	if not cm or not um then return end
	local ang = cm:GetAngles()
	local frame = FrameNumber()
	local done = rec and rec.clav and rec.clav[i]
	if done and done.frame == frame then
		local a = done.ang
		if math.abs(math.AngleDifference(a.p, ang.p)) + math.abs(math.AngleDifference(a.y, ang.y)) + math.abs(math.AngleDifference(a.r, ang.r)) < 0.02 then return end
	end
	local c, s = cm:GetTranslation(), um:GetTranslation()
	local dx, dy, dz = hx - s.x, hy - s.y, hz - s.z
	local d = math.sqrt(dx * dx + dy * dy + dz * dz)
	if d < 1 then return end
	local L = len * 2
	local upK = M.Clamp(dz / L, 0, 1)
	local outK = M.Clamp((d / L - 0.6) / 0.4, 0, 1)
	local bd = C.Body
	local k = outK * bd.protract / d
	local mx, my, mz = dx * k, dy * k, dz * k + upK * bd.shrug
	-- (from nothing at the dead part to all of it at three times that: nothing jumps where it
	-- begins, and an arm that is stretched has the whole of its shoulder's way)
	local ml = math.sqrt(mx * mx + my * my + mz * mz)
	if ml <= SHOULDER_DEAD then return end
	local keep = M.Clamp((ml - SHOULDER_DEAD) / (SHOULDER_DEAD * 2), 0, 1)
	local move = Vector(mx * keep, my * keep, mz * keep)
	local v0 = s - c
	local v1 = v0 + move
	local axis = v0:Cross(v1)
	local al = axis:Length()
	if al < 1e-4 then return end
	axis:Div(al)
	local inv = cm:GetInverse()
	if not inv then return end
	ang:RotateAroundAxis(axis, math.deg(math.atan2(al, v0:Dot(v1))) * TURN)
	local m = Matrix()
	m:SetTranslation(c)
	m:SetAngles(ang)
	m:SetScale(cm:GetScale())
	if b.girdle == nil then b.girdle = hg.get_children(ent, b.clav, b.fore) or false end
	if b.girdle then
		local carry = m * inv
		for _, id in ipairs(b.girdle) do
			local bm = ent:GetBoneMatrix(id)
			if bm then ent:SetBoneMatrix(id, carry * bm) end
		end
	end
	ent:SetBoneMatrix(b.clav, m)
	if rec then
		rec.clav = rec.clav or {}
		done = rec.clav[i]
		if not done then done = { ang = Angle(0, 0, 0) } rec.clav[i] = done end
		done.frame = frame
		done.ang:Set(ang)
	end
end
-- (its time apart, for scene fh_perf)
local function Shoulder(ent, b, i, hx, hy, hz, len, rec)
	local pf = FH.PerfCl
	if not pf then return TurnShoulder(ent, b, i, hx, hy, hz, len, rec) end
	local t0 = SysTime()
	TurnShoulder(ent, b, i, hx, hy, hz, len, rec)
	pf.sh, pf.shN = pf.sh + SysTime() - t0, pf.shN + 1
end
R.Shoulder = Shoulder

-- Where the elbow was drawn last and when, for an elbow that goes round no faster than an elbow
-- does (sh_body.lua, B.Elbow): returns that place and how far round it may have gone since.
local function LastPole(rec, i)
	local p = rec.pole[i]
	local t = rec.poleT and rec.poleT[i]
	if not p or not t then return nil end
	local dt = RealTime() - t
	if dt > 0.25 then return nil end
	return p.x, p.y, p.z, rad(C.Arm.elbowTurn) * dt
end
R.LastPole = LastPole

-- What the last frame did for each player: the elbows for Z-City's solver, and numbers for tests.
R.last = R.last or setmetatable({}, { __mode = "k" })

-- Puts one hand bone at a simulated hand. hx..: where the simulation has the hand (world).
-- handAng: the hand's attitude when something else decides it (a grip); nil: carried by the forearm.
-- closed: the model a closed hand's fingers are taken from (R.ClosedHands), or nil: the fingers
-- then go with the hand as the animation has them.
local function PlaceHand(ent, ply, i, bones, hx, hy, hz, fx, fy, fz, lx, ly, lz, ux, uy, uz, rec, tk, handAng, closed)
	local b = bones[i]
	-- (Z-City's solver gives both bones the length of the forearm: the same here, or its arm and
	-- our hand would not meet)
	local len = ply:BoneLength(b.fore)
	if not len or len <= 0 then len = 12 end
	-- (a hand on a handle comes with its attitude, and its shoulder has been turned where that
	-- was worked out: cl_tool.lua, GripPose. Turned here again it went twice as far.)
	if not handAng then Shoulder(ent, b, i, hx, hy, hz, len, rec) end
	local upM, foreM, handM = ent:GetBoneMatrix(b.up), ent:GetBoneMatrix(b.fore), ent:GetBoneMatrix(b.hand)
	if not upM or not foreM or not handM then return false end
	local s, e0, h0 = upM:GetTranslation(), foreM:GetTranslation(), handM:GetTranslation()
	local L = len * 2 * C.Body.reach
	local dx, dy, dz = hx - s.x, hy - s.y, hz - s.z
	local d = math.sqrt(dx * dx + dy * dy + dz * dz)
	if d > L then hx, hy, hz = s.x + dx * L / d, s.y + dy * L / d, s.z + dz * L / d end
	-- (by how much the drawn arm is too short for where its hand should be)
	rec.short = rec.short or {}
	rec.short[i] = d > L and d - L or 0
	local qx, qy, qz, turn = LastPole(rec, i)
	local ex, ey, ez = B.Elbow(i, s.x, s.y, s.z, hx, hy, hz, fx, fy, fz, lx, ly, lz, ux, uy, uz, len, len, tk[1], tk[2], tk[3], tk[4], tk[5], qx, qy, qz, turn)
	rec.pole[i] = Vector(ex, ey, ez)
	rec.poleT = rec.poleT or {}
	rec.poleT[i] = RealTime()
	rec.frame = FrameNumber()
	rec.hand[i] = Vector(hx, hy, hz)
	local m = Matrix()
	m:SetTranslation(rec.hand[i])
	if handAng then
		m:SetAngles(handAng)
	else
		-- A fist on a straight wrist. The hand bone's axes (measured, run fh1): x along the hand
		-- toward the knuckles, y out of the back of the hand, z across (x cross y for both hands).
		-- The back of the hand looks up and outward, as in a guard.
		local xx, xy, xz = M.Norm(hx - ex, hy - ey, hz - ez)
		local o = B.SIDE[i]
		-- (As the forearm comes to stand up, "up" stops saying anything about which way the
		-- back of the hand looks: with it alone a raised fist rolled over. It then looks
		-- outward and forward, as the back of a hand in a high guard does.)
		local high = xx * ux + xy * uy + xz * uz
		if high < 0 then high = 0 end
		local ku, kf = 0.78 * (1 - high), 0.55 * high
		local yx, yy, yz = ux * ku + lx * o * 0.62 + fx * kf, uy * ku + ly * o * 0.62 + fy * kf, uz * ku + lz * o * 0.62 + fz * kf
		local k = yx * xx + yy * xy + yz * xz
		yx, yy, yz = M.Norm(yx - xx * k, yy - xy * k, yz - xz * k)
		local zx, zy, zz = M.Cross(xx, xy, xz, yx, yy, yz)
		m:SetAngles(M.Ang(xx, xy, xz, zx, zy, zz))
	end
	m:SetScale(handM:GetScale())
	if closed and FingerPose(closed, i) then
		ent:SetBoneMatrix(b.hand, m)
		CopyFingers(ent, i, closed, m)
	else
		hg.bone_apply_matrix(ent, b.hand, m)
	end
	return m
end
R.PlaceHand = PlaceHand

-- After Z-City's solver has bent the arms: what this module still has to do with the bones.
-- (hg.DoTPIK is called through the table every frame, so a function put in its place is called.)
function R.AfterIK(ply, ent, rec)
	if R.measure then
		-- for the tests: where the bones really are now
		local bones = Bones(ent)
		rec.meas = rec.meas or { {}, {} }
		for i = 1, 2 do
			local b = bones[i]
			local u, f, h = ent:GetBoneMatrix(b.up), ent:GetBoneMatrix(b.fore), ent:GetBoneMatrix(b.hand)
			if u and f and h then
				rec.meas[i].s, rec.meas[i].e, rec.meas[i].h = u:GetTranslation(), f:GetTranslation(), h:GetTranslation()
				-- (the middle of what a closed hand holds: out along the hand, in toward the palm)
				rec.meas[i].palm = h:GetTranslation() + h:GetForward() * 3.0 + h:GetRight() * 1.1
				rec.meas[i].frame = FrameNumber()
			end
		end
	end
	if R.AfterIKTool then R.AfterIKTool(ply, ent, rec) end
end

local function HookIK()
	if not hg or not hg.DoTPIK or hg.DoTPIK == R.wrapIK then return end
	local orig = hg.DoTPIK
	R.wrapIK = function(ply, ent)
		orig(ply, ent)
		local rec = R.last[ply]
		if rec and rec.frame == FrameNumber() then
			local ok, err = pcall(R.AfterIK, ply, ent, rec)
			if not ok and not R.ikErr then R.ikErr = true FH.Print("after-IK error: %s", tostring(err)) end
		end
	end
	hg.DoTPIK = R.wrapIK
end
R.HookIK = HookIK

-- weapon_hands_sh:SetHandPos while the fists are ours.
function R.FistsSetHandPos(orig, self, noset)
	R.calls = (R.calls or 0) + 1
	local ply = self:GetOwner()
	local rs = IsValid(ply) and FH.RenderHands(ply)
	if not rs or not hg or not hg.bone_apply_matrix then return orig(self, noset) end
	HookIK()
	if not ply.shouldTransmit or ply.NotSeen then return end
	local bones = Bones(ply)
	if not bones.okay then return orig(self, noset) end
	local rec = R.last[ply]
	if not rec then rec = { pole = {}, hand = {} } R.last[ply] = rec end
	-- (what the animation had, for Z-City's blend into and out of its solver)
	ply.rhold = ply:GetBoneMatrix(bones[2].hand)
	ply.lhold = ply:GetBoneMatrix(bones[1].hand)
	local fx, fy, fz, lx, ly, lz, ux, uy, uz = DrawnFrame(rs)
	local tk = DrawnTrunk(ply, rs)
	-- closed hands (cl_tool.lua: a pair of arms whose hands a sequence closes)
	local closed = R.ClosedHands()
	local okL = hg.CanUseLeftHand(ply) and PlaceHand(ply, ply, 1, bones, rs.h[1].x, rs.h[1].y, rs.h[1].z, fx, fy, fz, lx, ly, lz, ux, uy, uz, rec, tk, nil, closed)
	local okR = PlaceHand(ply, ply, 2, bones, rs.h[2].x, rs.h[2].y, rs.h[2].z, fx, fy, fz, lx, ly, lz, ux, uy, uz, rec, tk, nil, closed)
	self.lhandik = okL and true or false
	self.rhandik = okR and true or false
end

-- Z-City's solver asks where the elbow should start from.
hook.Add("IKPoleLeftArm", "FH_Pole", function(ply)
	local rec = R.last[ply]
	if rec and rec.frame == FrameNumber() and rec.pole[1] then return rec.pole[1] end
end)
hook.Add("IKPoleRightArm", "FH_Pole", function(ply)
	local rec = R.last[ply]
	if rec and rec.frame == FrameNumber() and rec.pole[2] then return rec.pole[2] end
end)

------------------------------------------------------------------------------------------
-- Developer drawing (fh_debug): targets, hands, shoulders, elbows.
------------------------------------------------------------------------------------------
local colT, colH, colS, colE = Color(255, 255, 255), Color(90, 255, 120), Color(255, 200, 60), Color(120, 180, 255)
hook.Add("PostDrawTranslucentRenderables", "FH_Debug", function(depth, sky)
	if sky or C.cv.debug:GetInt() < 1 then return end
	render.SetColorMaterialIgnoreZ()
	for _, ply in ipairs(player.GetAll()) do
		local rs = FH.RenderHands(ply)
		if rs then
			for i = 1, 2 do
				render.DrawSphere(Vector(rs.h[i].x, rs.h[i].y, rs.h[i].z), 0.7, 8, 8, rs.h[i].on and colT or colH)
			end
			local rec = R.last[ply]
			if rec and rec.pole[1] and rec.pole[2] then
				render.DrawSphere(rec.pole[1], 0.5, 6, 6, colE)
				render.DrawSphere(rec.pole[2], 0.5, 6, 6, colE)
			end
			local st = FH.states[ply]
			if st and st.active and ply == LocalPlayer() then
				for i = 1, 2 do
					local h = st.h[i]
					render.DrawSphere(Vector(h.wx, h.wy, h.wz), 0.4, 6, 6, colT)
					render.DrawSphere(Vector(h.sx, h.sy, h.sz), 0.5, 6, 6, colS)
				end
			end
		end
	end
end)
