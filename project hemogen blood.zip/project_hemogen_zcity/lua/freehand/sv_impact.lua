-- Server: what a contact does to what was struck.
--
-- A contact arrives from sh_contact.lua as physics: where, along which normal, how fast the two
-- closed on each other, the impulse that passed between them and the energy that was lost in
-- the collision. Here that becomes what Z-City understands: an amount of damage of a kind, at a
-- place, along a direction, as deep and as wide as the thing that struck goes; a push; a sound.
-- How hard somebody is hit is the energy, and nothing else: a slow blow, a glancing one, a blow
-- with the flat of an axe or with the handle are weak because their numbers are small.

local FH = FreeHand
local C, M = FH.Config, FH.Math
FH.Impact = FH.Impact or {}
local I = FH.Impact
local min, max = math.min, math.max

-- when a weapon last wounded a thing, and how hard: weapon -> { [entity] = { t, e } }
local lastHit = setmetatable({}, { __mode = "k" })
local function Again(wep, ent, energy, now)
	local w = lastHit[wep]
	if not w then w = setmetatable({}, { __mode = "k" }) lastHit[wep] = w end
	local e = w[ent]
	if not e then e = { t = -10, e = 0 } w[ent] = e end
	local recent = now - e.t < C.Hit.again
	if recent and energy < e.e * 2 then return false end
	e.e = recent and max(e.e, energy) or energy
	e.t = now
	return true
end

local lastSound = setmetatable({}, { __mode = "k" })
local function Sound(wep, name, pos, level, pitch)
	if not name or name == "" then return end
	local now = CurTime()
	if lastSound[wep] and now - lastSound[wep] < 0.07 then return end
	lastSound[wep] = now
	sound.Play(name, pos, level, pitch, 1)
end

local function IsHead(ent, c)
	if c.hitgroup == HITGROUP_HEAD then return true end
	if ent:IsRagdoll() then
		local bone = ent:TranslatePhysBoneToBone(c.physbone or 0)
		local name = bone and ent:GetBoneName(bone) or ""
		return string.find(name, "Head", 1, true) ~= nil
	end
	return false
end

-- How much damage, and of which kind, a blow of this energy with this place of this weapon is.
-- A weapon's own number in Z-City (what one of its swings did) is what a solid blow does here.
local function Damage(wep, prof, c)
	local d = prof.damage
	local base = d.base or ((tonumber(wep.DamagePrimary) or 20) / 1.5)
	local k = min(c.energy / d.ref, d.cap or 3)
	local dmg = base * k
	local dtype = prof.damageType
	local cut = false
	if c.kind == "edge" then
		-- a blade cuts when it leads; turned, it is a club that is badly shaped for it
		if c.edge >= C.Hit.edgeCut then
			cut = true
			dmg = dmg * (0.7 + 0.5 * c.edge)
		else
			dtype = DMG_CLUB
			dmg = dmg * 0.55
		end
	elseif c.kind == "head" then
		dtype = DMG_CLUB                       -- the back of an axe's head
		dmg = dmg * 0.8
	elseif c.kind == "bar" and prof.damageType == DMG_SLASH then
		dtype = DMG_CLUB                       -- an axe's handle
		dmg = dmg * 0.45
	elseif c.kind == "hook" then
		dmg = dmg * 1.15
	end
	return dmg * C.cv.damage:GetFloat(), dtype, cut, k
end

-- Another fighter's weapon or forearm was in the way.
local function Blocked(ply, wep, st, prof, c, hard)
	local other = c.target
	local pos = Vector(c.x, c.y, c.z)
	if FH.OnBlock then FH.OnBlock(ply, other, c) end
	if not hard then return end
	if c.block == "tool" then
		-- steel on steel (or wood)
		local level = 62 + min(c.energy / 40, 1) * 16
		Sound(wep, prof.kind == "fists" and "Flesh.ImpactHard" or (wep.AttackHit or "Weapon_Crowbar.Melee_HitWorld"), pos, level, 105)
		if FH.React then FH.React.Jolt(ply, c) FH.React.Jolt(other, c) end
		return
	end
	-- a forearm: it takes the blow, and what a forearm can take is not much
	if not IsValid(other) or not Again(wep, other, c.energy, CurTime()) then return end
	local dmg, dtype, cut = Damage(wep, prof, c)
	dmg = dmg * C.Hit.armBlock
	Sound(wep, prof.kind == "fists" and "Flesh.ImpactHard" or (wep.AttackHitFlesh or "Flesh.ImpactHard"), pos, 60 + min(c.energy / 40, 1) * 12, 100)
	-- (Z-City looks for the wound along the blow from where it was given. The forearm that
	-- stopped it is where the simulation has it; the forearm Z-City can wound is where the
	-- animation under it has it: the damage is given there, or it would go to what is behind)
	local bone = other:LookupBone(c.blockArm == 1 and "ValveBiped.Bip01_L_Forearm" or "ValveBiped.Bip01_R_Forearm")
	local bp = bone and other:GetBonePosition(bone)
	if bp and bp ~= other:GetPos() then c.x, c.y, c.z = bp.x - c.dx * 3, bp.y - c.dy * 3, bp.z - c.dz * 3 end
	I.Hurt(ply, wep, prof, other, other, c, dmg, dtype, cut, false)
	if FH.React then FH.React.Body(other, ply, c, "arm") end
end

-- The damage itself, the way Z-City's own weapons give it.
function I.Hurt(ply, wep, prof, ent, target, c, dmg, dtype, cut, head)
	if FH.OnHurt then FH.OnHurt(ply, target, dmg, dtype, cut, c) end
	local dir = Vector(c.dx, c.dy, c.dz)
	local pos = Vector(c.x, c.y, c.z)
	local di = DamageInfo()
	di:SetAttacker(ply)
	di:SetInflictor(wep)
	di:SetDamage(dmg)
	di:SetDamageType(dtype)
	di:SetDamagePosition(pos)
	-- (Z-City reads the direction of the wound from the force, and its length as how hard the
	-- body is thrown: its own weapons give the damage as that length)
	di:SetDamageForce(dir * max(dmg, 1))
	-- How deep and how wide the wound goes Z-City reads from the weapon. A blade that leads goes
	-- as deep as the weapon's own number says, less for a weaker blow; anything blunt stays shallow.
	local pen, size = wep.Penetration, wep.PenetrationSize
	local k = M.Clamp(c.energy / prof.damage.ref, 0.3, 1.4)
	if prof.kind ~= "fists" then
		local full = tonumber(wep.PenetrationPrimary) or 3
		wep.Penetration = (cut and full or min(full, 3)) * k
		wep.PenetrationSize = tonumber(wep.PenetrationSizePrimary) or 3
	end
	if head and FH.React then FH.React.BeforeHead(target, ply, c) end
	-- (should the damage, or anything after it, put the player down: sv_react.lua, "The fall")
	if FH.React then FH.React.Struck(target, c) end
	wep.FH_blow = c
	local ok, err = pcall(ent.TakeDamageInfo, ent, di)
	wep.FH_blow = nil
	wep.Penetration, wep.PenetrationSize = pen, size
	if not ok then FH.Print("damage error: %s", tostring(err)) end
	-- what Z-City's weapons do after their damage: the force a ragdoll starts with, should the
	-- body fall now
	if IsValid(target) and hg and hg.AddForceRag then
		hg.AddForceRag(target, c.physbone or 0, dir * min(c.impulse * C.React.ragPerNs, C.React.ragMax), 0.5)
	end
end

function I.Blow(ply, wep, st, prof, c)
	local H = C.Hit
	if FH.OnBlow then FH.OnBlow(ply, c) end
	local hard = not c.pressing and c.closing >= H.minSpeed and c.energy >= H.minEnergy
	if c.block then return Blocked(ply, wep, st, prof, c, hard) end
	if not hard then return end
	local ent, target = c.ent, c.target
	local pos = Vector(c.x, c.y, c.z)
	local now = CurTime()
	local level = 58 + min(c.energy / prof.damage.ref, 1.2) * 16

	-- the world, or something in it that is not alive
	if not c.soft then
		Sound(wep, prof.kind == "fists" and "Flesh.ImpactSoft" or (wep.AttackHit or "Concrete.ImpactHard"), pos, level, 100)
		if FH.React then FH.React.Jolt(ply, c) end
		if IsValid(ent) then
			if not Again(wep, ent, c.energy, now) then return end
			local dmg, dtype = Damage(wep, prof, c)
			local phys = ent:GetPhysicsObjectNum(c.physbone or 0)
			if IsValid(phys) and phys:IsMotionEnabled() then
				-- (an impulse in the engine's own units: kg inch / s)
				phys:ApplyForceOffset(Vector(c.dx, c.dy, c.dz) * (c.impulse * FH.M2U), pos)
			end
			local di = DamageInfo()
			di:SetAttacker(ply)
			di:SetInflictor(wep)
			di:SetDamage(dmg)
			di:SetDamageType(ent:GetClass() == "func_breakable_surf" and DMG_SLASH or dtype)
			di:SetDamagePosition(pos)
			di:SetDamageForce(Vector(c.dx, c.dy, c.dz) * max(dmg, 1))
			ent:TakeDamageInfo(di)
			-- (what Z-City's own class does to a door it has hit hard, with its own chances)
			if c.energy >= prof.damage.ref * 0.6 and wep.PrimaryAttackAdd and prof.kind ~= "fists" then
				pcall(wep.PrimaryAttackAdd, wep, ent, { Entity = ent, HitPos = pos, HitNormal = Vector(c.nx, c.ny, c.nz), Normal = Vector(c.dx, c.dy, c.dz) })
			end
		elseif prof.kind ~= "fists" and c.energy >= prof.damage.ref * 0.5 and (tonumber(wep.weight) or 0) >= 1.4 then
			-- a heavy tool leaves a mark on a wall (Z-City's own marks, taken in turn)
			local n = Vector(c.nx, c.ny, c.nz)
			local name = prof.damageType == DMG_SLASH and "ManhackCut" or ("Impact.BluntAdd" .. (1 + st.tick % 4))
			util.Decal(name, pos + n, pos - n, ply)
		end
		return
	end

	if not IsValid(ent) or not Again(wep, IsValid(target) and target or ent, c.energy, now) then return end
	local dmg, dtype, cut = Damage(wep, prof, c)
	local head = IsHead(ent, c)
	Sound(wep, prof.kind == "fists" and "Flesh.ImpactHard" or (wep.AttackHitFlesh or "Flesh.ImpactHard"), pos, level, 100)
	if FH.React then FH.React.Jolt(ply, c) end
	I.Hurt(ply, wep, prof, ent, target, c, dmg, dtype, cut, head)
	if not IsValid(ent) then return end
	if IsValid(target) then
		if FH.React then
			if head then FH.React.Head(target, ply, c, prof) else FH.React.Body(target, ply, c, nil) end
		end
	end
	-- a body that lies, or a thing that is alive and no player: pushed where it was struck
	if ent:IsRagdoll() or not IsValid(target) then
		local phys = ent:GetPhysicsObjectNum(c.physbone or 0)
		if IsValid(phys) then phys:ApplyForceOffset(Vector(c.dx, c.dy, c.dz) * (c.impulse * FH.M2U), pos) end
	end
end
