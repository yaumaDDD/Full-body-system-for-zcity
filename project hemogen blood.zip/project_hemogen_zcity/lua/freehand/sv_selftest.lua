-- Test scenes of the free-hand module (developer tool). They run inside the blood module's
-- harness (lua/advancedblood/server/sv_selftest.lua), which exists only when
-- garrysmod/data/abl_selftest.txt does, and only when asked for by name.
-- docs/FREEHAND_TESTING.md says what each scene measures.

local FH = FreeHand
if not (istable(ABL) and istable(ABL.SelfTest)) then return end
local S = ABL.SelfTest
local Log, Wait = S.Log, S.Wait
local C, M, B, Sim = FH.Config, FH.Math, FH.Body, FH.Sim
local V = Vector

FH.TestLog = Log
FH.Test = FH.Test or {}
local T = FH.Test

------------------------------------------------------------------------------------------
-- Helpers
------------------------------------------------------------------------------------------
util.AddNetworkString("fh_t")
local results = {}
net.Receive("fh_t", function(_, ply)
	if ply ~= S.Host() then return end
	local tag = net.ReadString()
	results[tag] = net.ReadTable()
end)

-- Sends a request to the host's client and waits for what it answers under `tag`.
local function Ask(cmd, t, tag, seconds)
	results[tag] = nil
	t = t or {}
	t.tag = tag
	S.Client(cmd, t)
	local t0 = CurTime()
	while not results[tag] and CurTime() - t0 < (seconds or 3) do Wait(0.05) end
	return results[tag]
end
T.Ask = Ask

local pass, fail = 0, 0
local function Check(what, ok, detail)
	if ok then pass = pass + 1 else fail = fail + 1 end
	Log("    %s %s%s", ok and "PASS" or "FAIL", what, detail and detail ~= "" and (" (" .. detail .. ")") or "")
	return ok
end
local function Tally(name)
	Log("  == %s: %d checks passed, %d failed", name, pass, fail)
	pass, fail = 0, 0
end
T.Check, T.Tally = Check, Tally

-- A list of moves played into a fighter's input, one entry for n ticks:
--   { L = true, R = true, depth = true, grip = true, mx = counts a tick, my = counts a tick, n = ticks }
-- Returns a function that says whether the list is through. After it the last entry's buttons
-- stay held with a still mouse when `hold` is set (a hand that is let go returns to its guard).
local function Play(ply, moves, hold)
	local i, left = 1, moves[1] and moves[1].n or 0
	local done = false
	local still
	FH.TestInput[ply] = function()
		while i <= #moves and left <= 0 do
			i = i + 1
			left = moves[i] and moves[i].n or 0
		end
		local m = moves[i]
		if not m then
			done = true
			if hold then
				local last = moves[#moves]
				still = still or { L = last.L, R = last.R, depth = last.depth, mx = 0, my = 0 }
				return still
			end
			return nil
		end
		left = left - 1
		return m
	end
	return function() return done end
end
T.Play = Play

local function WaitFor(fn, seconds)
	local t0 = CurTime()
	while not fn() and CurTime() - t0 < (seconds or 5) do Wait(0.05) end
end

-- Where a scene's bots look. (An engine bot's commands carry its own idea of that every tick, and
-- what is set on the player between two of them is gone with the next.)
T.aim = T.aim or setmetatable({}, { __mode = "k" })
local function Aim(bot, pitch, yaw)
	T.aim[bot] = Angle(pitch, yaw, 0)
	S.Drive(bot, function(ply, cmd)
		local a = T.aim[ply]
		if a then cmd:SetViewAngles(a) ply:SetEyeAngles(a) end
	end)
end
T.Aim = Aim

-- A bot standing at a spot with raised fists, held by this module.
local function Fighter(p, yaw, class, prep)
	local bot = S.NewBot()
	if not IsValid(bot) then return nil end
	-- (Z-City gives a player its drawing, arms included, when the client hears that it spawned;
	-- a bot that has just joined is not known to the client yet when it first spawns)
	Wait(0.8)
	bot:Spawn()
	Wait(0.6)
	S.Place(bot, p, yaw)
	Aim(bot, 0, yaw)
	Wait(0.6)
	if istable(bot.organism) then bot.organism.godmode = true end
	class = class or "weapon_hands_sh"
	if prep then prep(bot) end
	-- (a bot that is used again still carries what the scene before gave it)
	for other in pairs(C.Classes) do
		if other ~= class and other ~= "weapon_hands_sh" and bot:HasWeapon(other) then bot:StripWeapon(other) end
	end
	if not bot:HasWeapon(class) then bot:Give(class) end
	bot:SelectWeapon(class)
	Wait(0.4)
	local wep = bot:GetActiveWeapon()
	if IsValid(wep) and wep.SetFists then wep:SetFists(true) end
	FH.TestInput[bot] = function() return nil end
	Wait(0.6)
	return bot, wep
end
T.Fighter = Fighter

local function Rel(st, i)
	local h = st.h[i]
	return h.px - st.bx, h.py - st.by, h.pz - st.bz
end
T.WaitFor, T.Rel = WaitFor, Rel

-- Whether a place is clear for a fighter to swing in: a level floor under it, and nothing (wall
-- or thing) within r units at the heights a weapon is swung at, in sixteen directions, nor
-- over it. Returns the floor, or nil.
local function ClearAt(c, r)
	local down = util.TraceLine({ start = c + V(0, 0, 40), endpos = c - V(0, 0, 40), mask = MASK_SOLID_BRUSHONLY })
	if not down.Hit or down.StartSolid or down.HitNormal.z < 0.97 then return nil end
	local floor = down.HitPos
	local all = player.GetAll()
	for _, z in ipairs({ 16, 44, 72, 100 }) do
		local from = floor + V(0, 0, z)
		for i = 0, 15 do
			local a = i * math.pi / 8
			if util.TraceLine({ start = from, endpos = from + V(math.cos(a) * r, math.sin(a) * r, 0), mask = MASK_SHOT, filter = all }).Hit then return nil end
		end
	end
	if util.TraceLine({ start = floor + V(0, 0, 8), endpos = floor + V(0, 0, 130), mask = MASK_SHOT, filter = all }).Hit then return nil end
	return floor
end

-- The host put where nobody else stands and nothing is in reach (a weapon that lies against
-- another player's body is stopped by it, and the client's idea of where that body is is not
-- the server's; a weapon that touches a wall is stopped by the wall: a scene that compares the
-- host's own prediction with the server needs the host alone and in the open). At p, or at the
-- nearest place about it that is clear. opts.ahead: clear that far along +x too, for a host
-- that walks (it looks along +x); opts.see: a place that has to be in sight from there (Z-City
-- does not place the arms of a player the local player cannot see). Returns how far the
-- nearest other player is, and whether a clear place was found.
-- (Until run fh44 the host was put 220 units beside the scene's spot, unlooked at. In some
-- runs that was at a wall: the host's weapon touched it, a walk ended after 22 units, and
-- from behind a wall the scene's bot was not drawn.)
function T.HostAlone(host, p, opts)
	opts = opts or {}
	local clear
	if p then
		local function Good(c)
			local floor = ClearAt(c, 80)
			if not floor then return nil end
			for _, other in ipairs(player.GetAll()) do
				if other ~= host and other:Alive() and other:GetPos():DistToSqr(floor) < 200 * 200 then return nil end
			end
			if opts.ahead then
				for d = 60, opts.ahead, 60 do
					local f2 = ClearAt(floor + V(d, 0, 0), 80)
					if not f2 or math.abs(f2.z - floor.z) > 4 then return nil end
				end
			end
			if opts.see and util.TraceLine({ start = floor + V(0, 0, 64), endpos = opts.see + V(0, 0, 50), mask = MASK_SOLID_BRUSHONLY }).Hit then return nil end
			return floor
		end
		local at = Good(p)
		for ring = 1, 5 do
			if at then break end
			for k = 0, 11 do
				local a = k * math.pi / 6
				at = Good(p + V(math.cos(a), math.sin(a), 0) * ring * 70)
				if at then break end
			end
		end
		clear = at ~= nil
		host:SetPos(at or p)
		host:SetLocalVelocity(Vector(0, 0, 0))
	end
	local near = math.huge
	for _, other in ipairs(player.GetAll()) do
		if other ~= host and other:Alive() then near = math.min(near, other:GetPos():Distance(host:GetPos())) end
	end
	return near, clear
end
-- The same, as a line for the log.
function T.HostPlace(host, p, opts)
	local near, clear = T.HostAlone(host, p, opts)
	return string.format("the host stands %.0f units from the nearest other player, %s", near,
		clear and "with nothing within 80 units of it" or "AT A PLACE THAT WAS NOT FOUND CLEAR")
end

-- The host's own settings for a scene that is about settings: put in on the client (which keeps
-- what was there), and waited for until the server has heard of them. T.Prefs(host): put back.
function T.Prefs(host, set)
	if not set then
		S.Client("fhprefs", { restore = true })
		Wait(0.4)
		FH.testPrefs = nil
		return
	end
	FH.testPrefs = true
	S.Client("fhprefs", { set = set })
	WaitFor(function()
		for name, v in pairs(set) do if host:GetInfo(name) ~= tostring(v) then return false end end
		return true
	end, 3)
	Wait(0.3)
end

-- In what two dumps of a state differ (sh_sim.lua, S.Dump), as text. Counters that each side
-- keeps for itself are left out.
local OWN = { tick = true, pressTick = true, contactTick = true, stamp = true, simTick = true, cmd = true, work = true, gone = true, fixes = true, active = true, ok = true }
function T.DumpDiff(c, s)
	if not c or not s then return "one side has no record of it" end
	local keys = {}
	for k in pairs(c) do if not OWN[k] then keys[k] = true end end
	for k in pairs(s) do if not OWN[k] then keys[k] = true end end
	local names = {}
	for k in pairs(keys) do
		local a, b = c[k], s[k]
		if a == nil or b == nil or math.abs(a - b) > 1e-4 then names[#names + 1] = k end
	end
	table.sort(names)
	if #names == 0 then return "the same in everything" end
	local parts = {}
	for i = 1, math.min(#names, 28) do
		local k = names[i]
		parts[#parts + 1] = string.format("%s %s|%s", k, c[k] and string.format("%.4f", c[k]) or "-", s[k] and string.format("%.4f", s[k]) or "-")
	end
	return string.format("%d differ (client|server): %s%s", #names, table.concat(parts, ", "), #names > 28 and ", ..." or "")
end
-- The client's dumps for some commands against the server's, into the log.
function T.DumpCompare(Ask, Log, sdump, list, firstBad)
	local want, seen = {}, {}
	local function Add(k) local e = list[k] if e and not seen[e[1]] then seen[e[1]] = true want[#want + 1] = e[1] end end
	Add(1)
	for k = firstBad - 3, firstBad do Add(k) end
	local r = Ask("fhinput", { dump = want }, "dump", 3) or {}
	for _, n in ipairs(want) do
		local c = r[tostring(n)]
		Log("    command %d (corrections so far on the client: %s): %s", n, tostring(c and c.fixes), T.DumpDiff(c, sdump[n]))
	end
end

function T.PredictionNotes(host, server, list)
	local low, high = 1e9, -1e9
	return function(note)
		if note then
			local k = host:GetNW2Float("fh_str", 1)
			low, high = math.min(low, k), math.max(high, k)
			return
		end
		if low > high then low, high = host:GetNW2Float("fh_str", 1), host:GetNW2Float("fh_str", 1) end
		local ns, nc, both = 0, list and #list or 0, 0
		for _ in pairs(server) do ns = ns + 1 end
		for _, e in ipairs(list or {}) do if server[e[1]] then both = both + 1 end end
		return string.format("the server stepped %d commands, the client recorded %d, %d are in both; the arms' strength was %.3f to %.3f; the eye %.1f over the feet, the body at %.1f units/s",
			ns, nc, both, low, high, host:GetCurrentViewOffset().z, host:GetVelocity():Length())
	end
end

------------------------------------------------------------------------------------------
-- fh_probe: what the game really has. No judgement, numbers for sh_config.lua.
------------------------------------------------------------------------------------------
S.Add("fh_probe", function()
	Log("-- the classes this module takes over")
	Log("  patched %s class(es); fh_enabled %s", tostring(FH.Patch.count), tostring(C.cv.enabled:GetBool()))
	for class in pairs(C.Classes) do
		local t = weapons.GetStored(class)
		if not t then
			Log("  %s: NOT REGISTERED", class)
		else
			Log("  %s: base %s | world %s | real %s | exchange %s | basebone %s | weaponPos %s weaponAng %s | two-handed %s | hold %s | weight %s | damage %s %s",
				class, tostring(t.Base), tostring(t.WorldModel), tostring(t.WorldModelReal), tostring(t.WorldModelExchange), tostring(t.basebone),
				tostring(t.weaponPos), tostring(t.weaponAng), tostring(t.TwoHanded), tostring(t.HoldType), tostring(t.weight), tostring(t.DamagePrimary), tostring(t.DamageSecondary))
		end
	end
	for class, prof in pairs(C.Weapons) do
		if prof.kind == "tool" then
			Log("  profile %s: %.2f kg, %.0f cm, centre of mass %.0f cm from the butt, inertia %.4f kg m2 (axial %.5f)", class, prof.mass, prof.length * 100, prof.comM * 100, prof.inertiaT, prof.inertiaA)
		end
	end

	local p = S.FindSpot({ open = 170, outdoor = true })
	local bot = Fighter(p, 0)
	if not IsValid(bot) then Log("no bot") return end
	S.View(p + V(95, 40, 62), p + V(0, 0, 46))
	Wait(1.0)

	Log("-- the body: bones in the frame of the eye's yaw, from the feet (forward, left, up)")
	local wep = bot:GetActiveWeapon()
	local function Body(tag, pitch, fists)
		Aim(bot, pitch, 0)
		if IsValid(wep) and wep.SetFists then wep:SetFists(fists) end
		Wait(0.9)
		local r = Ask("fhprobe", { ent = bot:EntIndex(), what = "body", name = tag }, "probe", 3)
		Log("  %s: eye height %.1f (server), view offset %s, crouching %s | client says %s", tag, bot:EyePos().z - bot:GetPos().z, tostring(bot:GetCurrentViewOffset()), tostring(bot:Crouching()), r and r.ok and "done" or "nothing")
	end
	Body("standing, hands down, level", 0, false)
	Body("standing, fists, level", 0, true)
	S.Shot("fh_probe_fists")
	Body("standing, fists, looking 45 up", -45, true)
	Body("standing, fists, looking 45 down", 45, true)
	Aim(bot, 0, 0)

	Log("-- the weapons' models")
	for class, prof in pairs(C.Weapons) do
		if prof.kind == "tool" then
			local t = weapons.GetStored(class) or {}
			Ask("fhprobe", { what = "model", name = class, prop = prof.model.path, real = t.WorldModelReal, exchange = t.WorldModelExchange or t.WorldModel,
				basebone = t.basebone, weaponPos = t.weaponPos, weaponAng = t.weaponAng, idle = t.AnimList and t.AnimList.idle }, "probe", 3)
		end
	end

	Log("-- the mouse on its way to the server (the host's own commands)")
	local host = S.Host()
	if not host:HasWeapon("weapon_hands_sh") then host:Give("weapon_hands_sh") end
	host:SelectWeapon("weapon_hands_sh")
	Wait(0.5)
	local hw = host:GetActiveWeapon()
	if IsValid(hw) and hw.SetFists then hw:SetFists(true) end
	Wait(0.5)
	local got = {}
	FH.OnCmd = function(ply, cmd, inp)
		if ply == host then got[#got + 1] = { cmd:CommandNumber(), cmd:GetMouseX(), cmd:GetMouseY(), inp.L, inp.R, cmd:GetButtons() } end
	end
	S.Client("fhinput", { moves = { { R = true, mx = 17, my = -9, n = 20 }, { L = true, R = true, mx = -5, my = 3, n = 10 } } })
	Wait(1.5)
	FH.OnCmd = nil
	local seen17, seen5, any = 0, 0, 0
	for _, g in ipairs(got) do
		any = any + 1
		if g[2] == 17 and g[3] == -9 and g[5] and not g[4] then seen17 = seen17 + 1 end
		if g[2] == -5 and g[3] == 3 and g[5] and g[4] then seen5 = seen5 + 1 end
	end
	Log("  the server stepped the host %d times; of 20 commands with (17, -9) and the right hand it saw %d, of 10 with (-5, 3) and both hands %d", any, seen17, seen5)
	if got[1] then Log("  first: cmd %d mouse %d %d L %s R %s buttons %d", got[1][1], got[1][2], got[1][3], tostring(got[1][4]), tostring(got[1][5]), got[1][6]) end
	Check("the mouse's movement reaches the server inside the command", seen17 >= 18 and seen5 >= 8, string.format("%d of 20, %d of 10", seen17, seen5))
	S.Client("fhinput", {})
	Tally("fh_probe")
end)

------------------------------------------------------------------------------------------
-- fh_hands: the gate before any weapon. Two hands that go where the mouse sends them, each by
-- itself; arms that follow without stretching and without an elbow in the chest; the same
-- hands on the client as on the server.
------------------------------------------------------------------------------------------
S.Add("fh_hands", function()
	local p = S.FindSpot({ open = 170, outdoor = true })
	-- (the host where it can see the scene's bot: T.HostAlone)
	T.HostAlone(S.Host(), p + V(0, -220, 0), { see = p })
	local bot = Fighter(p, 0)
	if not IsValid(bot) then Log("no bot") return end
	local st = FH.State(bot)
	S.Client("fhmeasure", { on = true })
	RunConsoleCommand("fh_debug", "1")
	local front, side, top = p + V(88, 0, 60), p + V(6, -88, 58), p + V(26, 0, 140)
	local look = p + V(4, 0, 50)
	S.View(front, look)
	Wait(1.2)
	Check("the module holds the bot's fists", st.active == true and st.ok == true, string.format("active %s", tostring(st.active)))

	local L = B.ArmLength()
	local worst = { hand = 0, len = 0, elbowIn = 0, net = 0 }
	local nMeasured = 0

	-- one posture: what the server has, what the client drew, what the bones did
	local function Measure(tag, shot)
		Wait(0.55)
		local r = Ask("fhmeasure", { ent = bot:EntIndex(), get = true }, "meas", 3)
		if not r or not r.h then Log("  %s: the client did not answer", tag) fail = fail + 1 return end
		nMeasured = nMeasured + 1
		local line = {}
		for i = 1, 2 do
			local sx, sy, sz = Rel(st, i)
			local m = r.h[i]
			-- the hand the client drew against the hand the server has
			local dn = math.sqrt((m.dx - sx) ^ 2 + (m.dy - sy) ^ 2 + (m.dz - sz) ^ 2)
			-- the bone against the hand that was to be drawn (an arm that cannot reach is short by r.clamp)
			local db = math.sqrt((m.bx - m.dx) ^ 2 + (m.by - m.dy) ^ 2 + (m.bz - m.dz) ^ 2)
			worst.net = math.max(worst.net, dn)
			worst.hand = math.max(worst.hand, math.max(db - (m.clamp or 0), 0))
			worst.len = math.max(worst.len, math.abs(m.upper / m.bone - 1), math.abs(m.fore / m.bone - 1))
			worst.elbowIn = math.max(worst.elbowIn, m.elbowIn or 0)
			local az, el, ext = B.TargetPolar(i, st.h[i].tf, st.h[i].tl, st.h[i].tu)
			line[#line + 1] = string.format("%s target across %.0f up %.0f reach %.0f%% | hand (%.1f %.1f %.1f) drawn off by %.2f, bone off by %.2f (short %.2f) | upper %.2f fore %.2f of %.2f | elbow %.1f from the trunk's middle, %.1f inside",
				i == 1 and "L" or "R", az, el, ext / L * 100, sx, sy, sz, dn, db, m.clamp or 0, m.upper, m.fore, m.bone, m.elbowDist or -1, m.elbowIn or 0)
		end
		Log("  %s", tag)
		Log("     %s", line[1])
		Log("     %s", line[2])
		if tag == "guard" then
			Log("     where the bot looks: placed at yaw 0 | the server's eye %.1f, stepped with %.1f | the client drew with %.1f, its eye %.1f",
				bot:EyeAngles().y, st.yaw, r.yawDrawn or -1, r.yawEye or -1)
			Check("the bot looks where it was put, on the server and on the client", math.abs(math.AngleDifference(st.yaw, 0)) < 1 and math.abs(math.AngleDifference(r.yawDrawn or 999, 0)) < 1)
		end
		if shot then S.Shot("fh_hands_" .. shot) end
	end

	Log("-- at the guard")
	Measure("guard", "guard_front")
	S.View(side, look) Wait(0.4) S.Shot("fh_hands_guard_side")
	S.View(front, look)

	Log("-- the right hand alone, over the range of its shoulder")
	local function Go(tag, moves, shot)
		WaitFor(Play(bot, moves, true), 6)
		Measure(tag, shot)
	end
	local lBefore = { Rel(st, 1) }
	Go("right: up", { { R = true, mx = 0, my = -55, n = 22 } }, "r_up")
	Go("right: up and out to the side", { { R = true, mx = 60, my = 0, n = 26 } }, "r_up_out")
	Go("right: down at the side", { { R = true, mx = 0, my = 60, n = 44 } }, "r_down_out")
	Go("right: low across the body", { { R = true, mx = -60, my = 0, n = 60 } }, "r_low_across")
	Go("right: high across the body", { { R = true, mx = 0, my = -60, n = 50 } }, "r_high_across")
	Go("right: straight out in front (depth)", { { R = true, mx = 40, my = 30, n = 30 }, { R = true, depth = true, mx = 0, my = -60, n = 30 } }, "r_reach")
	S.View(side, look) Wait(0.4) S.Shot("fh_hands_r_reach_side") S.View(front, look)
	Go("right: pulled in to the chest (depth)", { { R = true, depth = true, mx = 0, my = 60, n = 60 } }, "r_pulled")
	local lAfter = { Rel(st, 1) }
	local lMoved = math.sqrt((lAfter[1] - lBefore[1]) ^ 2 + (lAfter[2] - lBefore[2]) ^ 2 + (lAfter[3] - lBefore[3]) ^ 2)
	Check("the left hand stayed where it was while the right one went everywhere", lMoved < 1.0, string.format("it moved %.2f units", lMoved))

	Log("-- the left hand alone")
	-- (the right hand is let go first: a hand that is let go returns to its guard)
	FH.TestInput[bot] = function() return nil end
	Wait(1.8)
	local rBefore = { Rel(st, 2) }
	Go("left: up", { { L = true, mx = 0, my = -55, n = 22 } }, "l_up")
	Go("left: out to the side", { { L = true, mx = -60, my = 0, n = 26 } }, "l_out")
	Go("left: across, low", { { L = true, mx = 60, my = 50, n = 50 } }, "l_across_low")
	Go("left: overhead", { { L = true, mx = -30, my = -70, n = 60 } }, "l_overhead")
	S.View(side, look) Wait(0.4) S.Shot("fh_hands_l_overhead_side") S.View(front, look)
	local rAfter = { Rel(st, 2) }
	local rMoved = math.sqrt((rAfter[1] - rBefore[1]) ^ 2 + (rAfter[2] - rBefore[2]) ^ 2 + (rAfter[3] - rBefore[3]) ^ 2)
	Check("the right hand, let go, stayed at its guard while the left one moved", rMoved < 1.0, string.format("it moved %.2f units", rMoved))

	Log("-- both at once")
	Go("both: up together", { { L = true, R = true, mx = 0, my = -50, n = 30 } }, "both_up")
	Go("both: to the right together", { { L = true, R = true, mx = 60, my = 30, n = 30 } }, "both_right")
	S.View(top, look) Wait(0.4) S.Shot("fh_hands_both_right_top") S.View(front, look)

	Log("-- let go: back to the guard")
	FH.TestInput[bot] = function() return nil end
	Wait(2.6)
	Measure("after letting go", "released")
	local gf, gl, gu = Sim.GuardTarget(st, st.prof, 2)
	local back = math.sqrt((st.h[2].tf - gf) ^ 2 + (st.h[2].tl - gl) ^ 2 + (st.h[2].tu - gu) ^ 2)
	Check("a hand that is let go returns to its guard", back < 0.6, string.format("%.2f units from it after 2.6 s", back))

	Log("-- how a hand moves: a hard pull to one side (speed and overshoot)")
	do
		local peak, travel, maxOver = 0, 0, 0
		local x0, y0, z0 = Rel(st, 2)
		-- (sampled inside the step, every tick: a scene's own clock is too coarse for a peak)
		local far = 0
		FH.OnCmd = function(ply, cmd, inp, s)
			if ply ~= bot then return end
			local h = s.h[2]
			peak = math.max(peak, math.sqrt((h.vx - s.bvx) ^ 2 + (h.vy - s.bvy) ^ 2 + (h.vz - s.bvz) ^ 2) * FH.U2M)
			far = math.max(far, math.sqrt((h.px - s.bx - x0) ^ 2 + (h.py - s.by - y0) ^ 2 + (h.pz - s.bz - z0) ^ 2))
		end
		Play(bot, { { R = true, mx = 500, my = 0, n = 5 } }, true)
		Wait(1.2)
		FH.OnCmd = nil
		local x1, y1, z1 = Rel(st, 2)
		travel = math.sqrt((x1 - x0) ^ 2 + (y1 - y0) ^ 2 + (z1 - z0) ^ 2)
		Log("  a flick of 2500 counts in 5 ticks: the hand came to rest %.1f units (%.0f cm) away, was at most %.1f away (overshoot %.1f), peak speed %.1f m/s", travel, travel * FH.U2M * 100, far, far - travel, peak)
		Check("a flicked hand is fast and not instant", peak > 3.5 and peak < 16, string.format("%.1f m/s", peak))
		Check("and does not swing far past where it was sent", far - travel < 2.5, string.format("%.1f units past", far - travel))
	end

	Log("-- the body moves: the hands come along")
	do
		FH.TestInput[bot] = function() return nil end
		Wait(3.5)
		local before = { Rel(st, 2) }
		bot:SetPos(p + V(0, 40, 2))
		Wait(1.2)
		local after = { Rel(st, 2) }
		local d = math.sqrt((after[1] - before[1]) ^ 2 + (after[2] - before[2]) ^ 2 + (after[3] - before[3]) ^ 2)
		Check("after the body is moved 40 units the hands are where they were on it", d < 0.8, string.format("%.2f units off", d))
		bot:SetPos(p + V(0, 0, 2))
		Wait(0.5)
	end

	Log("-- over all %d postures", nMeasured)
	Check("the hand the client draws is the hand the server has", worst.net < 1.2, string.format("worst %.2f units", worst.net))
	Check("the hand bone is on the simulated hand (but for what an arm cannot reach)", worst.hand < 1.2, string.format("worst %.2f units", worst.hand))
	Check("no arm is stretched or shortened", worst.len < 0.06, string.format("worst %.1f %% of a bone", worst.len * 100))
	Check("no elbow is inside the trunk", worst.elbowIn < 1.0, string.format("deepest %.2f units", worst.elbowIn))

	Log("-- the host's own hands: predicted on the client, stepped on the server from the same commands")
	do
		local host = S.Host()
		if not host:HasWeapon("weapon_hands_sh") then host:Give("weapon_hands_sh") end
		host:SelectWeapon("weapon_hands_sh")
		Wait(0.5)
		local hw = host:GetActiveWeapon()
		if IsValid(hw) and hw.SetFists then hw:SetFists(true) end
		host:SetEyeAngles(Angle(8, 0, 0))
		if T.Rested then T.Rested(host) end
		Log("  (%s)", T.HostPlace(host, p + Vector(0, -220, 0), { see = p }))
		Wait(0.8)
		local hs = FH.State(host)
		local server = {}
		local notes
		-- (After the server's contacts, as the client's record is after the client's. Until
		-- run fh44 the server's side was taken before them: a fist that touched a wall was a
		-- difference between two sides that agreed.)
		FH.OnContact = function(ply, s)
			if ply == host then
				local a, b, c = Rel(s, 1)
				local d, e, f = Rel(s, 2)
				server[s.cmd] = { a, b, c, d, e, f }
				if notes then notes(true) end
			end
		end
		notes = T.PredictionNotes(host, server, nil)
		S.Client("fhinput", { record = true, moves = {
			{ R = true, mx = 30, my = -40, n = 20 }, { R = true, mx = 0, my = 0, n = 15 }, { L = true, mx = -50, my = -20, n = 20 },
			{ L = true, R = true, mx = 25, my = 35, n = 25 }, { R = true, depth = true, mx = 0, my = -50, n = 20 }, { R = true, mx = 0, my = 0, n = 20 },
		} })
		Wait(2.6)
		local r = Ask("fhinput", { report = true }, "pred", 3)
		FH.OnContact = nil
		local n, worstD, sum = 0, 0, 0
		local first, mean = nil, { 0, 0, 0, 0, 0, 0 }
		if r and r.list then
			for k, e in ipairs(r.list) do
				local sv = server[e[1]]
				if sv then
					n = n + 1
					local d = math.max(math.sqrt((e[2] - sv[1]) ^ 2 + (e[3] - sv[2]) ^ 2 + (e[4] - sv[3]) ^ 2), math.sqrt((e[5] - sv[4]) ^ 2 + (e[6] - sv[5]) ^ 2 + (e[7] - sv[6]) ^ 2))
					worstD, sum = math.max(worstD, d), sum + d
					if not first and d > 0.01 then first = k end
					for j = 1, 6 do mean[j] = mean[j] + (e[j + 1] - sv[j]) end
				end
			end
		end
		Log("  %d commands compared: the client's own hands and the server's differ by %.3f units on average, %.3f at the worst", n, n > 0 and sum / n or -1, worstD)
		if worstD > 0.01 and n > 0 then
			-- (what kind of difference: from which command on, which way on average, and what the two sides may not agree on)
			Log("  the difference: from the %s compared command on; on average left (%.2f %.2f %.2f), right (%.2f %.2f %.2f) about the feet",
				tostring(first), mean[1] / n, mean[2] / n, mean[3] / n, mean[4] / n, mean[5] / n, mean[6] / n)
			Log("  %s", T.PredictionNotes(host, server, r and r.list)() )
		end
		Check("the client's own hands are the server's", n >= 80 and worstD < 1.0, string.format("%d commands, worst %.3f", n, worstD))
		-- what the player sees of it: Z-City's own first-person camera for three pictures
		S.Client("fhinput", {})
		S.Client("view", {})
		S.Client("zview", { on = true })
		Wait(3.2)
		S.Shot("fh_hands_own_guard")
		S.Client("fhinput", { moves = { { R = true, mx = 30, my = 0, n = 14 }, { R = true, depth = true, mx = 0, my = -60, n = 30 }, { R = true, mx = 0, my = 0, n = 200 } } })
		Wait(1.3)
		S.Shot("fh_hands_own_right_out")
		S.Client("fhinput", { moves = { { L = true, mx = 40, my = 40, n = 30 }, { L = true, mx = 0, my = 0, n = 200 } } })
		Wait(1.2)
		S.Shot("fh_hands_own_left_across")
		S.Client("fhinput", {})
		S.Client("zview", { on = false })
		if IsValid(hw) and hw.SetFists then hw:SetFists(false) end
	end

	S.Client("fhmeasure", { on = false })
	RunConsoleCommand("fh_debug", "0")
	FH.TestInput[bot] = nil
	Tally("fh_hands")
end)
