-- One tick of one fighter: commands in, hands and weapon out.
--
--   input   which hands are held, the mouse's movement, the eye's direction
--   targets where the player wants each hand (aim frame), inside what a shoulder allows
--   arms    each arm pulls its hand (or its grip on the weapon) toward the target with a spring
--           that has a limit: the arm's strength. Nothing is placed; everything is pulled.
--   weapon  a rigid body the two grips pull on. Two forces at two places are a force and a
--           torque: both hands together move it, one against the other turns it.
--
-- Stepped with the fixed length of a tick, split into substeps; no clock is read in here. The
-- client runs it for its own player when it makes a command, the server when it gets one.

FreeHand.SameOnBothSides()
local FH = FreeHand
local C, M, B, W = FH.Config, FH.Math, FH.Body, FH.Weapon
FH.Sim = FH.Sim or {}
local S = FH.Sim
local sqrt, abs, min, max, exp, band = math.sqrt, math.abs, math.min, math.max, math.exp, bit.band
local Clamp = M.Clamp

------------------------------------------------------------------------------------------
-- Input
------------------------------------------------------------------------------------------
-- What a command says, in the simulation's own words. mx, my: the mouse's movement in counts
-- (the client adds up what it took from the view and sends it in the command).
-- (A player's settings: sh_config.lua, C.Prefs. The client reads its own, the server what the
-- client sent with the player; a bot has the defaults.)
local prefs, who = {}, nil
local function ReadOwn(name)
	local cv = GetConVar(name)
	return cv and cv:GetString() or nil
end
local function ReadSent(name) return who:GetInfo(name) end
function S.Prefs(ply)
	-- (A scene is running: everybody has the defaults, whatever the person at the machine has
	-- set and saved, unless the scene is about the settings: FH.testPrefs, on both sides.)
	if FH.testRun and not FH.testPrefs then return C.BotPrefs end
	if CLIENT then return C.Prefs(ReadOwn, prefs) end
	if ply:IsBot() then return C.BotPrefs end
	who = ply
	return C.Prefs(ReadSent, prefs)
end

function S.Input(ply, buttons, mx, my, yaw, pitch)
	local p = S.Prefs(ply)
	local K = C.Keys
	local left, right = band(buttons, K[p.left]) ~= 0, band(buttons, K[p.right]) ~= 0
	-- (an arm that is gone holds nothing)
	local org = ply.organism
	local noL, noR = istable(org) and org.larmamputated == true, istable(org) and org.rarmamputated == true
	return {
		L = left and not noL, R = right and not noR, noL = noL, noR = noR,
		depth = band(buttons, K[p.depth]) ~= 0,
		grip = band(buttons, K[p.grip]) ~= 0,
		mx = mx, my = my, yaw = yaw, pitch = pitch, sens = p.sens, invert = p.invert,
		smooth = p.smooth, reach = p.reach,
	}
end

------------------------------------------------------------------------------------------
-- Laying the state on the body: hands at their guard, at rest with the body.
------------------------------------------------------------------------------------------
local function GuardTarget(st, prof, i)
	if prof.kind == "fists" then
		local g = C.Guard.fists[i]
		return B.PolarTarget(i, g.azIn, g.el, g.ext * B.ArmLength())
	end
	return S.ToolGuard(st, prof, i)
end
S.GuardTarget = GuardTarget

function S.Reset(st, prof)
	st.prof = prof
	st.idle = 0
	st.twoHand = prof.kind == "tool" and prof.hands == 2
	st.gripKeyWas = false
	for i = 1, 2 do
		local h = st.h[i]
		h.tf, h.tl, h.tu = GuardTarget(st, prof, i)
		h.wx, h.wy, h.wz = B.ToWorld(st, h.tf, h.tl, h.tu)
		h.px, h.py, h.pz = h.wx, h.wy, h.wz
		h.qx, h.qy, h.qz = h.px, h.py, h.pz
		h.vx, h.vy, h.vz = st.bvx, st.bvy, st.bvz
		h.fx, h.fy, h.fz = 0, 0, 0
		h.ptf, h.ptl, h.ptu = h.tf, h.tl, h.tu
		h.effort = C.Arm.effortMin
		h.on = false
		h.idle = 0
		h.grip = true
	end
	st.w = nil
	if prof.kind == "tool" then S.ToolReset(st, prof) end
	st.ok = true
end

------------------------------------------------------------------------------------------
-- Targets
------------------------------------------------------------------------------------------
local function Targets(st, prof, inp, dt)
	local a = C.Arm
	local mx, my = Clamp(inp.mx, -a.maxCount, a.maxCount), Clamp(inp.my, -a.maxCount, a.maxCount)
	if inp.invert then my = -my end
	-- fh_smoothing: what the mouse said is paid out over a few ticks. Nought (the default): at once.
	local sm = inp.smooth or 0
	if sm > 0 and (inp.L or inp.R) then
		local k = 1 - exp(-dt / (sm * a.smoothMax))
		local px, py = (st.pmx or 0) + mx, (st.pmy or 0) + my
		mx, my = px * k, py * k
		st.pmx, st.pmy = px - mx, py - my
	else
		st.pmx, st.pmy = 0, 0
	end
	-- fh_reach: how far these arms stretch (B.WithinReach)
	local rk = inp.reach or 1
	st.h[1].reachK, st.h[2].reachK = rk, rk
	local across = mx * a.degPerCount * inp.sens
	local up, out = -my * a.degPerCount * inp.sens, 0
	if inp.depth then up, out = 0, -my * a.unitsPerCount * inp.sens end
	local h1, h2 = st.h[1], st.h[2]
	h1.on, h2.on = inp.L and not inp.noL, inp.R and not inp.noR
	if prof.kind == "tool" then
		S.ToolTargets(st, prof, inp, across, up, out, dt)
	else
		for i = 1, 2 do
			local h = st.h[i]
			if h.on then h.tf, h.tl, h.tu = B.MoveTarget(i, h.tf, h.tl, h.tu, across, up, out, C.Guard.fists[i]) end
		end
	end
	-- A hand that was let go eases back to its guard. Two hands on one handle go back
	-- together, once both are let go: one of them going home alone would turn the weapon.
	if h1.on or h2.on then st.idle = 0 else st.idle = st.idle + dt end
	local together = prof.kind == "tool" and st.twoHand
	local k = 1 - exp(-a.recenterRate * dt)
	for i = 1, 2 do
		local h = st.h[i]
		if h.on then h.idle = 0 else h.idle = h.idle + dt end
		local idle = together and st.idle or h.idle
		if idle > a.releaseHold then
			local gf, gl, gu = GuardTarget(st, prof, i)
			h.tf, h.tl, h.tu = h.tf + (gf - h.tf) * k, h.tl + (gl - h.tl) * k, h.tu + (gu - h.tu) * k
		end
	end
	-- how hard each arm tries: as fast as its target was moved, and for a while after
	for i = 1, 2 do
		local h = st.h[i]
		local dx, dy, dz = h.tf - h.ptf, h.tl - h.ptl, h.tu - h.ptu
		local sp = sqrt(dx * dx + dy * dy + dz * dz) / dt * FH.U2M
		h.ptf, h.ptl, h.ptu = h.tf, h.tl, h.tu
		local e = Clamp(sp / a.effortFull, a.effortMin, 1)
		local kept = h.effort * exp(-dt / a.effortHold)
		h.effort = e > kept and e or kept
	end
	-- into the world, out of the body, inside the arm's reach
	for i = 1, 2 do
		local h = st.h[i]
		local x, y, z = B.ToWorld(st, h.tf, h.tl, h.tu)
		x, y, z = B.KeepOut(st, x, y, z, 1.0, true)
		h.wx, h.wy, h.wz = B.WithinReach(h, x, y, z)
	end
end

------------------------------------------------------------------------------------------
-- The pull of an arm on a point at p moving with v, toward its hand's target.
-- Returns the force (kg unit / s^2).
------------------------------------------------------------------------------------------
local function ArmForce(st, h, px, py, pz, vx, vy, vz, mass, strength)
	local a = C.Arm
	local fmax = FH.N(a.force) * strength
	local ex, ey, ez = h.wx - px, h.wy - py, h.wz - pz
	local d = sqrt(ex * ex + ey * ey + ez * ez)
	-- the speed toward the target from which the arm can still stop there
	local acc = a.brake * fmax / mass
	local far = d
	-- (an arm that was pushing against something a moment ago: sh_config.lua, calmLead)
	if st.tick - st.pressTick <= C.Hit.calmTicks and far > C.Hit.calmLead then far = C.Hit.calmLead end
	local want
	if far >= a.zone then want = sqrt(2 * acc * (far - a.zone * 0.5)) else want = far * sqrt(acc / a.zone) end
	local cap = a.maxSpeed * FH.M2U
	if want > cap then want = cap end
	local k = d > 1e-5 and want / d or 0
	local g = mass / a.servo
	local rx, ry, rz = vx - st.bvx, vy - st.bvy, vz - st.bvz
	local fx, fy, fz = g * (ex * k - rx), g * (ey * k - ry), g * (ez * k - rz)
	local f2 = fx * fx + fy * fy + fz * fz
	if f2 < 1e-12 then return 0, 0, 0 end
	-- what the arm has left at the speed it is moving the point with
	local f = sqrt(f2)
	local along = (rx * fx + ry * fy + rz * fz) / f
	local lim
	if along > -1 then
		-- pushing: what the speed leaves; and against something (or just after), what the
		-- gesture asks for and no more (sh_config.lua, effortMin). In free air an arm has all
		-- of its force whatever the mouse does: until phase 41 a slow movement had a quarter.
		local effort = (st.tick - st.pressTick <= C.Hit.calmTicks) and h.effort or 1
		lim = fmax * effort * max(1 - max(along, 0) / cap, 0)
	else
		lim = fmax * min(1 - (a.eccentric - 1) * along / (cap * 0.25), a.eccentric)
	end
	if f > lim then
		local s = lim / f
		return fx * s, fy * s, fz * s
	end
	return fx, fy, fz
end
S.ArmForce = ArmForce

-- Two fists are not in the same place: nearer than they can be, they are moved apart by halves
-- and lose what speed they had toward each other.
function S.FistsApart(st)
	local a, b = st.h[1], st.h[2]
	local dx, dy, dz = a.px - b.px, a.py - b.py, a.pz - b.pz
	local d2 = dx * dx + dy * dy + dz * dz
	local need = C.Arm.fistApart
	if d2 >= need * need then return end
	local d = sqrt(d2)
	if d < 1e-3 then dx, dy, dz, d = st.lx, st.ly, st.lz, 1 end
	local nx, ny, nz = dx / d, dy / d, dz / d
	local push = (need - d) * 0.5
	a.px, a.py, a.pz = a.px + nx * push, a.py + ny * push, a.pz + nz * push
	b.px, b.py, b.pz = b.px - nx * push, b.py - ny * push, b.pz - nz * push
	local vn = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny + (a.vz - b.vz) * nz
	if vn < 0 then
		local h = vn * 0.5
		a.vx, a.vy, a.vz = a.vx - nx * h, a.vy - ny * h, a.vz - nz * h
		b.vx, b.vy, b.vz = b.vx + nx * h, b.vy + ny * h, b.vz + nz * h
	end
end

-- A free hand (a fist): a mass on the end of an arm.
local function StepFist(st, h, i, dt, strength)
	local m = C.Arm.mass
	local fx, fy, fz = ArmForce(st, h, h.px, h.py, h.pz, h.vx, h.vy, h.vz, m, strength)
	h.fx, h.fy, h.fz = fx, fy, fz
	-- (the work the arm does: what swinging costs)
	local p = fx * (h.vx - st.bvx) + fy * (h.vy - st.bvy) + fz * (h.vz - st.bvz)
	if p > 0 then st.work = st.work + p * dt end
	local vx, vy, vz = h.vx + fx / m * dt, h.vy + fy / m * dt, h.vz + fz / m * dt
	local px, py, pz = h.px + vx * dt, h.py + vy * dt, h.pz + vz * dt
	-- the body is in the way: on its surface, and no further into it
	local qx, qy, qz, deep = B.KeepOut(st, px, py, pz, 0.6, true)
	if deep > 0 then
		local nx, ny, nz, l = M.Norm(qx - px, qy - py, qz - pz)
		if l > 0 then
			local vn = (vx - st.bvx) * nx + (vy - st.bvy) * ny + (vz - st.bvz) * nz
			if vn < 0 then vx, vy, vz = vx - nx * vn, vy - ny * vn, vz - nz * vn end
		end
		px, py, pz = qx, qy, qz
	end
	-- the arm is at its end: a rope
	local rx, ry, rz, over = B.WithinReach(h, px, py, pz)
	if over > 0 then
		local nx, ny, nz = M.Norm(px - h.sx, py - h.sy, pz - h.sz)
		local vn = (vx - st.bvx) * nx + (vy - st.bvy) * ny + (vz - st.bvz) * nz
		if vn > 0 then vx, vy, vz = vx - nx * vn, vy - ny * vn, vz - nz * vn end
		px, py, pz = rx, ry, rz
	end
	h.px, h.py, h.pz, h.vx, h.vy, h.vz = px, py, pz, vx, vy, vz
end
S.StepFist = StepFist

------------------------------------------------------------------------------------------
-- A tick
------------------------------------------------------------------------------------------
-- pos, vel: the player's origin and velocity; eyeZ: the eye's height over the origin.
function S.Step(st, prof, inp, px, py, pz, vx, vy, vz, eyeZ, dt, strength)
	-- (fh_weapon_inertia: a number compared; the weapons are weighed again when it has changed)
	W.Weigh()
	-- a body that was put somewhere else takes its hands with it
	if st.ok and st.prof == prof then
		local dx, dy, dz = px - st.bx, py - st.by, pz - st.bz
		if dx * dx + dy * dy + dz * dz > C.Sim.teleport * C.Sim.teleport then st.ok = false end
	else
		st.ok = false
	end
	-- (the frame as it was, for what the turn of the view does to the hands: below)
	local turned = st.ok and (inp.yaw ~= st.yaw or inp.pitch ~= st.pitch)
	local ofx, ofy, ofz, olx, oly, olz, oux, ouy, ouz = st.fx, st.fy, st.fz, st.lx, st.ly, st.lz, st.ux, st.uy, st.uz
	local oox, ooy, ooz, obvx, obvy, obvz = st.ox, st.oy, st.oz, st.bvx, st.bvy, st.bvz
	local obx, oby, obz = st.bx, st.by, st.bz
	B.SetFrame(st, px, py, pz, eyeZ, inp.yaw, inp.pitch, vx, vy, vz)
	local fresh = not st.ok
	if fresh then S.Reset(st, prof) end
	st.tick = st.tick + 1
	for i = 1, 2 do
		local h = st.h[i]
		h.qx, h.qy, h.qz = h.px, h.py, h.pz
	end
	local w = st.w
	if w then w.px, w.py, w.pz, w.pqw, w.pqx, w.pqy, w.pqz = w.x, w.y, w.z, w.qw, w.qx, w.qy, w.qz end
	-- The arms are on a body that the game turns as fast as the mouse says. Hands that were
	-- left to catch up by themselves were behind their owner's back for a moment after every
	-- quick look round (26 units from their guard after 120 degrees in 60 ms). They go round
	-- with the body: where a hand, a weapon and their speeds were in the frame of the aim, they
	-- are in the frame as it is now. Only the turn is carried so; where the body walks to is
	-- still for the arms to follow. The turn gives a hand no speed of its own: a look round
	-- is not a blow. (What was passed on the way is still looked through for something to
	-- meet: the places a tick ago are left where they were.)
	if turned and not fresh then
		-- where the middle between the shoulders would be had the body only turned
		local cx, cy, cz = st.ox - (px - obx), st.oy - (py - oby), st.oz - (pz - obz)
		local function Pos(x, y, z)
			x, y, z = x - oox, y - ooy, z - ooz
			local a, b, c = x * ofx + y * ofy + z * ofz, x * olx + y * oly + z * olz, x * oux + y * ouy + z * ouz
			return cx + st.fx * a + st.lx * b + st.ux * c, cy + st.fy * a + st.ly * b + st.uy * c, cz + st.fz * a + st.lz * b + st.uz * c
		end
		local function Dir(x, y, z)
			local a, b, c = x * ofx + y * ofy + z * ofz, x * olx + y * oly + z * olz, x * oux + y * ouy + z * ouz
			return st.fx * a + st.lx * b + st.ux * c, st.fy * a + st.ly * b + st.uy * c, st.fz * a + st.lz * b + st.uz * c
		end
		for i = 1, 2 do
			local h = st.h[i]
			h.px, h.py, h.pz = Pos(h.px, h.py, h.pz)
			local rx, ry, rz = Dir(h.vx - obvx, h.vy - obvy, h.vz - obvz)
			h.vx, h.vy, h.vz = obvx + rx, obvy + ry, obvz + rz
		end
		if w then
			w.x, w.y, w.z = Pos(w.x, w.y, w.z)
			local rx, ry, rz = Dir(w.vx - obvx, w.vy - obvy, w.vz - obvz)
			w.vx, w.vy, w.vz = obvx + rx, obvy + ry, obvz + rz
			w.wx, w.wy, w.wz = Dir(w.wx, w.wy, w.wz)
			local ax, ay, az = Dir(M.QRot(w.qw, w.qx, w.qy, w.qz, 1, 0, 0))
			local ex, ey, ez = Dir(M.QRot(w.qw, w.qx, w.qy, w.qz, 0, 1, 0))
			w.qw, w.qx, w.qy, w.qz = M.QFromAxes(ax, ay, az, ex, ey, ez)
			if w.rdx then w.rdx, w.rdy, w.rdz = Dir(w.rdx, w.rdy, w.rdz) end
		end
	end
	Targets(st, prof, inp, dt)
	local n = C.Sim.substeps
	local sdt = dt / n
	if prof.kind == "tool" then
		S.ToolStep(st, prof, inp, sdt, n, strength)
	else
		for _ = 1, n do
			StepFist(st, st.h[1], 1, sdt, strength)
			StepFist(st, st.h[2], 2, sdt, strength)
			S.FistsApart(st)
		end
	end
	S.Arms(st, fresh, dt)
	return st
end

-- Where the elbows and the knuckles are (for what the arms can run into, and what can run into
-- them): worked out once a tick from where the hands have come to.
function S.Arms(st, fresh, dt)
	local bd = C.Body
	local turn = dt and math.rad(C.Arm.elbowTurn) * dt or nil
	for i = 1, 2 do
		local h = st.h[i]
		local ex, ey, ez
		if fresh or not h.ex or not turn then
			ex, ey, ez = B.Elbow(i, h.sx, h.sy, h.sz, h.px, h.py, h.pz, st.fx, st.fy, st.fz, st.lx, st.ly, st.lz, st.ux, st.uy, st.uz,
				bd.upperArm, bd.foreArm, st.tax, st.tay, st.tlow, st.thigh, st.tr)
		else
			-- (the elbow of a tick ago, carried with the body as the hand was)
			ex, ey, ez = B.Elbow(i, h.sx, h.sy, h.sz, h.px, h.py, h.pz, st.fx, st.fy, st.fz, st.lx, st.ly, st.lz, st.ux, st.uy, st.uz,
				bd.upperArm, bd.foreArm, st.tax, st.tay, st.tlow, st.thigh, st.tr, h.sx + h.erx, h.sy + h.ery, h.sz + h.erz, turn)
		end
		h.ex, h.ey, h.ez = ex, ey, ez
		-- (kept about the shoulder: the shoulder goes where the body goes)
		h.erx, h.ery, h.erz = ex - h.sx, ey - h.sy, ez - h.sz
		local fx, fy, fz, l = M.Norm(h.px - ex, h.py - ey, h.pz - ez)
		if l < 1e-4 then fx, fy, fz = st.fx, st.fy, st.fz end
		local kx, ky, kz = h.px + fx * bd.hand, h.py + fy * bd.hand, h.pz + fz * bd.hand
		if fresh or not h.kx then h.kqx, h.kqy, h.kqz = kx, ky, kz else h.kqx, h.kqy, h.kqz = h.kx, h.ky, h.kz end
		h.kx, h.ky, h.kz = kx, ky, kz
	end
end

-- (S.ToolGuard, S.ToolReset, S.ToolTargets, S.ToolStep: sh_tool.lua)

-- Every number and switch in a state and in what its step was given, by name: for the scenes
-- that ask in what the client's own state and the server's differ.
function S.Dump(st, inp)
	local out = {}
	local function Take(prefix, t)
		for k, v in pairs(t) do
			if isnumber(v) then out[prefix .. tostring(k)] = v
			elseif isbool(v) then out[prefix .. tostring(k)] = v and 1 or 0 end
		end
	end
	Take("", st)
	Take("h1.", st.h[1])
	Take("h2.", st.h[2])
	if st.w then Take("w.", st.w) end
	if inp then Take("inp.", inp) end
	out.sincePress = st.tick - st.pressTick
	return out
end

-- What a player's body gives the step (the same call on both sides).
function S.BodyOf(ply)
	local p, v = ply:GetPos(), ply:GetVelocity()
	local eyeZ = 64
	if ply.GetCurrentViewOffset then eyeZ = ply:GetCurrentViewOffset().z end
	return p.x, p.y, p.z, v.x, v.y, v.z, eyeZ
end
