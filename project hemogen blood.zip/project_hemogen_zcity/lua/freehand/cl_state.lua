-- Client: where a fighter's hands and weapon are for the frame that is being drawn.
--
-- Two sources. The local player's own: the state the client stepped itself (cl_input.lua), drawn
-- between its last two ticks. Everybody else's (and the local player's when it does not step
-- itself): the server's snapshots, drawn between the last two that came. Both are kept relative
-- to the fighter's feet and laid on where the feet are drawn, so hands never trail the body.

FreeHand.NoJIT()
local FH = FreeHand
local C, M, B = FH.Config, FH.Math, FH.Body
local cl = FH.cl

cl.remote = cl.remote or {}     -- ent index -> { a = snapshot, b = snapshot, ta, tb, active }

local function ReadSnap(tool)
	local s = { h = {} }
	s.cmd = net.ReadUInt(16)
	s.yaw, s.pitch = net.ReadInt(16) / 100, net.ReadInt(16) / 100
	for i = 1, 2 do
		local x, y, z = net.ReadInt(16) / 16, net.ReadInt(16) / 16, net.ReadInt(16) / 16
		s.h[i] = { x = x, y = y, z = z, on = net.ReadBool(), grip = net.ReadBool() }
	end
	if tool then
		s.wx, s.wy, s.wz = net.ReadInt(16) / 16, net.ReadInt(16) / 16, net.ReadInt(16) / 16
		s.qw, s.qx, s.qy, s.qz = M.QNorm(net.ReadInt(16) / 32767, net.ReadInt(16) / 32767, net.ReadInt(16) / 32767, net.ReadInt(16) / 32767)
	end
	return s
end

net.Receive("fh_s", function()
	local n = net.ReadUInt(6)
	local now = RealTime()
	for _ = 1, n do
		local idx = net.ReadUInt(8)
		local active = net.ReadBool()
		local r = cl.remote[idx]
		if not active then
			if r then r.active = false end
		else
			local tool = net.ReadBool()
			local s = ReadSnap(tool)
			s.tool = tool
			if not r then r = {} cl.remote[idx] = r end
			if r.active and r.b and now - r.tb < 0.5 then r.a, r.ta = r.b, r.tb else r.a, r.ta = s, now - 0.03 end
			r.b, r.tb = s, now
			r.active = true
		end
	end
end)

local function Lerp(a, b, k) return a + (b - a) * k end

-- What to draw for a player this frame, or nil when the module does not hold its hands.
--   rs.h[i] = { x, y, z (world), on, grip }, rs.prof, rs.yaw, rs.pitch (of the eye the hands
--   were stepped with)
--   rs.w = { x, y, z, qw, qx, qy, qz } for a tool
-- (Worked out once for a player in a frame. It is asked for by each pass in which the player's
-- hands are placed, by the weapon's drawing, by the view: they all get the same, and the
-- second and third ask cost nothing.)
local drawn = setmetatable({}, { __mode = "k" })
function FH.RenderHands(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return nil end
	local rs = drawn[ply]
	local frame = FrameNumber()
	if rs and rs.frame == frame then
		if rs.none then return nil end
		return rs
	end
	if not rs then
		rs = { h = { {}, {} }, w = {} }
		drawn[ply] = rs
	end
	rs.frame, rs.none = frame, true
	local prof = FH.Applies(ply)
	if not prof then return nil end
	local o = ply:GetPos()
	rs.prof = prof
	rs.tool = false
	local st = FH.states[ply]
	if ply == LocalPlayer() and st and st.active and st.ok and not cl.forceNet then
		-- Our own, between the tick before and the last one. How far between: by the game's
		-- own clock, which goes on evenly from frame to frame whether one tick or two were
		-- stepped since the last (cl.interp 1). Until phase 41 it was the time since the last
		-- step by the wall clock (0): with fewer frames than ticks every frame is drawn right
		-- after its steps, and that showed the tick before, late and unevenly. (2: the last
		-- tick as it is, for comparison.)
		local k
		local mode = cl.interp or 1
		if mode == 0 then
			k = M.Clamp((RealTime() - (st.stamp or 0)) / engine.TickInterval(), 0, 1)
		elseif mode == 2 then
			k = 1
		else
			local raw = CurTime() / engine.TickInterval() - (st.simTick or 0)
			cl.rawClock = raw
			-- (the clock runs one tick's width; where that width begins is found as it goes)
			local base = cl.clockBase
			if not base or raw < base or raw > base + 1.5 then
				base = math.floor(raw)
				cl.clockBase = base
			end
			k = M.Clamp(raw - base, 0, 1)
		end
		cl.lastK = k
		-- (what a correction from the server moved the state by is drawn in over a moment)
		local fix = cl.fix
		if fix and cl.fixFrame ~= FrameNumber() then
			cl.fixFrame = FrameNumber()
			local keep = math.exp(-14 * math.min(RealFrameTime(), 0.1))
			for i = 1, 2 do
				local f = fix.h[i]
				f[1], f[2], f[3] = f[1] * keep, f[2] * keep, f[3] * keep
			end
			fix.w[1], fix.w[2], fix.w[3] = fix.w[1] * keep, fix.w[2] * keep, fix.w[3] * keep
		end
		local w = st.w
		local tool = w ~= nil and prof.kind == "tool"
		for i = 1, 2 do
			local h, d = st.h[i], rs.h[i]
			-- (relative to where the feet were at that tick, laid on where they are drawn now)
			d.x, d.y, d.z = o.x + Lerp(h.qx, h.px, k) - st.bx, o.y + Lerp(h.qy, h.py, k) - st.by, o.z + Lerp(h.qz, h.pz, k) - st.bz
			local f = fix and ((tool and (i == 2 or h.grip)) and fix.w or fix.h[i])
			if f then d.x, d.y, d.z = d.x + f[1], d.y + f[2], d.z + f[3] end
			d.on, d.grip = h.on, h.grip
		end
		if tool then
			rs.tool = true
			local d = rs.w
			d.x, d.y, d.z = o.x + Lerp(w.px, w.x, k) - st.bx, o.y + Lerp(w.py, w.y, k) - st.by, o.z + Lerp(w.pz, w.z, k) - st.bz
			if fix then d.x, d.y, d.z = d.x + fix.w[1], d.y + fix.w[2], d.z + fix.w[3] end
			-- (two attitudes a tick apart are close: a straight blend and a renormalisation)
			local s = (w.pqw * w.qw + w.pqx * w.qx + w.pqy * w.qy + w.pqz * w.qz) < 0 and -1 or 1
			d.qw, d.qx, d.qy, d.qz = M.QNorm(Lerp(w.pqw * s, w.qw, k), Lerp(w.pqx * s, w.qx, k), Lerp(w.pqy * s, w.qy, k), Lerp(w.pqz * s, w.qz, k))
		end
		rs.yaw, rs.pitch = st.yaw, st.pitch
		rs.source = "own"
		rs.none = false
	else
		local r = cl.remote[ply:EntIndex()]
		if not r or not r.active or not r.b then return nil end
		local a, b = r.a or r.b, r.b
		local span = math.max(r.tb - r.ta, 0.005)
		local k = M.Clamp((RealTime() - r.tb) / span, 0, 1.25)
		for i = 1, 2 do
			local d = rs.h[i]
			d.x, d.y, d.z = o.x + Lerp(a.h[i].x, b.h[i].x, k), o.y + Lerp(a.h[i].y, b.h[i].y, k), o.z + Lerp(a.h[i].z, b.h[i].z, k)
			d.on, d.grip = b.h[i].on, b.h[i].grip
		end
		if b.tool and a.tool then
			rs.tool = true
			local d = rs.w
			d.x, d.y, d.z = o.x + Lerp(a.wx, b.wx, k), o.y + Lerp(a.wy, b.wy, k), o.z + Lerp(a.wz, b.wz, k)
			local s = (a.qw * b.qw + a.qx * b.qx + a.qy * b.qy + a.qz * b.qz) < 0 and -1 or 1
			d.qw, d.qx, d.qy, d.qz = M.QNorm(Lerp(a.qw * s, b.qw, k), Lerp(a.qx * s, b.qx, k), Lerp(a.qy * s, b.qy, k), Lerp(a.qz * s, b.qz, k))
		end
		rs.yaw = a.yaw + math.AngleDifference(b.yaw, a.yaw) * math.min(k, 1)
		rs.pitch = Lerp(a.pitch, b.pitch, math.min(k, 1))
		rs.source = "net"
		rs.none = false
	end
	return rs
end
