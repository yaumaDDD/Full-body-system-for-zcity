-- A weapon as a rigid body: what follows from its parts (mass, where its weight sits, how hard
-- it is to turn), and the body itself (place, velocity, attitude, spin).
--
-- The weapon's own frame: x along the handle from the butt toward the tip, y the side the blade
-- (or the hook) is on, z across both. Its origin for the dynamics is the centre of mass; a place
-- "at" a number is that many metres from the butt along x.

FreeHand.SameOnBothSides()
local FH = FreeHand
local C, M = FH.Config, FH.Math
FH.Weapon = FH.Weapon or {}
local W = FH.Weapon
local sqrt = math.sqrt

-- Works out, once, what the dynamics need from a profile's parts. Lengths are turned into units.
-- (W.massK: every part's mass is multiplied by it. The setting fh_weapon_inertia, W.Weigh.)
W.massK = W.massK or 1
function W.Prepare(prof)
	if prof.ready or prof.kind ~= "tool" then prof.ready = true return prof end
	local mk = W.massK
	local m, mx = 0, 0
	for _, p in ipairs(prof.parts) do
		local at = p.at or (p.from + p.to) * 0.5
		m, mx = m + p.mass * mk, mx + p.mass * mk * at
	end
	local com = mx / m
	-- about an axis across the handle, through the centre of mass
	local it = 0
	for _, p in ipairs(prof.parts) do
		if p.at then
			local s = p.size or 0
			it = it + p.mass * mk * (s * s / 12 + (p.at - com) ^ 2)
		else
			local len, mid = p.to - p.from, (p.from + p.to) * 0.5
			it = it + p.mass * mk * (len * len / 12 + (mid - com) ^ 2)
		end
	end
	-- about the handle's own line: a bar of a finger's thickness, and the head's width
	local ia = 0
	for _, p in ipairs(prof.parts) do
		local r = p.at and (p.size or 0.04) * 0.5 or 0.014
		ia = ia + p.mass * mk * r * r * 0.5
	end
	prof.mass = m
	prof.comM = com                                  -- metres from the butt
	prof.inertiaT = it                               -- kg m^2
	prof.inertiaA = math.max(ia, 2e-4)
	local U = FH.M2U
	prof.u = {                                       -- the same in units, for the simulation
		length = prof.length * U, com = com * U,
		it = FH.KGM2(it), ia = FH.KGM2(prof.inertiaA),
		butt = prof.grips.butt * U, one = prof.grips.one * U, two = prof.grips.two * U, twoMin = prof.grips.twoMin * U, twoMax = prof.grips.twoMax * U,
	}
	-- (the guard's direction as a unit vector)
	local g = prof.guard
	g.dir[1], g.dir[2], g.dir[3] = M.Norm(g.dir[1], g.dir[2], g.dir[3])
	prof.usamples = {}
	for i, s in ipairs(prof.samples) do
		prof.usamples[i] = { at = s.at * U, r = s.r * U, off = (s.off or 0) * U, kind = s.kind }
	end
	prof.ready = true
	return prof
end

for _, prof in pairs(C.Weapons) do W.Prepare(prof) end

-- The weapons weighed again when fh_weapon_inertia is no longer what they were weighed with.
-- Asked once a tick by each side's step; the server's number reaches the client by itself.
function W.Weigh()
	local k = C.cv.inertia:GetFloat()
	if not k or k ~= k then k = 1 end
	k = k < 0.5 and 0.5 or (k > 2 and 2 or k)
	if k == W.massK then return end
	W.massK = k
	for _, prof in pairs(C.Weapons) do
		if prof.kind == "tool" then prof.ready = nil W.Prepare(prof) end
	end
end

-- A new rigid body at rest: centre of mass, velocity, attitude (quaternion), spin (world).
function W.NewBody()
	return {
		x = 0, y = 0, z = 0, vx = 0, vy = 0, vz = 0,
		qw = 1, qx = 0, qy = 0, qz = 0,
		wx = 0, wy = 0, wz = 0,
		-- where it was a tick ago
		px = 0, py = 0, pz = 0, pqw = 1, pqx = 0, pqy = 0, pqz = 0,
		slide = 0, slideWant = 0,                    -- where the right hand holds (units from the butt), and is to
		rdx = 1, rdy = 0, rdz = 0,                   -- where the wrist held the handle for, a step ago
	}
end

-- The weapon's axes in the world.
function W.Axes(b)
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local ex, ey, ez = M.QRot(b.qw, b.qx, b.qy, b.qz, 0, 1, 0)
	return ax, ay, az, ex, ey, ez
end

-- A place on the weapon (units from the butt along the handle, and to the blade's side) in the world.
function W.Point(prof, b, at, off)
	local s = at - prof.u.com
	return M.QRot(b.qw, b.qx, b.qy, b.qz, s, off or 0, 0)
end

-- The velocity of a place given as an offset from the centre of mass (world).
function W.VelAt(b, rx, ry, rz)
	local cx, cy, cz = M.Cross(b.wx, b.wy, b.wz, rx, ry, rz)
	return b.vx + cx, b.vy + cy, b.vz + cz
end

-- torque -> angular acceleration, for a body that is the same all round its handle
function W.InvInertia(prof, ax, ay, az, tx, ty, tz)
	local k = tx * ax + ty * ay + tz * az
	local it, ia = prof.u.it, prof.u.ia
	return (tx - ax * k) / it + ax * k / ia, (ty - ay * k) / it + ay * k / ia, (tz - az * k) / it + az * k / ia
end

-- How heavy the weapon is to something that meets it at an offset r from its centre of mass,
-- along the direction n (kg): 1 / (1/m + (r x n) . I^-1 (r x n)).
function W.EffectiveMass(prof, b, rx, ry, rz, nx, ny, nz)
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local cx, cy, cz = M.Cross(rx, ry, rz, nx, ny, nz)
	local ix, iy, iz = W.InvInertia(prof, ax, ay, az, cx, cy, cz)
	return 1 / (1 / prof.mass + cx * ix + cy * iy + cz * iz)
end

-- An impulse (kg unit / s) at an offset r from the centre of mass.
function W.Impulse(prof, b, rx, ry, rz, jx, jy, jz)
	b.vx, b.vy, b.vz = b.vx + jx / prof.mass, b.vy + jy / prof.mass, b.vz + jz / prof.mass
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local tx, ty, tz = M.Cross(rx, ry, rz, jx, jy, jz)
	local dx, dy, dz = W.InvInertia(prof, ax, ay, az, tx, ty, tz)
	b.wx, b.wy, b.wz = b.wx + dx, b.wy + dy, b.wz + dz
end
