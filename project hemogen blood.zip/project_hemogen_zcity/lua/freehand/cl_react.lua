-- Client: what is seen and felt of a blow.
--
-- The hand that gave or stopped a blow feels it: a small kick of the view, through Z-City's own
-- view-punch spring. A head that was struck is seen to go: a spring on the head and the upper
-- spine of that player, through Z-City's layered bone offsets, pushed once by the blow and left
-- to swing back. Neither is an animation: both are a push and a spring.

FreeHand.NoJIT()
local FH = FreeHand
local C, M = FH.Config, FH.Math
FH.ReactCl = FH.ReactCl or {}
local Rc = FH.ReactCl

local snaps = setmetatable({}, { __mode = "k" })   -- player -> the springs of its head and trunk

local function Springs(ply)
	local s = snaps[ply]
	if not s then
		s = { nod = 0, turn = 0, tilt = 0, vn = 0, vt = 0, vl = 0, lean = 0, side = 0, vb = 0, vs = 0, t = 0 }
		snaps[ply] = s
	end
	return s
end

net.Receive("fh_ev", function()
	local kind = net.ReadUInt(3)
	if kind == 1 then
		local k = net.ReadFloat()
		local dir = net.ReadVector()
		local lp = LocalPlayer()
		if not IsValid(lp) or not ViewPunch then return end
		-- (against the blow: the hand is thrown back, and the view a little with it)
		local ang = lp:EyeAngles()
		local a = k * C.React.joltView
		ViewPunch(Angle(dir:Dot(ang:Up()) * a, dir:Dot(ang:Right()) * a * 0.6, 0))
	elseif kind == 2 then
		local ply = Entity(net.ReadUInt(8))
		local dir = net.ReadVector()
		local sev = net.ReadFloat()
		if not IsValid(ply) or not ply:IsPlayer() then return end
		local s = Springs(ply)
		-- which way the head goes, in the struck player's own frame
		local ang = Angle(0, ply:EyeAngles().y, 0)
		local f, r = dir:Dot(ang:Forward()), dir:Dot(ang:Right())
		local kick = math.min(sev, 1.6) * C.React.snapSpeed
		s.vn = s.vn - f * kick              -- pushed back: the chin goes up
		s.vt = s.vt + r * kick * 0.9        -- pushed to its right: turned to its right
		s.vl = s.vl + r * kick * 0.5
		s.t = CurTime()
		Rc.last = { ply = ply, sev = sev, t = CurTime() }
	elseif kind == 3 then
		local ply = Entity(net.ReadUInt(8))
		local dir = net.ReadVector()
		local impulse = net.ReadFloat()
		if not IsValid(ply) or not ply:IsPlayer() then return end
		local s = Springs(ply)
		local ang = Angle(0, ply:EyeAngles().y, 0)
		local f, r = dir:Dot(ang:Forward()), dir:Dot(ang:Right())
		local kick = impulse * C.React.flinchSpeed
		s.vb = s.vb - f * kick              -- pushed back: the trunk gives backward
		s.vs = s.vs + r * kick * 0.7
		s.t = CurTime()
	end
end)

-- A damped spring, stepped with the frame.
local function Spring(x, v, dt, k, c)
	local a = -k * x - c * v
	v = v + a * dt
	return x + v * dt, v
end

hook.Add("Bones", "FH_HeadSnap", function(ply)
	local s = snaps[ply]
	if not s or not hg or not hg.bone or not hg.bone.Set then return end
	local dt = math.min(FrameTime(), 0.05)
	local r = C.React
	local k, c = r.snapStiff, r.snapDamp
	s.nod, s.vn = Spring(s.nod, s.vn, dt, k, c)
	s.turn, s.vt = Spring(s.turn, s.vt, dt, k, c)
	s.tilt, s.vl = Spring(s.tilt, s.vl, dt, k, c)
	s.lean, s.vb = Spring(s.lean, s.vb, dt, k * 0.7, c)
	s.side, s.vs = Spring(s.side, s.vs, dt, k * 0.7, c)
	local lim = r.snapMax
	s.nod, s.turn, s.tilt = M.Clamp(s.nod, -lim, lim), M.Clamp(s.turn, -lim, lim), M.Clamp(s.tilt, -lim * 0.6, lim * 0.6)
	s.lean, s.side = M.Clamp(s.lean, -lim * 0.5, lim * 0.5), M.Clamp(s.side, -lim * 0.4, lim * 0.4)
	local still = math.abs(s.nod) + math.abs(s.turn) + math.abs(s.tilt) + math.abs(s.lean) + math.abs(s.side) < 0.05
		and math.abs(s.vn) + math.abs(s.vt) + math.abs(s.vl) + math.abs(s.vb) + math.abs(s.vs) < 0.5
	if still or CurTime() - s.t > 3 then
		hg.bone.Set(ply, "head", vector_origin, angle_zero, "fh_snap")
		hg.bone.Set(ply, "spine2", vector_origin, angle_zero, "fh_snap")
		hg.bone.Set(ply, "spine1", vector_origin, angle_zero, "fh_snap")
		snaps[ply] = nil
		return
	end
	-- (the head bone of these bodies nods with yaw and turns with roll: Z-City's own head turn
	-- drives it that way; the spine's bones are laid out the same)
	hg.bone.Set(ply, "head", vector_origin, Angle(s.tilt, s.nod, s.turn), "fh_snap")
	hg.bone.Set(ply, "spine2", vector_origin, Angle(s.tilt * 0.3 + s.side * 0.6, s.nod * 0.35 + s.lean * 0.6, s.turn * 0.3), "fh_snap")
	hg.bone.Set(ply, "spine1", vector_origin, Angle(s.side * 0.4, s.lean * 0.4, 0), "fh_snap")
end)
