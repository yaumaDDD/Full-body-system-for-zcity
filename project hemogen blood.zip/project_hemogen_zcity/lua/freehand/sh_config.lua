-- FreeHand configuration: switches, the body's measures, the arm's strength, and the weapons.
-- Everything that is a number of the simulation is here and nowhere else.
--
-- Units. Lengths in the game's units (1 unit = 0.01905 m) wherever the engine is met, because
-- positions, bones and traces are in them. Masses in kg, time in seconds. A spring constant
-- (N/m = kg/s^2) and a damping (N s/m = kg/s) are the same number in both systems; a force (N), a
-- torque (N m) and an inertia (kg m^2) are converted once, here (FH.N, FH.NM, FH.KGM2).
-- Tiers behind the numbers: [M] measured in this game (docs/FREEHAND_TESTING.md), [R] from the
-- literature (docs/FREEHAND_RESEARCH.md), [G] a game choice.

local FH = FreeHand
FH.Config = FH.Config or {}
local C = FH.Config

FH.U2M = 0.01905                       -- metres in a unit
FH.M2U = 1 / 0.01905                   -- units in a metre
function FH.N(newton) return newton * FH.M2U end                  -- force in kg unit / s^2
function FH.NM(nm) return nm * FH.M2U * FH.M2U end                 -- torque in kg unit^2 / s^2
function FH.KGM2(i) return i * FH.M2U * FH.M2U end                 -- inertia in kg unit^2

------------------------------------------------------------------------------------------
-- Switches
------------------------------------------------------------------------------------------
local REP = { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_NOTIFY }
C.cv = C.cv or {}
C.cv.enabled = CreateConVar("fh_enabled", "1", REP, "FreeHand: free-hand physical melee for hands, crowbar and axes (0 = Z-City's own melee)", 0, 1)
C.cv.debug = CreateConVar("fh_debug", "0", { FCVAR_REPLICATED }, "FreeHand: draw targets, grips, sweeps and contacts (developer)", 0, 3)
C.cv.strength = CreateConVar("fh_strength", "1", REP, "FreeHand: multiplies the force of the arms", 0.25, 3)
C.cv.damage = CreateConVar("fh_damage", "1", REP, "FreeHand: multiplies the damage of an impact", 0, 5)
C.cv.knockout = CreateConVar("fh_knockout", "1", REP, "FreeHand: multiplies how much a head impact counts toward a knockout", 0, 5)

C.cv.inertia = CreateConVar("fh_weapon_inertia", "1", REP, "FreeHand: multiplies the weight of the weapons in the hands (1 = as they are built; more is heavier: slower to start, harder to stop, harder where it lands)", 0.5, 2)

if CLIENT then
	-- A player's own settings. The console command fh_help lists them with what they are now;
	-- fh_menu opens a panel with all of them. Those the simulation needs go to the server with
	-- the player (the fourth argument), which steps that player from the same numbers.
	-- (The names are new since phase 42. A value saved under an old name, fh_mirror_buttons,
	-- fh_sens, fh_key_depth, fh_key_grip, fh_cam_follow and the other fh_cam_*, would have kept
	-- alive what is no longer the default: which button holds which arm, first of all.)
	local KEYS = "attack (the primary mouse button), attack2 (the secondary), walk, reload, zoom, alt1, alt2, duck, speed, use"
	C.cv.bindRight = CreateClientConVar("fh_bind_right_arm", "attack2", true, true, "FreeHand: the key that holds the RIGHT arm while it is down. One of: " .. KEYS)
	C.cv.bindLeft = CreateClientConVar("fh_bind_left_arm", "attack", true, true, "FreeHand: the key that holds the LEFT arm while it is down. One of: " .. KEYS)
	C.cv.depthKey = CreateClientConVar("fh_bind_reach", "walk", true, true, "FreeHand: held, the mouse's forward and back is reach (and slides the hands on a handle). One of: " .. KEYS)
	C.cv.gripKey = CreateClientConVar("fh_bind_grip", "reload", true, true, "FreeHand: takes the second hand off the weapon or puts it back. One of: " .. KEYS)
	C.cv.sens = CreateClientConVar("fh_sensitivity", "1", true, true, "FreeHand: how far a hand goes for a movement of the mouse (1 = 0.05 degrees a count)", 0.2, 4)
	C.cv.invert = CreateClientConVar("fh_invert_y", "0", true, true, "FreeHand: 1 = mouse forward lowers the hand", 0, 1)
	C.cv.smooth = CreateClientConVar("fh_smoothing", "0", true, true, "FreeHand: 0 = the hand's aim follows the mouse at once; up to 1 = the mouse's movement is paid out over about a tenth of a second (steadier, later)", 0, 1)
	C.cv.reach = CreateClientConVar("fh_reach", "1", true, true, "FreeHand: how far the arms stretch, as a share of their length (0.85 to 1)", 0.85, 1)
	C.cv.camFollow = CreateClientConVar("fh_camera_follow", "0.4", true, false, "FreeHand: how much the view turns after a held hand that leaves the picture (0 = never, 1 = 14 degrees at the most)", 0, 1)
	C.cv.hints = CreateClientConVar("fh_hints", "1", true, false, "FreeHand: show which key holds which arm for a few seconds when a weapon of the module is taken in hand", 0, 1)
	C.cv.predict = CreateClientConVar("fh_predict", "1", true, false, "FreeHand: simulate one's own hands on the client (0 = show what the server sends; developer)", 0, 1)
end

-- The keys an arm or a function can be put on, by the names the settings take. (A key is what
-- the game's own binds make of it: "attack" is whatever is bound to +attack.)
C.Keys = { attack = IN_ATTACK, attack2 = IN_ATTACK2, walk = IN_WALK, reload = IN_RELOAD, zoom = IN_ZOOM, alt1 = IN_ALT1, alt2 = IN_ALT2, duck = IN_DUCK, speed = IN_SPEED, use = IN_USE }
C.KeyOrder = { "attack", "attack2", "walk", "reload", "zoom", "alt1", "alt2", "duck", "speed", "use" }
C.Defaults = { right = "attack2", left = "attack", depth = "walk", grip = "reload", sens = 1, smooth = 0, reach = 1 }

-- A player's settings made safe, into `out`. read(name) gives a setting as text, or nothing.
-- A number that is none, or out of its range, is brought to its default or into the range. A
-- key that is not one of C.Keys is its default. Four things need four keys: with two of them on
-- one key all four are the defaults (out.clash says so).
do
	local function Key(v)
		v = string.lower(tostring(v or "")):gsub("^%s+", ""):gsub("%s+$", "")
		return C.Keys[v] and v or nil
	end
	local function Num(v, lo, hi, def)
		v = tonumber(v)
		if not v or v ~= v then return def end
		return v < lo and lo or (v > hi and hi or v)
	end
	function C.Prefs(read, out)
		out = out or {}
		local d = C.Defaults
		local kr, kl, kd, kg = Key(read("fh_bind_right_arm")), Key(read("fh_bind_left_arm")), Key(read("fh_bind_reach")), Key(read("fh_bind_grip"))
		out.unknown = not (kr and kl and kd and kg)
		local r, l, depth, grip = kr or d.right, kl or d.left, kd or d.depth, kg or d.grip
		out.clash = r == l or depth == grip or depth == r or depth == l or grip == r or grip == l
		if out.clash then r, l, depth, grip = d.right, d.left, d.depth, d.grip end
		out.right, out.left, out.depth, out.grip = r, l, depth, grip
		out.sens = Num(read("fh_sensitivity"), 0.2, 4, d.sens)
		out.invert = (tonumber(read("fh_invert_y")) or 0) ~= 0
		out.smooth = Num(read("fh_smoothing"), 0, 1, d.smooth)
		out.reach = Num(read("fh_reach"), 0.85, 1, d.reach)
		return out
	end
	C.BotPrefs = C.Prefs(function() return nil end)
end

------------------------------------------------------------------------------------------
-- The body (Z-City's citizens; units). [M] where marked, from scene fh_probe.
------------------------------------------------------------------------------------------
C.Body = {
	-- the shoulder joints relative to the player's origin, in the frame of the eye's yaw
	shoulderDrop = 7.0,          -- [M] below the eye (the upper arm's joint, run fh1)
	-- The upper arms' joints of the player model with a weapon of this module in its hands,
	-- about the feet in the frame of the eye's yaw (scene fh_probe_turn, run fh22): the left one
	-- 0.9 in front and 8.8 to the left, the right one 1.6 in front and 6.6 to the right, and
	-- they stay there within a unit while the view is turned on the spot (the model's feet lag
	-- up to 45 degrees behind the eye, its trunk turns the rest). Until phase 39 these were 5.6
	-- to each side of the origin: the arms were drawn from the model's own joints all the same,
	-- and the hands sat to the right of the middle of the first-person picture.
	shoulderHalf = 7.7,          -- [M] to each side of their middle
	shoulderFwd = 1.2,           -- [M] their middle in front (+) of the origin
	shoulderSide = 1.1,          -- [M] and to the left (+) of it
	upperArm = 11.12,            -- [M] shoulder to elbow
	foreArm = 11.21,             -- [M] elbow to wrist
	hand = 3.4,                  -- [G] wrist to the knuckles of a fist
	reach = 0.965,               -- of the two bones together: an arm is never quite straight
	fold = 0.42,                 -- of the two bones together: nearer the shoulder a hand cannot come
	-- how much of the eye's pitch the working space of the hands follows
	pitchFollow = 0.62,          -- [G]
	-- the trunk and the head as what a hand must stay out of
	trunkLow = 33, trunkHigh = 54, trunkR = 5.6, trunkFwd = -1.0,    -- a capsule up the spine [M]
	elbowPad = 1.2,              -- an elbow stays this far outside it (the arm is thick) [G]
	-- A ball round the face. Z-City's first-person camera is at the eyes, 5 to 7.5 units in front
	-- of the origin (run fh2), and these citizens' arms are short (42 cm from shoulder to wrist):
	-- a hand that is raised passes 8 units from the lens and fills a third of the screen, and a
	-- weapon swung down goes through the lens (run fh7). Nothing of a hand or of a weapon comes
	-- nearer the eyes than this.
	-- (the eye the first-person picture is taken with: 6.2 in front of the origin and 2.1 to
	-- the left of it, run fh22)
	headUp = 0.5, headFwd = 6.0, headSide = 2.0, headR = 9.5,        -- [M: G]
	-- The shoulder goes with the arm (cl_render.lua, Shoulder): the collar bone is turned so
	-- that the arm's joint rises by `shrug` units when the hand is as high over it as an arm is
	-- long, and goes `protract` units toward the hand when the arm is stretched. Z-City's arm
	-- solver bends two bones from a joint that never moves: until phase 41 nothing above the
	-- upper arm answered a hand. Drawn only. [G]
	shrug = 2.6, protract = 2.4,
	-- How far a wrist is drawn bent sideways by a handle in its fist (degrees): toward the
	-- little finger (the weapon pointed along the forearm), and the other way (cl_tool.lua). [R: about 35 and 20 for the bare joint; a handle lies askew in the palm by some 25 more]
	wristFwd = 60, wristBack = 25,
	-- Where that eye goes with the head (scene fh_bodycam, runs fh24 and fh27): walking at 93
	-- units/s it is 10.8 in front of the origin, looking 62 degrees down 13.8 in front and 7.5
	-- lower, looking 44 degrees up 3 behind. Without this the fists of a walking player were 5.9
	-- units from the lens. Units of the eye's way forward per unit/s of walking, and at most;
	-- units forward per sine of the eye's pitch; units down per its square, looking down. [M]
	headWalk = 0.045, headWalkMax = 5, headNod = 8.6, headDrop = 8.5,
	-- masses for what a blow moves (kg) [R]
	headMass = 4.8, trunkMass = 38, limbMass = 4.2, bodyMass = 75,
}

------------------------------------------------------------------------------------------
-- The arm as an actuator [R: G]
------------------------------------------------------------------------------------------
C.Arm = {
	mass = 2.1,                  -- kg: what of forearm and hand has to be moved with a fist
	force = 430,                 -- N: the most one arm pushes or pulls
	-- How an arm goes for a target: as fast as it can still stop in time. Far from the target it
	-- pulls with all it has; the speed it allows itself falls with the distance left, along the
	-- curve of a body braked by `brake` of the arm's force; inside `zone` it is a damped spring.
	-- (A plain spring that does not overshoot is slow: 1.8 m/s for a hand flicked 15 cm, run fh2.)
	brake = 0.8,                 -- of the arm's force: what the approach leaves for stopping
	zone = 3.0,                  -- units
	servo = 0.012,               -- s: how soon the hand has the speed the arm wants
	-- A muscle that shortens fast pushes less: the arm's force falls in a straight line with the
	-- speed of what it pushes, to nothing at `maxSpeed`; against the movement (braking) it holds
	-- `eccentric` times its force. [R: a fist reaches about 9 m/s, docs/FREEHAND_RESEARCH.md]
	maxSpeed = 13,               -- m/s
	eccentric = 1.3,
	-- How hard an arm tries follows how fast the player moves its target. A hand that is sent
	-- somewhere slowly goes there gently: it pushes with `effortMin` of the arm's force at most,
	-- so a weapon that is slowly brought against something leans on it and no more. (With full
	-- force whatever the gesture, a hatchet carried slowly into a body was pinned by its handle,
	-- levered round and struck with 10 J, run fh15.) A target that moves at `effortFull` or
	-- faster has all of the arm; the effort outlasts the gesture by `effortHold`, the time a
	-- hand needs to arrive. Stopping a hand is never held back.
	effortMin = 0.25, effortFull = 2.0, effortHold = 0.45,       -- of the force; m/s; s [G]
	-- the wrist of a hand that holds a tool alone
	wrist = 13,                  -- N m: the most it turns a tool about its grip [R: G]
	wristStiff = 55,             -- N m per radian
	wristDamp = 0.7,             -- of what would just not swing back (a ratio)
	-- The angle between the forearm and the handle (toward the head), in degrees. A hand that
	-- holds a tool ready holds it at `wristRest`; the joint lets the handle lean from
	-- `wristMid` by `wristCone` to any side, and no further. [G, from how a wrist moves: about
	-- 35 degrees toward the little finger and 20 toward the thumb, more in flexion]
	wristRest = 42,
	wristMid = 62,
	wristCone = 36,
	wristStop = 320,             -- N m per radian past that (the joint itself, not a muscle)
	-- turning a handle about its own length: the edge leads where the head is going
	rollTorque = 5,              -- N m
	rollStiff = 30,              -- N m per radian
	edgeFrom = 1.2,              -- m/s of the head: from here the edge turns into the movement
	edgeFull = 3.5,              -- m/s: and from here it follows it alone
	slideSpeed = 1.6,            -- m/s: a hand sliding along a handle
	takeHold = 2.4,              -- units: a hand this near the handle takes hold of it
	-- the mouse
	-- (0.030 until phase 41: the first person who played it had to move the mouse too far)
	degPerCount = 0.050,         -- degrees of arc a hand goes for one count of the mouse [G]
	unitsPerCount = 0.022,       -- units of reach for one count, with the depth key held [G]
	maxCount = 1500,              -- counts a tick: more than a hand could follow is not taken
	-- fh_smoothing 1: the mouse's movement is paid out with this time constant (s); less for less
	smoothMax = 0.10,
	-- A hand whose button is let go eases back to its guard, and the next press takes it over
	-- from wherever its target has come to: the mouse's zero is the guard (docs/
	-- FREEHAND_RESEARCH.md, 1.3). After this long, at this rate. Two hands on one handle go back
	-- together, when both are let go.
	releaseHold = 0.12,          -- s [G]
	recenterRate = 4.0,          -- 1/s [G]
	-- Two hands on one handle (sh_tool.lua, S.ToolTargets): how much of the mouse's way the
	-- grip is carried, and how fast the handle is turned (its direction's movement over the
	-- half ball, per radian of the mouse's arc), for the leading arm held alone, the arm at
	-- the butt alone, and both. Before phase 40 the leading arm levered the weapon about the
	-- other hand (its head went up to 66 degrees off the mouse's way, and a small correction
	-- did next to nothing), the arm at the butt sent the head the opposite way, and both
	-- only carried it (tools/fhsim/t_traj.lua). [G]
	steer = { lead = { 1.0, 1.2 }, butt = { 0.5, 1.6 }, both = { 1.0, 2.2 } },
	-- Reach follows the gesture: a fist's target is at its guard's reach at the guard and at
	-- `extendTo` of the arm's length once it is `extendOver` degrees away from it. A guard is
	-- close, a swing goes wide; the depth key adds to it or takes from it. Fists only. [G]
	extendOver = 30, extendTo = 0.95,
	-- limits of a target about its shoulder (degrees; "in" is across the body)
	-- (Until phase 41: 78 across, 96 out, 86 up, 74 down. 96 out is past the line of the
	-- shoulders: a hand could be put behind its owner.)
	azIn = 70, azOut = 80, elUp = 80, elDown = 72,
	-- What else a hand, and what the mouse asks of it, stays inside (sh_body.lua):
	--   in front of the line of the shoulders by this much (units);
	--   no further across the middle of the body than this (units);
	--   two fists no nearer to each other than this (units, between the wrists).
	front = 1.0, cross = 4.0, fistApart = 5.0,
	-- The elbow goes round the line from shoulder to hand no faster than this (degrees a
	-- second). Where it wants to be is worked out from where the hand is, and that changes at
	-- once for certain places of the hand; an elbow does not.
	elbowTurn = 540,
}

-- Rest targets about each hand's own shoulder: azimuth toward the middle (degrees), elevation,
-- reach as a share of the arm's. Fists at the height of the chin and well out in front: there
-- they are at the lower edge of what Z-City's first-person camera sees, 25 degrees under the
-- middle, and do not hide what is looked at (nearer and higher, run fh5, they filled the screen).
-- The view's turn after a held hand (cl_camera.lua). How much of it there is, is one setting
-- (fh_camera_follow, 0 to 1); the rest is here. [G]
C.Cam = {
	zone = 0.85,                 -- the share of half the picture, from its middle, inside which a held hand leaves the view alone
	max = 14,                    -- degrees the view turns after a hand at the most, with the setting at 1
	-- With a weapon in the hands the view turns this share of that. The hands on a handle end a
	-- full swing drawn in near the chest, which is out at the side of the picture: with the
	-- whole of it every full swing turned the view as far as it may (run fh53).
	toolShare = 0.5,
	speed = 7,                   -- 1/s: nine tenths of the way in 0.6 s
	pitchShare = 0.6,            -- up and down the view turns this share of what it may turn sideways
}

C.Guard = {
	-- (the wrists a hand's width from the middle: a fist is longer than its wrist, and with
	-- less the knuckles of the two met, run fh6)
	-- (Where the fists were before the shoulders were put where the model has them, but about
	-- the eye instead of the origin: 4.4 and 4.7 units to each side of the line the eye looks
	-- along. The eye is a unit to the left of the shoulders' middle, so the two angles differ.)
	fists = { { azIn = 8.6, el = 12, ext = 0.70 }, { azIn = 14.2, el = 10, ext = 0.74 } },   -- left, right [G]
}

-- The hold type of every weapon while it is ours: the animation under the arms. This one stands
-- square to the front (the arms themselves are placed by the simulation, whatever it does).
C.HoldType = "revolver"

-- Player classes of Z-City whose bare hands are something else (claws, a zombie's arms): theirs.
C.SkipPlayerClass = { headcrabzombie = true, furry = true }

------------------------------------------------------------------------------------------
-- The simulation
------------------------------------------------------------------------------------------
C.Sim = {
	substeps = 4,                -- of a tick
	gravity = 9.81,              -- m/s^2 on what the hands hold
	teleport = 96,               -- units in one tick: further and the state is laid on the body again
	netEvery = 2,                -- ticks between two snapshots for the other clients
	ownEvery = 4,                -- ticks between two states sent to the player they belong to
}

------------------------------------------------------------------------------------------
-- Contact: what the hands and the weapon run into, and what that does to both.
------------------------------------------------------------------------------------------
C.Hit = {
	minMove = 0.2,               -- units in a tick: a place that moved less is not swept
	fistR = 2.3,                 -- units: the knuckles as a ball
	edgeCut = 0.6,               -- how well a blade must lead to cut (1: straight on its edge)
	armBlock = 0.35,             -- of a blow's damage: what a forearm that stopped it takes
	skin = 0.3,                  -- units: how far off a surface a place is put back
	friction = 0.25,             -- of the push into a surface: what scraping along it takes [G]
	armR = 1.7,                  -- units: a forearm as something that is in the way [M: the citizen]
	barR = 0.9,                  -- units: a handle as something that is in the way
	fistMass = 2.9,              -- kg: what a punch is worth to what it hits [R: Walilko 2005]
	-- what a struck thing weighs to the blow (kg) [R: G]
	mass = { head = 4.8, trunk = 38, arm = 4.2, leg = 11, other = 30 },
	flesh = 0.2,                 -- of a weapon's rebound: flesh gives
	-- A place that lay against a thing this many ticks ago or less is pressed against it, not
	-- thrown at it. (An arm that pushes a weapon against a body lets it come off a little and
	-- brings it back; every return was a small blow of its own, and a slow push with an axe put
	-- a player out, run fh10.)
	pressTicks = 8,
	-- An arm that was pushing against something does not lunge when the thing gives way: for
	-- this many ticks after a place lay against something the arm goes for its target as if it
	-- were no further off than `calmLead` units. (A hatchet pushed slowly against a body came
	-- free of it and struck at 7 m/s, with the mouse far ahead of the blocked hand, run fh13.)
	calmTicks = 16, calmLead = 4,
	-- what counts as a blow at all (slower, and the weapon merely touches)
	minSpeed = 0.9,              -- m/s into the surface
	minEnergy = 1.2,             -- J
	-- One swing lays more than one place of a weapon on a body. Within this time of a wound the
	-- same weapon gives the same body another only for a blow twice as hard as that one.
	again = 0.15,
	near = 90,                   -- units: other fighters further away are not looked at
}

------------------------------------------------------------------------------------------
-- What a blow does to who was struck (sv_react.lua). [G] throughout: the forms are physics, the
-- numbers are set so that what follows fits the game. One solid punch shakes; two hooks or
-- four straights within a few seconds put a player down, and more put them out; steel to the
-- head does it sooner.
------------------------------------------------------------------------------------------
C.React = {
	headInertia = 0.03,          -- kg m^2: a head about its own middle, with what the neck adds
	dvMax = 9, omegaMax = 90,    -- m/s, rad/s: no blow is taken to move a head more than this
	-- how hard a blow to the head was: 1 is what puts a fresh player on the edge of a knockout
	koOmega = 60,                -- rad/s of turning that alone is 1
	koDv = 9,                    -- m/s of throw that alone is 1
	-- What strikes matters beside how much impulse it brings: a fist gives and spreads the blow
	-- over a hundredth of a second, steel does not. A blow counts with the square of the
	-- striker's hardness against a fist's. (With less, a crowbar on the crown of a head at
	-- 7 m/s did not even shake, run fh10.)
	hardRef = 0.55,
	-- and how fast it came: a slow heavy push is no blow to the head, whatever impulse it has
	sevFrom = 1.5, sevFull = 4.0,                  -- m/s into the head: nothing below, in full above
	dazeHalf = 6,                -- s in which half of it has faded
	-- (run fh9: a fast straight right counts about 0.35, a fast hook about 0.7)
	stagger = 0.4, knockdown = 1.0, knockout = 1.5,
	weak = 0.55, weakTime = 0.9, -- a shaken player's arms: this much of their force, for this long
	downTime = 2.2,              -- s on the ground after a knockdown before Z-City lets the player up
	outTime = 3, outPerDaze = 9, outMax = 14,      -- s out: at the line, per unit beyond it, at most
	-- the body
	fallImpulse = 55,            -- N s within a second or so that put a standing player down
	balHalf = 0.9,               -- s
	legFactor = 1.6, armFactor = 0.4,
	pushMax = 220,               -- units/s: no blow throws a standing body faster
	-- A standing player takes up a blow's impulse with the whole body: 9 N s on 75 kg is 12 cm/s,
	-- gone in a hand's width (run fh11: 0.1 units). Seen from outside that is nothing at all, so
	-- the body gives a little more than its weight says, and the trunk is seen to give (below).
	pushGain = 2.5,
	flinchSpeed = 26,            -- deg/s of the trunk's spring per N s of a blow to the body
	-- the force Z-City's ragdoll starts with when the body falls (its own scale, per N s)
	ragPerNs = 260, ragMax = 11000,
	-- The fall (sv_react.lua, "The fall"): a body that goes limp within `fallWindow` seconds of
	-- a blow topples the way of the blow. The part that was struck starts with this speed per
	-- N s of the blow (units/s; a head of 4.8 kg alone would take 11 from 1 N s), at most
	-- `fallMax`; the rest of the body by how far it is from that part, the far end not at all. [G]
	fallWindow = 0.5, fallPerNs = 7, fallMax = 150, fallReach = 0.7,
	-- what is seen and felt
	viewKick = 13, viewKickMax = 20,               -- degrees per unit of how hard, and at most
	joltFull = 20, joltView = 1.6,                 -- N s of a full jolt in the hand; degrees of view it kicks
	snapSpeed = 520, snapStiff = 190, snapDamp = 13, snapMax = 38,   -- the head's spring: deg/s, 1/s^2, 1/s, degrees
	-- what swinging costs: Z-City's stamina per joule of work the arms do
	staminaPerJoule = 0.12,
	-- arms that are tired: at this share of Z-City's stamina and below they have `tired` of their force
	tiredAt = 0.25, tired = 0.6,
}

------------------------------------------------------------------------------------------
-- Weapons. A weapon is a rigid bar along its own x axis, from the butt (x = 0) to the tip. What
-- it weighs and where is given as parts; mass, centre of mass and inertia are worked out from
-- them (sh_weapon.lua). Nothing about a weapon is written anywhere else.
--   parts     { from, to, mass }: a stretch of bar (m, kg); { at, mass, size }: a lump
--   grips     where the hands hold, in metres from the butt. The right hand leads and is always
--             on the weapon: at `one` when it holds alone, at `two` when the left hand holds too
--             (and anywhere from twoMin to twoMax: it slides). The left hand holds at `butt`.
--   hands     2: both hands by default; 1: one hand by default. canSwitch: the grip key works
--   useAction Z-City's own class does something with USE + primary that is not an attack
--   samples   what of the weapon can touch something: { at (m), r (m), kind }. kind: "bar", "head",
--             "edge" (an axe's blade, see edge), "hook"
--   edge      the blade: the direction it faces in the weapon's frame (y = the side the blade is on)
--   spinDamp  1/s: what the hands take out of the weapon's turning all the time
--   restitution  how much of the closing speed a hit gives back
--   damage    ref: the energy (J) a solid blow with it loses in what it hits; that blow does the
--             damage one swing of the weapon did in Z-City (read from the weapon), others in
--             proportion to their energy, up to `cap` times
--   guard     where the grips rest, about the shoulders' middle, in the frame of the aim
--             (forward, left, up; units). two: the left hand's place and the direction from the
--             butt to the head; one: the right hand's place when it holds alone
--   model     the prop that is drawn: path, and where its origin and axes lie in the weapon's frame
-- Lengths are the drawn models' own (scene fh_probe, run fh2) [M]; masses are real tools' [G].
------------------------------------------------------------------------------------------
C.Weapons = C.Weapons or {}
local W = C.Weapons

W.weapon_hands_sh = {
	name = "hands", kind = "fists",
	-- a fist: what touches is the knuckles (a ball) and the forearm behind them (for a guard)
	fistR = 0.045, forearmR = 0.042,
	restitution = 0.25, hardness = 0.55,
	damageType = DMG_CLUB,
	-- ref: the energy (J) of a solid blow; base: the damage it is (a tool's is its own number in
	-- Z-City, read from the weapon); cap: how many times that at most
	damage = { ref = 35, base = 4, cap = 2.5 },
	guard = "fists",
}

-- A wrecking bar of 59 cm: a steel bar with a little more steel at the hooked end.
W.weapon_hg_crowbar = {
	name = "crowbar", kind = "tool",
	damage = { ref = 45, cap = 2.5 },
	length = 0.587,
	parts = { { from = 0, to = 0.587, mass = 1.25 }, { at = 0.555, mass = 0.25, size = 0.07 } },
	grips = { butt = 0.06, one = 0.10, two = 0.30, twoMin = 0.19, twoMax = 0.43 },
	hands = 2, canSwitch = true,
	useAction = true,            -- Z-City's own use of it with USE held (a locked door) stays
	samples = {
		{ at = 0.02, r = 0.016, kind = "bar" }, { at = 0.16, r = 0.016, kind = "bar" }, { at = 0.29, r = 0.016, kind = "bar" },
		{ at = 0.41, r = 0.018, kind = "bar" }, { at = 0.50, r = 0.020, kind = "bar" }, { at = 0.565, r = 0.030, kind = "hook" },
	},
	spinDamp = 1.2,
	restitution = 0.30, hardness = 1.0,
	damageType = DMG_CLUB,
	guard = { two = { 13.2, 2.0, -9.5 }, dir = { 0.225, -0.54, 0.81 }, one = { 14.2, -5.5, -2.0 } },
	model = { path = "models/weapons/tfa_nmrih/w_me_crowbar.mdl", pos = Vector(0, 0, 0), ang = Angle(0, 0, 0) },
}

W.weapon_hg_crowbar_gordon = table.Copy(W.weapon_hg_crowbar)
W.weapon_hg_crowbar_gordon.name = "crowbar (one hand)"
W.weapon_hg_crowbar_gordon.hands = 1

-- An axe of 61 cm: a light handle and nearly all of the weight in the head.
W.weapon_hg_axe = {
	name = "woodcutting axe", kind = "tool",
	shaft = 0.75,                -- how hard its handle is (wood) against its head
	damage = { ref = 50, cap = 2.5 },
	length = 0.608,
	parts = { { from = 0, to = 0.608, mass = 0.55 }, { at = 0.535, mass = 1.25, size = 0.13 } },
	grips = { butt = 0.06, one = 0.12, two = 0.36, twoMin = 0.19, twoMax = 0.46 },
	hands = 2, canSwitch = true,
	samples = {
		{ at = 0.03, r = 0.018, kind = "bar" }, { at = 0.18, r = 0.018, kind = "bar" }, { at = 0.33, r = 0.018, kind = "bar" },
		{ at = 0.45, r = 0.020, kind = "bar" }, { at = 0.535, r = 0.045, kind = "edge", off = 0.075 }, { at = 0.535, r = 0.035, kind = "head", off = -0.035 },
	},
	edge = { dir = { 0, 1, 0 }, length = 0.115 },
	spinDamp = 1.0,
	restitution = 0.18, hardness = 1.25,
	damageType = DMG_SLASH,
	guard = { two = { 13.2, 2.0, -10.0 }, dir = { 0.20, -0.52, 0.83 }, one = { 14.2, -5.5, -2.5 } },
	model = { path = "models/props/cs_militia/axe.mdl", pos = Vector(0, 0, 0), ang = Angle(0, 0, 0) },
}

-- A hatchet of 37 cm: made for one hand.
W.weapon_hatchet = {
	name = "hatchet", kind = "tool",
	shaft = 0.75,                -- how hard its handle is (wood) against its head
	damage = { ref = 30, cap = 2.5 },
	length = 0.365,
	parts = { { from = 0, to = 0.365, mass = 0.25 }, { at = 0.315, mass = 0.60, size = 0.09 } },
	grips = { butt = 0.045, one = 0.075, two = 0.165, twoMin = 0.145, twoMax = 0.21 },
	hands = 1, canSwitch = true,
	samples = {
		{ at = 0.02, r = 0.016, kind = "bar" }, { at = 0.17, r = 0.016, kind = "bar" },
		{ at = 0.315, r = 0.036, kind = "edge", off = 0.05 }, { at = 0.315, r = 0.028, kind = "head", off = -0.025 },
	},
	edge = { dir = { 0, 1, 0 }, length = 0.085 },
	spinDamp = 1.4,
	restitution = 0.20, hardness = 1.15,
	damageType = DMG_SLASH,
	guard = { two = { 13.7, 1.5, -7.0 }, dir = { 0.20, -0.45, 0.87 }, one = { 14.7, -5.5, -2.0 } },
	model = { path = "models/weapons/tfa_nmrih/w_me_hatchet.mdl", pos = Vector(0, 0, 0), ang = Angle(0, 0, 0) },
}

-- A tomahawk of 36 cm: lighter in the head than the hatchet, and quicker for it.
W.weapon_tomahawk = {
	name = "tomahawk", kind = "tool",
	shaft = 0.75,                -- how hard its handle is (wood) against its head
	damage = { ref = 24, cap = 2.5 },
	length = 0.362,
	parts = { { from = 0, to = 0.362, mass = 0.24 }, { at = 0.32, mass = 0.38, size = 0.08 } },
	grips = { butt = 0.045, one = 0.075, two = 0.165, twoMin = 0.145, twoMax = 0.21 },
	hands = 1, canSwitch = true,
	samples = {
		{ at = 0.02, r = 0.014, kind = "bar" }, { at = 0.17, r = 0.014, kind = "bar" },
		{ at = 0.32, r = 0.032, kind = "edge", off = 0.045 }, { at = 0.32, r = 0.020, kind = "head", off = -0.03 },
	},
	edge = { dir = { 0, 1, 0 }, length = 0.075 },
	spinDamp = 1.4,
	restitution = 0.20, hardness = 1.10,
	damageType = DMG_SLASH,
	guard = { two = { 13.7, 1.5, -7.0 }, dir = { 0.20, -0.45, 0.87 }, one = { 14.7, -5.5, -2.0 } },
	model = { path = "models/pwb/weapons/w_tomahawk_thrown.mdl", pos = Vector(0, 0, 0), ang = Angle(0, 0, 0) },
}

-- The classes this module takes over, and nothing else.
C.Classes = {}
for class in pairs(W) do C.Classes[class] = true end
