-- The body a pair of hands belongs to: when the system applies, the frame the hands work in, the
-- shoulders, and the state of one fighter. Shared: the client steps its own fighter from the
-- commands it sends, the server steps every fighter from the commands it gets.
--
-- Frames. "Aim frame": forward along the eye's yaw and a share of its pitch, left horizontal, up
-- across both. Its origin is the middle between the shoulders. A hand's target is kept in that
-- frame, so turning and looking up or down carries the hands; the hands themselves are simulated
-- in the world, so the body's own movement is felt by whatever they hold.
-- Hands: 1 = left, 2 = right.

FreeHand.SameOnBothSides()
local FH = FreeHand
local C, M = FH.Config, FH.Math
FH.Body = FH.Body or {}
local B = FH.Body
local sin, cos, rad, deg, sqrt, asin, acos, atan2, abs, min, max = math.sin, math.cos, math.rad, math.deg, math.sqrt, math.asin, math.acos, math.atan2, math.abs, math.min, math.max
local Clamp = M.Clamp

B.SIDE = { 1, -1 }          -- toward the left (+) for the left hand, toward the right for the right

function FH.Profile(wep)
	if not IsValid(wep) then return nil end
	return C.Weapons[wep:GetClass()]
end

-- The ragdoll Z-City has put a player into, if any (the client's field can be unset while the
-- player lies: ask both).
local function Ragdolled(ply)
	if IsValid(ply.FakeRagdoll) then return true end
	local r = ply:GetNWEntity("FakeRagdoll")
	return IsValid(r)
end
B.Ragdolled = Ragdolled

-- The profile of the weapon in a player's hands when this module is to handle it, or nil: then
-- everything is Z-City's as before.
function FH.Applies(ply, wep)
	if not C.cv.enabled:GetBool() then return nil end
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return nil end
	wep = wep or ply:GetActiveWeapon()
	local prof = FH.Profile(wep)
	if not prof or wep.FH_broken then return nil end
	if ply:InVehicle() or Ragdolled(ply) then return nil end
	if ply.GetNetVar and ply:GetNetVar("handcuffed", false) then return nil end
	-- (what Z-City does with a blade and its owner's own throat is Z-City's)
	if ply.suiciding then return nil end
	if prof.kind == "fists" then
		if C.SkipPlayerClass[ply.PlayerClassName or ""] then return nil end
		-- (lowered hands carry things and open doors: Z-City's. Raised, they are fists: ours)
		if not (wep.GetFists and wep:GetFists()) then return nil end
		if wep.GetNWEntity and IsValid(wep:GetNWEntity("carryent")) then return nil end
	end
	local org = ply.organism
	if SERVER and istable(org) and org.otrub then return nil end
	return prof
end

------------------------------------------------------------------------------------------
-- State
------------------------------------------------------------------------------------------
local function NewHand()
	return {
		tf = 0, tl = 0, tu = 0,                    -- target, aim frame, about the shoulders' middle
		wx = 0, wy = 0, wz = 0,                    -- target, world (after the limits)
		px = 0, py = 0, pz = 0, vx = 0, vy = 0, vz = 0,   -- the hand itself, world
		qx = 0, qy = 0, qz = 0,                    -- where it was a tick ago (for drawing and for sweeps)
		sx = 0, sy = 0, sz = 0,                    -- its shoulder, world
		fx = 0, fy = 0, fz = 0,                    -- the force the arm made last (kg unit / s^2)
		on = false,                                -- held by the player this tick
		idle = 0,                                  -- seconds since it was let go
		effort = 0.25,                             -- how much of the arm's force goes into pushing (sh_sim.lua)
		ptf = 0, ptl = 0, ptu = 0,                 -- where the target was a tick ago (aim frame)
		grip = true,                               -- on the weapon (a tool's second hand may be off it)
	}
end

function B.NewState()
	return {
		ok = false,                                -- laid on the body (false: the next step does it)
		tick = 0,
		prof = nil,
		h = { NewHand(), NewHand() },
		-- the aim frame
		ox = 0, oy = 0, oz = 0,                    -- shoulders' middle, world
		fx = 1, fy = 0, fz = 0, lx = 0, ly = 1, lz = 0, ux = 0, uy = 0, uz = 1,
		yaw = 0, pitch = 0, cy = 1, sy = 0,
		tax = 0, tay = 0, tlow = 0, thigh = 0, tr = 1,   -- the trunk (B.Trunk)
		hbx = 0, hby = 0, hbz = 0,                 -- the middle of the ball about the eye
		bvx = 0, bvy = 0, bvz = 0,                 -- the body's velocity
		idle = 0,                                  -- seconds since a hand was held
		work = 0,                                  -- what the arms have done since it was last asked (kg unit^2 / s^2)
		twoHand = false,                           -- a tool: the left hand is to hold it too
		gripKeyWas = false,
		w = nil,                                   -- the weapon's rigid body (sh_weapon.lua), tools only
		touch = {},                                -- place of the weapon -> what it lay against, and when
		pressTick = -1000,                         -- the last tick a place was pressed against something
	}
end

FH.states = FH.states or setmetatable({}, { __mode = "k" })
function FH.State(ply)
	local st = FH.states[ply]
	if not st then st = B.NewState() FH.states[ply] = st end
	return st
end

------------------------------------------------------------------------------------------
-- The aim frame
------------------------------------------------------------------------------------------
-- pos: the player's origin; eyeZ: the height of the eye over it; yaw, pitch: of the eye (degrees).
function B.SetFrame(st, px, py, pz, eyeZ, yaw, pitch, vx, vy, vz)
	local bd = C.Body
	local y = rad(yaw)
	local p = rad(Clamp(pitch, -89, 89) * bd.pitchFollow)
	local cy, sy, cp, sp = cos(y), sin(y), cos(p), sin(p)
	st.yaw, st.pitch = yaw, pitch
	st.fx, st.fy, st.fz = cy * cp, sy * cp, -sp
	st.lx, st.ly, st.lz = -sy, cy, 0
	st.ux, st.uy, st.uz = sp * cy, sp * sy, cp
	local z = Clamp(eyeZ, 24, 72) - bd.shoulderDrop
	st.ox, st.oy, st.oz = px + cy * bd.shoulderFwd - sy * bd.shoulderSide, py + sy * bd.shoulderFwd + cy * bd.shoulderSide, pz + z
	st.bx, st.by, st.bz = px, py, pz             -- the feet
	st.eyeZ = eyeZ
	st.bvx, st.bvy, st.bvz = vx, vy, vz
	st.cy, st.sy = cy, sy
	st.tax, st.tay, st.tlow, st.thigh, st.tr = B.Trunk(px, py, pz, eyeZ, yaw)
	-- The head: a ball about the eye the first-person picture is taken with. That eye is on the
	-- model's head, and the head moves: forward when the player walks (the body leans into it),
	-- forward and down when the player looks down (the head nods about the neck), back when the
	-- player looks up (sh_config.lua, headWalk and after).
	local sp1 = sin(rad(Clamp(pitch, -89, 89)))
	local hf = bd.headFwd + Clamp((vx * cy + vy * sy) * bd.headWalk, 0, bd.headWalkMax) + bd.headNod * sp1
	local hz = eyeZ + bd.headUp - (sp1 > 0 and bd.headDrop * sp1 * sp1 or 0)
	st.hbx, st.hby, st.hbz = px + cy * hf - sy * bd.headSide, py + sy * hf + cy * bd.headSide, pz + hz
	for i = 1, 2 do
		local h = st.h[i]
		local k = bd.shoulderHalf * B.SIDE[i]
		h.sx, h.sy, h.sz = st.ox + st.lx * k, st.oy + st.ly * k, st.oz
	end
end

function B.ArmLength() return C.Body.upperArm + C.Body.foreArm end

-- Aim-frame coordinates (forward, left, up about the shoulders' middle) to the world and back.
function B.ToWorld(st, f, l, u)
	return st.ox + st.fx * f + st.lx * l + st.ux * u, st.oy + st.fy * f + st.ly * l + st.uy * u, st.oz + st.fz * f + st.lz * l + st.uz * u
end
function B.ToAim(st, x, y, z)
	x, y, z = x - st.ox, y - st.oy, z - st.oz
	return x * st.fx + y * st.fy + z * st.fz, x * st.lx + y * st.ly + z * st.lz, x * st.ux + y * st.uy + z * st.uz
end
-- A direction only.
function B.DirToWorld(st, f, l, u)
	return st.fx * f + st.lx * l + st.ux * u, st.fy * f + st.ly * l + st.uy * u, st.fz * f + st.lz * l + st.uz * u
end

------------------------------------------------------------------------------------------
-- A hand's target about its own shoulder: across the body (degrees), up (degrees), reach (units).
------------------------------------------------------------------------------------------
function B.TargetPolar(i, tf, tl, tu)
	local half = C.Body.shoulderHalf * B.SIDE[i]
	local x, y, z = tf, tl - half, tu
	local ext = sqrt(x * x + y * y + z * z)
	if ext < 1e-4 then return 0, 0, 0 end
	local el = deg(asin(Clamp(z / ext, -1, 1)))
	-- across the body: toward the right for the left hand, toward the left for the right hand
	local azIn = deg(atan2(-y * B.SIDE[i], x))
	return azIn, el, ext
end

function B.PolarTarget(i, azIn, el, ext)
	local a, e = rad(azIn), rad(el)
	local half = C.Body.shoulderHalf * B.SIDE[i]
	return cos(e) * cos(a) * ext, half - sin(a) * cos(e) * ext * B.SIDE[i], sin(e) * ext
end

-- The same target inside the limits of a shoulder and an arm.
function B.LimitPolar(azIn, el, ext)
	local a = C.Arm
	local L = B.ArmLength()
	return Clamp(azIn, -a.azOut, a.azIn), Clamp(el, -a.elDown, a.elUp), Clamp(ext, L * C.Body.fold, L * C.Body.reach)
end

-- How far a hand reaches by itself at a direction (degrees) g.azIn, g.el being its guard's and
-- g.ext the guard's share of the arm's length (sh_config.lua, extendOver). Units.
local function OwnReach(g, azIn, el)
	local a = C.Arm
	local a0, e0, a1, e1 = rad(g.azIn), rad(g.el), rad(azIn), rad(el)
	local c = cos(e0) * cos(e1) * cos(a1 - a0) + sin(e0) * sin(e1)
	local s = Clamp(deg(acos(Clamp(c, -1, 1))) / a.extendOver, 0, 1)
	s = s * s * (3 - 2 * s)
	local far = a.extendTo > g.ext and a.extendTo or g.ext
	return B.ArmLength() * (g.ext + (far - g.ext) * s)
end
B.OwnReach = OwnReach

-- Moves a target by the mouse: across, up, and (with the depth key) out. Returns the new target.
-- g: the hand's guard when its reach is to follow the gesture (a fist), or nil.
-- (Past the middle of the body a hand's target goes only a little: arms do not cross far.)
local function NotAcross(i, tf, tl, tu)
	local c = C.Arm.cross
	if B.SIDE[i] > 0 then
		if tl < -c then tl = -c end
	elseif tl > c then
		tl = c
	end
	return tf, tl, tu
end

-- slide: a hand that leads a weapon held in two hands (below).
function B.MoveTarget(i, tf, tl, tu, dAcross, dUp, dOut, g, slide)
	local azIn, el, ext = B.TargetPolar(i, tf, tl, tu)
	-- (mouse to the right is across the body for the left hand and away from it for the right)
	local az1, el1 = azIn + dAcross * B.SIDE[i], el + dUp
	if g and C.Arm.extendOver > 0 then
		-- what the depth key has added to the reach, or taken from it, stays as it is
		local kept = ext - OwnReach(g, azIn, el)
		az1, el1 = B.LimitPolar(az1, el1, ext)
		ext = OwnReach(g, az1, el1) + kept
	end
	azIn, el, ext = B.LimitPolar(az1, el1, ext + dOut)
	-- Past the middle of the body a hand goes only a little (C.Arm.cross), and there it stops
	-- going across: the direction is held at the limit, the reach and the height stay. (Until
	-- phase 42 the target was cut off sideways only, after the turn: every further movement of
	-- the mouse across then brought the hand nearer the chest, and a hook pulled the fist back
	-- 8 units instead of taking it across.) The hand that leads a weapon held in two hands is
	-- left to slide in along the limit as before: that is how a swing in two hands ends, the
	-- hands drawn in toward the far side of the chest, and with them stopped there instead the
	-- head of a crowbar swung sideways did 8 m/s where it had done 10 (run fh52).
	if not slide then
		local most = (C.Body.shoulderHalf + C.Arm.cross) / max(cos(rad(el)) * ext, 1e-3)
		if most < 1 then
			local azMost = deg(asin(most))
			if azIn > azMost then azIn = azMost end
		end
	end
	return NotAcross(i, B.PolarTarget(i, azIn, el, ext))
end

------------------------------------------------------------------------------------------
-- What a hand must stay out of: the trunk and the head. A point (world) is pushed to the surface
-- when it is inside; returns the point and how deep it was (units, 0 outside).
------------------------------------------------------------------------------------------
-- The trunk: a capsule up from the feet, a little behind the origin. Returns its axis (x, y), the
-- heights of its two ends and its radius.
function B.Trunk(bx, by, bz, eyeZ, yaw)
	local bd = C.Body
	local cy, sy = cos(rad(yaw)), sin(rad(yaw))
	return bx + cy * bd.trunkFwd, by + sy * bd.trunkFwd, bz + bd.trunkLow * (eyeZ / 64), bz + eyeZ - (64 - bd.trunkHigh), bd.trunkR
end

-- hand: the point is a hand, or where one is wanted. A hand also stays in front of the line of
-- the shoulders (a weapon's head may go behind it: that is a wind-up).
function B.KeepOut(st, x, y, z, pad, hand)
	local bd = C.Body
	local deep = 0
	local cy, sy = st.cy, st.sy
	if hand then
		local fwd = (x - st.ox) * cy + (y - st.oy) * sy
		local need = C.Arm.front - fwd
		if need > 0 then
			x, y = x + cy * need, y + sy * need
			deep = need
		end
	end
	local ax, ay, low, high = st.tax, st.tay, st.tlow, st.thigh
	local cz = Clamp(z, low, high)
	local dx, dy, dz = x - ax, y - ay, z - cz
	local r = bd.trunkR + pad
	local d2 = dx * dx + dy * dy + dz * dz
	if d2 < r * r then
		local d = sqrt(d2)
		if d < 1e-3 then dx, dy, dz, d = cy, sy, 0, 1 end
		deep = r - d
		x, y, z = ax + dx / d * r, ay + dy / d * r, cz + dz / d * r
	end
	-- the head: a ball at the eye
	local hx, hy, hz = st.hbx, st.hby, st.hbz
	dx, dy, dz = x - hx, y - hy, z - hz
	r = bd.headR + pad
	d2 = dx * dx + dy * dy + dz * dz
	if d2 < r * r then
		local d = sqrt(d2)
		if d < 1e-3 then dx, dy, dz, d = cy, sy, 0, 1 end
		deep = max(deep, r - d)
		x, y, z = hx + dx / d * r, hy + dy / d * r, hz + dz / d * r
	end
	return x, y, z, deep
end

-- A point (world) no further from a shoulder than an arm reaches. Returns the point and how far
-- beyond it was.
function B.WithinReach(h, x, y, z)
	local L = B.ArmLength() * C.Body.reach * (h.reachK or 1)
	local dx, dy, dz = x - h.sx, y - h.sy, z - h.sz
	local d = sqrt(dx * dx + dy * dy + dz * dz)
	if d <= L then return x, y, z, 0 end
	local k = L / d
	return h.sx + dx * k, h.sy + dy * k, h.sz + dz * k, d - L
end

------------------------------------------------------------------------------------------
-- Where the elbow is for a hand at a place: the arm's two bones as a triangle, turned about the
-- line shoulder - hand so that the elbow points down and outward (more outward the higher the
-- hand and the further across the body it is, as a raised or a crossed arm's does).
-- All in the world; fwd, left, up: the aim frame. Returns the elbow.
-- tax..tr: the trunk (B.Trunk), when the elbow is to stay out of it: an elbow that would be
-- inside is turned outward about the line shoulder - hand until it lies on the trunk's surface.
------------------------------------------------------------------------------------------
local function InTrunk(x, y, z, tax, tay, tlow, thigh, r)
	local dz = z - Clamp(z, tlow, thigh)
	local dx, dy = x - tax, y - tay
	return dx * dx + dy * dy + dz * dz < r * r
end

-- qx, qy, qz, turn: where the elbow was a moment ago, and how far round the line from shoulder
-- to hand it may have gone since (radians); nil: wherever it wants to be.
function B.Elbow(i, sx, sy, sz, hx, hy, hz, fx, fy, fz, lx, ly, lz, ux, uy, uz, l1, l2, tax, tay, tlow, thigh, tr, qx0, qy0, qz0, turn)
	local nx, ny, nz, d = M.Norm(hx - sx, hy - sy, hz - sz)
	if d < 1e-3 then nx, ny, nz, d = fx, fy, fz, 1e-3 end
	d = Clamp(d, abs(l1 - l2) + 0.05, l1 + l2 - 0.02)
	local a = (l1 * l1 - l2 * l2 + d * d) / (2 * d)
	local hgt = sqrt(max(l1 * l1 - a * a, 0))
	-- how high the hand is over the shoulder and how far across the body, 0..1
	local rx, ry, rz = hx - sx, hy - sy, hz - sz
	local L = l1 + l2
	local upK = Clamp((rx * ux + ry * uy + rz * uz) / L, 0, 1)
	local inK = Clamp(-(rx * lx + ry * ly + rz * lz) * B.SIDE[i] / L, 0, 1)
	local out = B.SIDE[i]
	-- (an arm that reaches across the body has its elbow out and back, not under the arm)
	-- (and one whose hand is in front of its own shoulder hangs its elbow under it: a guard)
	local kd, ko, kb = max(0.95 - 0.60 * upK - 0.45 * inK, 0.1), 0.25 + 0.70 * upK + 0.60 * inK, 0.30 + 0.25 * inK
	local px = -ux * kd + lx * out * ko - fx * kb
	local py = -uy * kd + ly * out * ko - fy * kb
	local pz = -uz * kd + lz * out * ko - fz * kb
	-- across the line shoulder - hand
	local k = px * nx + py * ny + pz * nz
	px, py, pz = px - nx * k, py - ny * k, pz - nz * k
	local pl
	px, py, pz, pl = M.Norm(px, py, pz)
	if pl < 1e-4 then px, py, pz = M.Norm(M.Cross(nx, ny, nz, lx, ly, lz)) end
	local mx, my, mz = sx + nx * a, sy + ny * a, sz + nz * a
	local ex, ey, ez = mx + px * hgt, my + py * hgt, mz + pz * hgt
	if tax and hgt > 0.05 then
		local r = tr + C.Body.elbowPad
		if InTrunk(ex, ey, ez, tax, tay, tlow, thigh, r) then
			-- the other direction across the line, on the side that leads outward
			local qx, qy, qz = M.Cross(nx, ny, nz, px, py, pz)
			if (qx * lx + qy * ly + qz * lz) * out < 0 then qx, qy, qz = -qx, -qy, -qz end
			-- the first of a few fixed turns that is clear, then halved back to the surface
			local step = rad(15)
			local lo, hi = 0, nil
			for n = 1, 9 do
				local c, s = cos(step * n), sin(step * n)
				if not InTrunk(mx + (px * c + qx * s) * hgt, my + (py * c + qy * s) * hgt, mz + (pz * c + qz * s) * hgt, tax, tay, tlow, thigh, r) then
					hi = step * n
					break
				end
				lo = step * n
			end
			if hi then
				for _ = 1, 5 do
					local mid = (lo + hi) * 0.5
					local c, s = cos(mid), sin(mid)
					if InTrunk(mx + (px * c + qx * s) * hgt, my + (py * c + qy * s) * hgt, mz + (pz * c + qz * s) * hgt, tax, tay, tlow, thigh, r) then lo = mid else hi = mid end
				end
				local c, s = cos(hi), sin(hi)
				ex, ey, ez = mx + (px * c + qx * s) * hgt, my + (py * c + qy * s) * hgt, mz + (pz * c + qz * s) * hgt
			end
		end
	end
	if qx0 and turn and hgt > 0.05 then
		-- From where it was toward where it wants to be, round the line, no faster than an
		-- elbow goes. (Where it wants to be can change at once: the direction it is taken from
		-- has no meaning when it lies along the arm, and the way out of the trunk has two sides.)
		local ox, oy, oz = qx0 - mx, qy0 - my, qz0 - mz
		local k = ox * nx + oy * ny + oz * nz
		local ol
		ox, oy, oz, ol = M.Norm(ox - nx * k, oy - ny * k, oz - nz * k)
		if ol > 1e-3 then
			local wx, wy, wz = (ex - mx) / hgt, (ey - my) / hgt, (ez - mz) / hgt
			local c = Clamp(ox * wx + oy * wy + oz * wz, -1, 1)
			local ang = acos(c)
			if ang > turn then
				-- the side to turn to: the sign of (old x wanted) along the line
				local cx, cy2, cz = M.Cross(ox, oy, oz, wx, wy, wz)
				local sgn = (cx * nx + cy2 * ny + cz * nz) < 0 and -1 or 1
				local tx, ty, tz = M.Cross(nx, ny, nz, ox, oy, oz)
				-- (Not into the trunk. The short way round to where it wants to be may lead
				-- through it: the elbow then stays on its side, and only if the trunk comes to it
				-- does it go on, the least it must, either way.)
				local function At(angle)
					local ct, stn = cos(angle), sin(angle)
					local rx2, ry2, rz2 = ox * ct + tx * stn, oy * ct + ty * stn, oz * ct + tz * stn
					local e2x, e2y, e2z = mx + rx2 * hgt, my + ry2 * hgt, mz + rz2 * hgt
					if tax and InTrunk(e2x, e2y, e2z, tax, tay, tlow, thigh, tr + C.Body.elbowPad * 0.5) then return nil end
					return e2x, e2y, e2z
				end
				local e2x, e2y, e2z = At(turn * sgn)
				if not e2x then e2x, e2y, e2z = At(0) end
				local n = 2
				while not e2x and n <= 12 do
					e2x, e2y, e2z = At(turn * n * sgn)
					if not e2x then e2x, e2y, e2z = At(-turn * (n - 1) * sgn) end
					n = n + 1
				end
				if e2x then ex, ey, ez = e2x, e2y, e2z end
			end
		end
	end
	return ex, ey, ez
end
