-- Client half of the free-hand test scenes (developer tool). Inert unless
-- garrysmod/data/abl_selftest.txt exists on this machine.

FreeHand.NoJIT()
local FH = FreeHand
if not FH.testRun or not (istable(ABL) and istable(ABL.TestClient)) then return end
local H = ABL.TestClient.H
local C, M, B, R = FH.Config, FH.Math, FH.Body, FH.Render
local cl = FH.cl
local OUT = "abl_test/client_freehand.txt"

local function Log(s)
	file.CreateDir("abl_test")
	file.Append(OUT, string.format("%8.2f %s\n", CurTime(), s))
end

local function Reply(tag, t)
	net.Start("fh_t")
	net.WriteString(tag or "?")
	net.WriteTable(t or {})
	net.SendToServer()
end

local BP = "ValveBiped.Bip01_"

------------------------------------------------------------------------------------------
-- fhprobe: the body's bones as the animation has them; a weapon's models.
------------------------------------------------------------------------------------------
local function ProbeBody(t)
	local ent = Entity(t.ent or -1)
	if not IsValid(ent) then Log("probe body " .. tostring(t.name) .. ": no entity") return end
	ent:InvalidateBoneCache()
	ent:SetupBones()
	local o = ent:GetPos()
	local yaw = math.rad(ent:EyeAngles().y)
	local F, L = Vector(math.cos(yaw), math.sin(yaw), 0), Vector(-math.sin(yaw), math.cos(yaw), 0)
	local function In(v) local d = v - o return d:Dot(F), d:Dot(L), d.z end
	Log(string.format("probe body: %s | model %s | eye %.1f above the feet, eye angles %s", tostring(t.name), tostring(ent:GetModel()), ent:EyePos().z - o.z, tostring(ent:EyeAngles())))
	local pos = {}
	for _, name in ipairs({ "Pelvis", "Spine2", "Spine4", "Neck1", "Head1", "L_Clavicle", "L_UpperArm", "L_Forearm", "L_Hand", "R_Clavicle", "R_UpperArm", "R_Forearm", "R_Hand" }) do
		local b = ent:LookupBone(BP .. name)
		local m = b and ent:GetBoneMatrix(b)
		if m then
			local f, l, u = In(m:GetTranslation())
			pos[name] = m:GetTranslation()
			Log(string.format("   %-11s fwd %6.2f left %6.2f up %6.2f | bone length %.2f", name, f, l, u, ent:BoneLength(b) or -1))
		else
			Log("   " .. name .. ": no bone")
		end
	end
	for _, s in ipairs({ "L", "R" }) do
		local a, b, c = pos[s .. "_UpperArm"], pos[s .. "_Forearm"], pos[s .. "_Hand"]
		if a and b and c then
			Log(string.format("   %s arm: shoulder to elbow %.2f, elbow to wrist %.2f, shoulder to wrist now %.2f", s, a:Distance(b), b:Distance(c), a:Distance(c)))
			-- the hand bone's own axes against the forearm and the body
			local hm = ent:GetBoneMatrix(ent:LookupBone(BP .. s .. "_Hand"))
			local fore = (c - b):GetNormalized()
			local hf, hr, hu = hm:GetForward(), hm:GetRight(), hm:GetUp()
			Log(string.format("   %s hand axes: forward . forearm %.2f | forward (%.2f %.2f %.2f) right (%.2f %.2f %.2f) up (%.2f %.2f %.2f) in the body's frame",
				s, hf:Dot(fore), hf:Dot(F), hf:Dot(L), hf.z, hr:Dot(F), hr:Dot(L), hr.z, hu:Dot(F), hu:Dot(L), hu.z))
		end
	end
	local eyes = ent:LookupAttachment("eyes")
	local att = eyes and eyes > 0 and ent:GetAttachment(eyes)
	if att then local f, l, u = In(att.Pos) Log(string.format("   eyes attachment fwd %.2f left %.2f up %.2f", f, l, u)) end
end

local function ProbeModel(t)
	Log("probe model: " .. tostring(t.name))
	local function Bounds(path, label)
		if not path or path == "" then Log("   " .. label .. ": no model named") return nil end
		Log(string.format("   %s %s: file there %s, valid %s", label, path, tostring(file.Exists(path, "GAME")), tostring(util.IsValidModel(path))))
		util.PrecacheModel(path)
		local m = ClientsideModel(path)
		if not IsValid(m) then Log("   " .. label .. ": could not be made") return nil end
		m:SetNoDraw(true)
		m:SetPos(vector_origin)
		m:SetAngles(angle_zero)
		m:SetupBones()
		local mins, maxs = m:GetModelBounds()
		Log(string.format("   %s %s: bounds %s .. %s | %d bones | %d sequences", label, path, tostring(mins), tostring(maxs), m:GetBoneCount(), m:GetSequenceCount() or -1))
		for i = 0, math.min(m:GetBoneCount() - 1, 3) do Log("      bone " .. i .. " " .. tostring(m:GetBoneName(i))) end
		for _, a in ipairs(m:GetAttachments() or {}) do Log("      attachment " .. a.id .. " " .. a.name) end
		return m
	end
	local prop = Bounds(t.prop, "prop")
	if IsValid(prop) then prop:Remove() end
	if t.exchange and t.exchange ~= t.prop then
		local e = Bounds(t.exchange, "exchange")
		if IsValid(e) then e:Remove() end
	end
	local real = Bounds(t.real, "animated")
	if not IsValid(real) then return end
	local seq = real:LookupSequence(t.idle or "Idle")
	real:ResetSequence(seq or 0)
	real:SetCycle(0)
	real:InvalidateBoneCache()
	real:SetupBones()
	Log(string.format("   idle sequence %s = %s", tostring(t.idle), tostring(seq)))
	local base = tonumber(t.basebone) or 1
	local bm = real:GetBoneMatrix(base)
	if not bm then Log("   no base bone " .. tostring(base)) real:Remove() return end
	Log(string.format("   base bone %d is %s at %s %s", base, tostring(real:GetBoneName(base)), tostring(bm:GetTranslation()), tostring(bm:GetAngles())))
	-- where Z-City puts the drawn prop: weaponPos / weaponAng on the base bone
	local pp, pa = LocalToWorld(t.weaponPos or vector_origin, t.weaponAng or angle_zero, bm:GetTranslation(), bm:GetAngles())
	Log(string.format("   the prop is drawn at %s %s (in the animated model's space)", tostring(pp), tostring(pa)))
	for _, s in ipairs({ "R", "L" }) do
		local hb = real:LookupBone(BP .. s .. "_Hand")
		local hm = hb and real:GetBoneMatrix(hb)
		if hm then
			local lp, la = WorldToLocal(hm:GetTranslation(), hm:GetAngles(), pp, pa)
			Log(string.format("   %s hand in the prop's space: at %s, angles %s", s, tostring(lp), tostring(la)))
			-- the middle of the grip: between the hand bone and the first joint of the middle finger
			local fb = real:LookupBone(BP .. s .. "_Finger2")
			local fm = fb and real:GetBoneMatrix(fb)
			if fm then
				local fp = WorldToLocal(fm:GetTranslation(), angle_zero, pp, pa)
				Log(string.format("      its middle finger's root in the prop's space: %s", tostring(fp)))
			end
		else
			Log("   no " .. s .. " hand bone in the animated model")
		end
	end
	real:Remove()
end

function H.fhprobe(t)
	if t.what == "body" then ProbeBody(t) else ProbeModel(t) end
	Reply(t.tag, { ok = true })
end

------------------------------------------------------------------------------------------
-- fhmeasure: what was drawn for a fighter and what its bones did.
------------------------------------------------------------------------------------------
function H.fhmeasure(t)
	if t.on ~= nil then R.measure = t.on and true or nil return end
	local ply = Entity(t.ent or -1)
	local out = { h = {} }
	if not IsValid(ply) then Reply(t.tag, out) return end
	local rs = FH.RenderHands(ply)
	local rec = R.last[ply]
	if not rs or not rec or not rec.meas then
		local r = cl.remote[ply:EntIndex()]
		local wep = ply:GetActiveWeapon()
		local stored = IsValid(wep) and weapons.GetStored(wep:GetClass()) or {}
		Log(string.format("measure %s: nothing to measure | applies %s | weapon %s fists %s | snapshots %s active %s | drawn record %s measured %s | transmit %s not seen %s | hook %s | patched classes %s, stored patched %s, this weapon has it %s, has a SetHandPos %s, calls %s, render override %s, rs %s",
			tostring(ply), tostring(FH.Applies(ply) ~= nil), tostring(IsValid(wep) and wep:GetClass()), tostring(IsValid(wep) and wep.GetFists and wep:GetFists()),
			tostring(r ~= nil), tostring(r and r.active), tostring(rec ~= nil), tostring(rec and rec.meas ~= nil), tostring(ply.shouldTransmit), tostring(ply.NotSeen),
			tostring(hg and hg.DoTPIK == R.wrapIK), tostring(FH.Patch.count), tostring(stored.FH_is_SetHandPos), tostring(IsValid(wep) and wep.SetHandPos == stored.SetHandPos),
			tostring(IsValid(wep) and wep.SetHandPos ~= nil), tostring(R.calls), tostring(ply.RenderOverride ~= nil), tostring(rs ~= nil)))
		Reply(t.tag, {})
		return
	end
	local o = ply:GetPos()
	local bd = C.Body
	local yaw = math.rad(rs.yaw)
	local ax, ay = o.x + math.cos(yaw) * bd.trunkFwd, o.y + math.sin(yaw) * bd.trunkFwd
	out.yawDrawn, out.yawEye = rs.yaw, ply:EyeAngles().y
	local bones = R.Bones(ply)
	for i = 1, 2 do
		local m = rec.meas[i]
		local d = rs.h[i]
		local e = {}
		e.dx, e.dy, e.dz = d.x - o.x, d.y - o.y, d.z - o.z
		if m and m.h then
			e.bx, e.by, e.bz = m.h.x - o.x, m.h.y - o.y, m.h.z - o.z
			e.px, e.py, e.pz = m.palm.x - o.x, m.palm.y - o.y, m.palm.z - o.z
			e.grip = d.grip
			e.upper, e.fore = m.s:Distance(m.e), m.e:Distance(m.h)
			e.bone = ply:BoneLength(bones[i].fore) or 12
			e.clamp = rec.short and rec.short[i] or 0
			e.age = FrameNumber() - (m.frame or 0)
			-- the elbow against the trunk
			local dist = math.sqrt((m.e.x - ax) ^ 2 + (m.e.y - ay) ^ 2)
			e.elbowDist = dist
			local z = m.e.z - o.z
			e.elbowIn = (z > bd.trunkLow and z < bd.trunkHigh) and math.max(bd.trunkR - dist, 0) or 0
		end
		out.h[i] = e
	end
	out.source = rs.source
	-- a tool: where the prop was drawn (its butt and its tip, from the model's own frame)
	-- against where the weapon is
	local wep = ply:GetActiveWeapon()
	if rs.tool and IsValid(wep) and IsValid(wep.FH_prop) then
		local prof, prop = rs.prof, wep.FH_prop
		local fr = R.ModelFrame(prof.model.path)
		local sc = prof.u.length / fr.len
		local butt = LocalToWorld(fr.o * sc, angle_zero, prop:GetPos(), prop:GetAngles())
		local tip = LocalToWorld((fr.o + fr.x * fr.len) * sc, angle_zero, prop:GetPos(), prop:GetAngles())
		local w = rs.w
		local ax, ay, az = M.QRot(w.qw, w.qx, w.qy, w.qz, 1, 0, 0)
		local u = prof.u
		local sb = Vector(w.x - ax * u.com, w.y - ay * u.com, w.z - az * u.com)
		local stp = sb + Vector(ax, ay, az) * u.length
		out.prop = { butt = butt:Distance(sb), tip = tip:Distance(stp), age = FrameNumber() - (wep.FH_drawn or 0),
			bx = sb.x - o.x, by = sb.y - o.y, bz = sb.z - o.z, tx = stp.x - o.x, ty = stp.y - o.y, tz = stp.z - o.z }
	end
	Reply(t.tag, out)
end

------------------------------------------------------------------------------------------
-- fhbody: where the local player's own arms and chest are from the eye the picture is taken
-- with: how far (units), how many degrees right of and above the middle of the picture, and
-- whether inside it. (fhmeasure must be on: the arms are the bones as they were last placed.)
------------------------------------------------------------------------------------------
-- (the view the picture is drawn with: taken while it is drawn. Asked for at another moment
-- the engine gives whatever it drew last, which need not be the screen.)
local seenView
hook.Add("PostDrawTranslucentRenderables", "FH_TestView", function(depth, sky)
	if not R.measure or depth or sky or render.GetRenderTarget() ~= nil then return end
	seenView = { origin = EyePos(), angles = EyeAngles(), fov = render.GetViewSetup().fov }
end)

-- fhturn: where the local player's own body is when the view has been turned on the spot: the
-- yaw the model is drawn with against the eye's, and the eye of the picture, the head and the
-- upper arms' joints about the feet, in the frame of the eye's yaw (forward, left, up).
function H.fhturn(t)
	local lp = LocalPlayer()
	local o = lp:GetPos()
	local yaw = lp:EyeAngles().y
	local a = Angle(0, yaw, 0)
	local fw, lf = a:Forward(), -a:Right()
	local function Rel(p)
		local d = p - o
		return { d:Dot(fw), d:Dot(lf), d.z }
	end
	local out = { eyeYaw = yaw, renderYaw = lp:GetRenderAngles().y, aim = lp:GetPoseParameter("aim_yaw"), view = seenView and Rel(seenView.origin) }
	local id = lp:LookupAttachment("eyes")
	local att = id and id > 0 and lp:GetAttachment(id)
	if att then out.eyes = Rel(att.Pos) end
	for k, name in pairs({ ls = "ValveBiped.Bip01_L_UpperArm", rs = "ValveBiped.Bip01_R_UpperArm", head = "ValveBiped.Bip01_Head1", pelvis = "ValveBiped.Bip01_Pelvis" }) do
		local b = lp:LookupBone(name)
		local m = b and lp:GetBoneMatrix(b)
		if m then out[k] = Rel(m:GetTranslation()) end
	end
	local rec = R.last[lp]
	if rec and rec.short then out.short = { rec.short[1] or 0, rec.short[2] or 0 } end
	Reply(t.tag, out)
end

-- fhcam: the view's turn after a held hand, frame by frame. on: begin to write down; get: what
-- was written down since (how far the view was turned at the most and at the end, the largest
-- change in one frame, how far past what was asked it ever went, whether the eye itself moved).
function H.fhcam(t)
	local cam = FH.Cam
	if t.on then cam.rec = {} return end
	local rec = cam.rec or {}
	cam.rec = nil
	local out = { n = #rec, yawMax = 0, yawMin = 0, pitchMax = 0, pitchMin = 0, step = 0, rate = 0, over = 0, eyeMoved = 0, turns = 0, heldYaw = 0, heldWant = 0 }
	local lastDir
	for k, e in ipairs(rec) do
		out.yawMax, out.yawMin = math.max(out.yawMax, e[2]), math.min(out.yawMin, e[2])
		out.pitchMax, out.pitchMin = math.max(out.pitchMax, e[3]), math.min(out.pitchMin, e[3])
		local p = rec[k - 1]
		if p then
			out.step = math.max(out.step, math.abs(e[2] - p[2]), math.abs(e[3] - p[3]))
			-- (degrees a second: a frame may be long)
			local dt = math.max(e[1] - p[1], 0.004)
			out.rate = math.max(out.rate, math.abs(e[2] - p[2]) / dt, math.abs(e[3] - p[3]) / dt)
			out.eyeMoved = math.max(out.eyeMoved, math.abs(math.AngleDifference(e[6], rec[1][6])), math.abs(math.AngleDifference(e[7], rec[1][7])))
			-- (how often the view's sideways turn changed its direction: a view that swings to and fro)
			local d = e[2] - p[2]
			if math.abs(d) > 0.02 then
				local dir = d > 0 and 1 or -1
				if lastDir and dir ~= lastDir then out.turns = out.turns + 1 end
				lastDir = dir
			end
		end
		-- (as it was in the last frame in which a hand was held)
		if e[10] == 1 then out.heldYaw, out.heldPitch, out.heldWant, out.heldWantP, out.heldAz, out.heldEl = e[2], e[3], e[4], e[5], e[8], e[9] end
		-- (past what was asked of it: on the far side of zero from where it came, or beyond the asking)
		if e[4] >= 0 and e[2] > e[4] + 0.001 and p and e[2] > p[2] then out.over = math.max(out.over, e[2] - e[4]) end
		if e[4] <= 0 and e[2] < e[4] - 0.001 and p and e[2] < p[2] then out.over = math.max(out.over, e[4] - e[2]) end
	end
	local last = rec[#rec]
	if last then
		out.yaw, out.pitch, out.wantYaw, out.wantPitch, out.az, out.el = last[2], last[3], last[4], last[5], last[8], last[9]
		out.secs = last[1] - rec[1][1]
	end
	Reply(t.tag, out)
end

-- fhmotion: the local player's own arms while they move, frame by frame as they are drawn.
-- interp: which way of drawing between two ticks (cl_state.lua); on: begin to write down;
-- get: what was written down since. Per arm: how far the hand bone, the elbow and the upper
-- arm's joint went in all; how evenly the drawn hand went (its speed from frame to frame: the
-- mean, and the spread as a share of the mean); how far the hand bone was from the simulated
-- hand, and a held handle from the palm, at the most.
local motion
hook.Add("PostDrawTranslucentRenderables", "FH_TestMotion", function(depth, sky)
	if not motion or depth or sky or render.GetRenderTarget() ~= nil then return end
	local lp = LocalPlayer()
	local rs = FH.RenderHands(lp)
	local rec = R.last[lp]
	if not rs or not rec or not rec.meas then return end
	local o = lp:GetPos()
	local e = { t = RealTime(), k = cl.lastK or -1, raw = cl.rawClock or 0, tool = rs.tool }
	for i = 1, 2 do
		local m = rec.meas[i]
		if m and m.h then
			e[i] = { d = Vector(rs.h[i].x, rs.h[i].y, rs.h[i].z) - o, h = m.h - o, e = m.e - o, s = m.s - o, palm = m.palm - o, grip = (i == 2) or rs.h[i].grip == true }
		end
	end
	motion[#motion + 1] = e
end)
function H.fhmotion(t)
	if t.interp ~= nil then cl.interp = t.interp cl.clockBase = nil end
	if t.on then motion = {} return end
	if not t.get then return end
	local rec = motion or {}
	motion = nil
	local out = { n = #rec, arm = { {}, {} } }
	if #rec > 2 then
		out.secs = rec[#rec].t - rec[1].t
		out.fps = (#rec - 1) / math.max(out.secs, 0.001)
		local kMin, kMax, rawMin, rawMax = 9, -9, 1e9, -1e9
		for _, e in ipairs(rec) do
			kMin, kMax, rawMin, rawMax = math.min(kMin, e.k), math.max(kMax, e.k), math.min(rawMin, e.raw), math.max(rawMax, e.raw)
		end
		out.kMin, out.kMax, out.rawMin, out.rawMax = kMin, kMax, rawMin, rawMax
		for i = 1, 2 do
			local a = out.arm[i]
			a.hand, a.elbow, a.joint, a.off, a.gap = 0, 0, 0, 0, 0
			local sum, sum2, n = 0, 0, 0
			for k = 2, #rec do
				local p, c = rec[k - 1][i], rec[k][i]
				if p and c then
					a.hand, a.elbow, a.joint = a.hand + c.h:Distance(p.h), a.elbow + c.e:Distance(p.e), a.joint + c.s:Distance(p.s)
					a.off = math.max(a.off, c.h:Distance(c.d))
					if rec[k].tool and c.grip then a.gap = math.max(a.gap, c.palm:Distance(c.d)) end
					local dt = math.max(rec[k].t - rec[k - 1].t, 0.001)
					local v = c.d:Distance(p.d) / dt
					sum, sum2, n = sum + v, sum2 + v * v, n + 1
				end
			end
			if n > 1 then
				a.speed = sum / n
				a.spread = math.sqrt(math.max(sum2 / n - a.speed * a.speed, 0)) / math.max(a.speed, 0.001)
			end
		end
	end
	Reply(t.tag, out)
end

-- fhprefs: the settings of whoever sits at the machine, for a scene that is about settings.
-- set: values by name, put in for the scene (what was there is kept); restore: put back.
local keptPrefs = {}
function H.fhprefs(t)
	if t.set then
		FH.testPrefs = true
		for name, v in pairs(t.set) do
			local cv = GetConVar(name)
			if cv then
				if keptPrefs[name] == nil then keptPrefs[name] = cv:GetString() end
				RunConsoleCommand(name, tostring(v))
			end
		end
	end
	if t.restore then
		for name, v in pairs(keptPrefs) do RunConsoleCommand(name, v) end
		keptPrefs = {}
		FH.testPrefs = nil
	end
end

-- fhlook: the eye (what the command says) and the picture (the view as Z-City and this module
-- leave it), frame by frame, in named stretches. seg: a stretch begins; nowrap: the mouse is
-- taken as it was until phase 42 (cl_input.lua); get: for each stretch, how far the eye and
-- the picture turned, the most either way, the picture's roll, and its largest steps in a frame.
local lookRec, lookSeg
hook.Add("PostDrawTranslucentRenderables", "FH_TestLook", function(depth, sky)
	if not lookRec or depth or sky or render.GetRenderTarget() ~= nil then return end
	local v = FH.Cam.watch
	if not v or v.frame ~= FrameNumber() then return end
	lookRec[#lookRec + 1] = { seg = lookSeg, ey = cl.cmdYaw or 0, ep = cl.cmdPitch or 0, vy = v.y, vp = v.p, vr = v.r }
end)
function H.fhlook(t)
	if t.nowrap ~= nil then cl.noWrap = t.nowrap and true or nil end
	if t.seg then
		lookRec = lookRec or {}
		lookSeg = t.seg
		FH.Cam.watch = FH.Cam.watch or {}
	end
	if not t.get then return end
	local AD, out = math.AngleDifference, {}
	for _, e in ipairs(lookRec or {}) do
		local s = out[e.seg]
		if not s then
			s = { n = 0, ey0 = e.ey, ep0 = e.ep, vy0 = e.vy, vp0 = e.vp, vr0 = e.vr, lastVy = e.vy,
				eyMin = 0, eyMax = 0, epMin = 0, epMax = 0, vyMin = 0, vyMax = 0, vpMin = 0, vpMax = 0, vrMin = 0, vrMax = 0, stepMin = 0, stepMax = 0 }
			out[e.seg] = s
		end
		s.n = s.n + 1
		local dey, dep, dvy, dvp, dvr = AD(e.ey, s.ey0), AD(e.ep, s.ep0), AD(e.vy, s.vy0), AD(e.vp, s.vp0), AD(e.vr, s.vr0)
		s.eyMin, s.eyMax, s.epMin, s.epMax = math.min(s.eyMin, dey), math.max(s.eyMax, dey), math.min(s.epMin, dep), math.max(s.epMax, dep)
		s.vyMin, s.vyMax, s.vpMin, s.vpMax = math.min(s.vyMin, dvy), math.max(s.vyMax, dvy), math.min(s.vpMin, dvp), math.max(s.vpMax, dvp)
		s.vrMin, s.vrMax = math.min(s.vrMin, dvr), math.max(s.vrMax, dvr)
		local step = AD(e.vy, s.lastVy)
		s.stepMin, s.stepMax, s.lastVy = math.min(s.stepMin, step), math.max(s.stepMax, step), e.vy
		s.eyEnd, s.vyEnd = dey, dvy
	end
	lookRec = nil
	FH.Cam.watch = nil
	cl.noWrap = nil
	Reply(t.tag, out)
end

-- fhmenu: the panel, the printed help and the hint, for a scene's picture. Says whether each
-- of them came about.
function H.fhmenu(t)
	if t.hint ~= nil then
		FH.testHint = t.hint and true or nil
		if t.hint then FH.Hint.Again() end
		return
	end
	if t.open then
		RunConsoleCommand("fh_help")
		RunConsoleCommand("fh_menu")
		return
	end
	if t.close then RunConsoleCommand("fh_menu") return end
	if t.shot then
		-- (the harness's own pictures are taken before the panels are painted)
		hook.Add("PostRenderVGUI", "FH_TestShot", function()
			hook.Remove("PostRenderVGUI", "FH_TestShot")
			local data = render.Capture({ format = "jpeg", quality = 90, x = 0, y = 0, w = ScrW(), h = ScrH() })
			if data then file.Write("abl_test/" .. t.shot .. ".jpg", data) end
		end)
		return
	end
	local n = 0
	for _, p in ipairs(vgui.GetWorldPanel():GetChildren()) do
		if p:GetClassName() == "LuaEditablePanel" and p.GetTitle and string.find(p:GetTitle() or "", "FreeHand", 1, true) then n = n + 1 end
	end
	local _, prefs = FH.Controls()
	Reply(t.tag, { panels = n, hints = FH.Hint.shows, right = FH.KeyName(prefs.right), left = FH.KeyName(prefs.left) })
end

function H.fhbody(t)
	local lp = LocalPlayer()
	local out = { pts = {} }
	local vs = seenView or render.GetViewSetup()
	local eye, ang = vs.origin, vs.angles
	local f, r, u = ang:Forward(), ang:Right(), ang:Up()
	out.fov, out.pitch, out.eyeUp = vs.fov, ang.p, eye.z - lp:GetPos().z
	-- (which way the picture looks against which way the eye does, and where the hands are
	-- that are drawn, about the feet in the eye's frame)
	out.viewYaw, out.eyeYaw, out.drawnYaw = ang.y, lp:EyeAngles().y, lp:GetRenderAngles().y
	local rs = FH.RenderHands(lp)
	if rs then
		local o, a = lp:GetPos(), Angle(0, lp:EyeAngles().y, 0)
		local fw, lf = a:Forward(), -a:Right()
		out.drawn = {}
		for i = 1, 2 do
			local d = Vector(rs.h[i].x, rs.h[i].y, rs.h[i].z) - o
			out.drawn[i] = { d:Dot(fw), d:Dot(lf), d.z }
		end
		out.cam = { (eye - o):Dot(fw), (eye - o):Dot(lf), eye.z - o.z }
	end
	-- (the engine's angle is the picture's width at 4:3)
	local th = math.tan(math.rad(vs.fov) * 0.5)
	local tx, ty = th * (ScrW() / ScrH()) / (4 / 3), th * 0.75
	local function Put(k, p)
		if not p then return end
		local d = p - eye
		local x, y, z = d:Dot(f), d:Dot(r), d:Dot(u)
		out.pts[k] = { d = d:Length(), right = math.deg(math.atan2(y, x)), up = math.deg(math.atan2(z, x)),
			seen = x > 1 and math.abs(y / x) < tx and math.abs(z / x) < ty }
	end
	local rec = R.last[lp]
	if rec and rec.meas then
		local names = { "l", "r" }
		for i = 1, 2 do
			local m = rec.meas[i]
			if m and m.h then Put(names[i] .. "h", m.h) Put(names[i] .. "e", m.e) Put(names[i] .. "s", m.s) end
		end
	end
	for k, name in pairs({ chest = "ValveBiped.Bip01_Spine2", lf = "ValveBiped.Bip01_L_Foot", rf = "ValveBiped.Bip01_R_Foot" }) do
		local bone = lp:LookupBone(name)
		local mat = bone and lp:GetBoneMatrix(bone)
		if mat then Put(k, mat:GetTranslation()) end
	end
	Reply(t.tag, out)
end

------------------------------------------------------------------------------------------
-- fhperf: what drawing the fighters costs. on: start counting; get: what was counted since.
------------------------------------------------------------------------------------------
local perfFrames, perfT0 = 0, 0
hook.Add("Think", "FH_TestPerfFrames", function() if FH.PerfCl then perfFrames = perfFrames + 1 end end)
function H.fhperf(t)
	if t.on then
		FH.PerfCl = { hands = 0, handsN = 0, prop = 0, propN = 0, sh = 0, shN = 0 }
		perfFrames, perfT0 = 0, SysTime()
		return
	end
	local p = FH.PerfCl
	FH.PerfCl = nil
	if not p then Reply(t.tag, {}) return end
	local secs = SysTime() - perfT0
	Reply(t.tag, { frames = perfFrames, secs = secs, hands = p.hands, handsN = p.handsN, prop = p.prop, propN = p.propN, sh = p.sh, shN = p.shN })
end

------------------------------------------------------------------------------------------
-- fhfix: the corrections the server's word has made to the local player's prediction (how many),
-- and a switch to leave them out.
------------------------------------------------------------------------------------------
function H.fhfix(t)
	if t.off ~= nil then cl.noFix = t.off and true or nil end
	if t.get then Reply(t.tag, { fixes = cl.fixes or 0 }) end
end

------------------------------------------------------------------------------------------
-- fhframe: where each tool's handle lies in its model (R.ModelFrame), for the log.
------------------------------------------------------------------------------------------
function H.fhframe(t)
	for class, prof in SortedPairs(C.Weapons) do
		if prof.kind == "tool" and (not t.class or t.class == class) then
			local fr = R.ModelFrame(prof.model.path)
			Log(string.format("frame %s %s: %s | handle along (%.2f %.2f %.2f), blade or hook toward (%.2f %.2f %.2f) | butt at (%.2f %.2f %.2f) | %.2f units = %.1f cm long (the profile says %.1f) | %s",
				class, prof.model.path, fr.guess and "FROM THE BOX" or (fr.tris .. " triangles"), fr.x.x, fr.x.y, fr.x.z, fr.y.x, fr.y.y, fr.y.z, fr.o.x, fr.o.y, fr.o.z,
				fr.len, fr.len * FH.U2M * 100, prof.length * 100, tostring(R.ClosedHands() ~= nil and "closed hands there" or "NO CLOSED HANDS")))
		end
	end
	Reply(t.tag, { ok = true })
end

------------------------------------------------------------------------------------------
-- fhinput: plays buttons and mouse into the local player's commands, as if they had been made.
--   moves: { L, R, depth, grip, mx, my, n } ...; record: keep what the client stepped;
--   report: send it back.
------------------------------------------------------------------------------------------
local recorded = {}
-- (the whole state after each recorded step, kept here and sent for single commands when a
-- scene asks in what the two sides differ)
local dumps = {}
function H.fhinput(t)
	if t.report then
		Reply(t.tag, { list = recorded })
		return
	end
	if t.dump then
		local out = { fixes = cl.fixes }
		for _, n in ipairs(t.dump) do out[tostring(n)] = dumps[n] end
		Reply(t.tag, out)
		return
	end
	if not t.moves then
		cl.testInput, cl.onStep, cl.onDump = nil, nil, nil
		return
	end
	local moves = t.moves
	local i, left = 1, moves[1] and moves[1].n or 0
	cl.testInput = function()
		while i <= #moves and left <= 0 do
			i = i + 1
			left = moves[i] and moves[i].n or 0
		end
		local m = moves[i]
		if not m then return nil end
		left = left - 1
		return m
	end
	if t.record then
		recorded = {}
		dumps = {}
		local kept = 0
		cl.onDump = function(st, n, inp)
			if kept < 400 then
				kept = kept + 1
				dumps[n] = FH.Sim.Dump(st, inp)
				dumps[n].fixes = cl.fixes
			end
		end
		cl.onStep = function(st, n)
			local a, b = st.h[1], st.h[2]
			if #recorded < 400 then
				local e = { n, a.px - st.bx, a.py - st.by, a.pz - st.bz, b.px - st.bx, b.py - st.by, b.pz - st.bz }
				local w = st.w
				if w then e[8], e[9], e[10], e[11], e[12], e[13], e[14] = w.x - st.bx, w.y - st.by, w.z - st.bz, w.qw, w.qx, w.qy, w.qz end
				recorded[#recorded + 1] = e
			end
		end
	end
end
