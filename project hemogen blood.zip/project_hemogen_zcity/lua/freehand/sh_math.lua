-- Vector and quaternion arithmetic on plain numbers.
-- The simulation is stepped on the client and on the server from the same commands and has to
-- come out the same on both; it also runs several times a tick for every fighter. So it works on
-- numbers, makes no engine call and no table inside its loops. A quaternion is (w, x, y, z).

FreeHand.SameOnBothSides()
local FH = FreeHand
FH.Math = FH.Math or {}
local M = FH.Math
local sqrt, sin, cos, acos, abs, min, max = math.sqrt, math.sin, math.cos, math.acos, math.abs, math.min, math.max

function M.Cross(ax, ay, az, bx, by, bz)
	return ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx
end

function M.Norm(x, y, z)
	local l = sqrt(x * x + y * y + z * z)
	if l < 1e-9 then return 0, 0, 0, 0 end
	return x / l, y / l, z / l, l
end

function M.Clamp(v, lo, hi) return v < lo and lo or (v > hi and hi or v) end

-- A vector no longer than `limit`.
function M.Limit(x, y, z, limit)
	local l2 = x * x + y * y + z * z
	if l2 <= limit * limit then return x, y, z end
	local k = limit / sqrt(l2)
	return x * k, y * k, z * k
end

function M.QMul(aw, ax, ay, az, bw, bx, by, bz)
	return aw * bw - ax * bx - ay * by - az * bz,
		aw * bx + ax * bw + ay * bz - az * by,
		aw * by - ax * bz + ay * bw + az * bx,
		aw * bz + ax * by - ay * bx + az * bw
end

function M.QNorm(w, x, y, z)
	local l = sqrt(w * w + x * x + y * y + z * z)
	if l < 1e-12 then return 1, 0, 0, 0 end
	return w / l, x / l, y / l, z / l
end

-- v turned by q
function M.QRot(w, x, y, z, vx, vy, vz)
	-- t = 2 q_v x v;  v' = v + w t + q_v x t
	local tx, ty, tz = 2 * (y * vz - z * vy), 2 * (z * vx - x * vz), 2 * (x * vy - y * vx)
	return vx + w * tx + (y * tz - z * ty), vy + w * ty + (z * tx - x * tz), vz + w * tz + (x * ty - y * tx)
end

-- v turned by the inverse of q
function M.QRotInv(w, x, y, z, vx, vy, vz)
	return M.QRot(w, -x, -y, -z, vx, vy, vz)
end

-- q after turning with the angular velocity (wx, wy, wz) (world) for dt
function M.QStep(w, x, y, z, wx, wy, wz, dt)
	local a = sqrt(wx * wx + wy * wy + wz * wz) * dt
	if a < 1e-9 then return w, x, y, z end
	local s = sin(a * 0.5) / (a / dt)
	local dw, dx, dy, dz = cos(a * 0.5), wx * s, wy * s, wz * s
	return M.QNorm(M.QMul(dw, dx, dy, dz, w, x, y, z))
end

-- The quaternion of a frame from its forward (x) and left (y) axes (unit, perpendicular).
function M.QFromAxes(fx, fy, fz, lx, ly, lz)
	local ux, uy, uz = M.Cross(fx, fy, fz, lx, ly, lz)
	-- rotation matrix with columns f, l, u
	local m00, m01, m02 = fx, lx, ux
	local m10, m11, m12 = fy, ly, uy
	local m20, m21, m22 = fz, lz, uz
	local tr = m00 + m11 + m22
	local w, x, y, z
	if tr > 0 then
		local s = sqrt(tr + 1) * 2
		w, x, y, z = 0.25 * s, (m21 - m12) / s, (m02 - m20) / s, (m10 - m01) / s
	elseif m00 > m11 and m00 > m22 then
		local s = sqrt(1 + m00 - m11 - m22) * 2
		w, x, y, z = (m21 - m12) / s, 0.25 * s, (m01 + m10) / s, (m02 + m20) / s
	elseif m11 > m22 then
		local s = sqrt(1 + m11 - m00 - m22) * 2
		w, x, y, z = (m02 - m20) / s, (m01 + m10) / s, 0.25 * s, (m12 + m21) / s
	else
		local s = sqrt(1 + m22 - m00 - m11) * 2
		w, x, y, z = (m10 - m01) / s, (m02 + m20) / s, (m12 + m21) / s, 0.25 * s
	end
	return M.QNorm(w, x, y, z)
end

-- The shortest turn that takes the unit vector a onto the unit vector b.
function M.QArc(ax, ay, az, bx, by, bz)
	local d = ax * bx + ay * by + az * bz
	if d > 0.999999 then return 1, 0, 0, 0 end
	if d < -0.999999 then
		-- half a turn about any axis across a
		local px, py, pz = M.Cross(ax, ay, az, 0, 0, 1)
		if px * px + py * py + pz * pz < 1e-6 then px, py, pz = M.Cross(ax, ay, az, 0, 1, 0) end
		px, py, pz = M.Norm(px, py, pz)
		return 0, px, py, pz
	end
	local cx, cy, cz = M.Cross(ax, ay, az, bx, by, bz)
	return M.QNorm(1 + d, cx, cy, cz)
end

-- The turn (axis times angle, radians) that takes direction a onto direction b.
function M.ArcVector(ax, ay, az, bx, by, bz)
	local cx, cy, cz = M.Cross(ax, ay, az, bx, by, bz)
	local s = sqrt(cx * cx + cy * cy + cz * cz)
	local d = ax * bx + ay * by + az * bz
	if s < 1e-7 then return 0, 0, 0 end
	local ang = math.atan2(s, d)
	local k = ang / s
	return cx * k, cy * k, cz * k
end

-- Where the nearest points of two segments are: P = a + s (b - a), Q = c + t (d - c).
-- Returns s, t and the square of their distance.
function M.SegSeg(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz)
	local ux, uy, uz = bx - ax, by - ay, bz - az
	local vx, vy, vz = dx - cx, dy - cy, dz - cz
	local wx, wy, wz = ax - cx, ay - cy, az - cz
	local a, b, c = ux * ux + uy * uy + uz * uz, ux * vx + uy * vy + uz * vz, vx * vx + vy * vy + vz * vz
	local d, e = ux * wx + uy * wy + uz * wz, vx * wx + vy * wy + vz * wz
	local den = a * c - b * b
	local s, t
	if a < 1e-12 and c < 1e-12 then s, t = 0, 0
	elseif a < 1e-12 then s, t = 0, M.Clamp(e / c, 0, 1)
	else
		if c < 1e-12 then t, s = 0, M.Clamp(-d / a, 0, 1)
		else
			s = den > 1e-12 and M.Clamp((b * e - c * d) / den, 0, 1) or 0
			t = (b * s + e) / c
			if t < 0 then t, s = 0, M.Clamp(-d / a, 0, 1)
			elseif t > 1 then t, s = 1, M.Clamp((b - d) / a, 0, 1) end
		end
	end
	local px, py, pz = wx + ux * s - vx * t, wy + uy * s - vy * t, wz + uz * s - vz * t
	return s, t, px * px + py * py + pz * pz
end

-- Engine types, for the edges of the simulation only.
function M.Vec(x, y, z) return Vector(x, y, z) end
-- An Angle from a frame's forward and up.
function M.Ang(fx, fy, fz, ux, uy, uz)
	return Vector(fx, fy, fz):AngleEx(Vector(ux, uy, uz))
end

-- A spring that does not overshoot (critically damped), stepped so that it is stable whatever
-- the step: x and its speed v after dt seconds on the way to target; omega (1/s) is how fast.
function M.Spring(x, v, target, omega, dt)
	local f = 1 + 2 * dt * omega
	local hoo = dt * omega * omega
	local hhoo = dt * hoo
	local k = 1 / (f + hhoo)
	return (f * x + dt * v + hhoo * target) * k, (v + hoo * (target - x)) * k
end
