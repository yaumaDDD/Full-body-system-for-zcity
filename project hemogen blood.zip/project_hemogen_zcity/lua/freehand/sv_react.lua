-- Server: what a blow does to who was struck, beyond the wound Z-City books for it.
--
-- A head that is struck is turned and thrown: how fast follows from the impulse, from the head's
-- mass and from how far beside its centre the blow went. That is what the view of the struck
-- player is kicked with, what everybody else sees the head do, and what counts toward a
-- knockout. Blows add up and fade: one may only daze, the next within a few seconds may fell.
-- A body that is struck is pushed, and pushed hard enough it goes down. Going down is Z-City's
-- own ragdoll, started with the force of the blow that caused it; being out is Z-City's own
-- unconsciousness. Nothing is decided by chance.

local FH = FreeHand
local C, M = FH.Config, FH.Math
FH.React = FH.React or {}
local Re = FH.React
local min, max = math.min, math.max

local vict = setmetatable({}, { __mode = "k" })
local function V(ply)
	local v = vict[ply]
	if not v then
		v = { daze = 0, dazeT = 0, bal = 0, balT = 0, weakUntil = 0, koUntil = 0 }
		vict[ply] = v
	end
	return v
end
Re.State = V

local function Faded(value, since, now, half)
	if value <= 0 then return 0 end
	return value * 0.5 ^ ((now - since) / half)
end

-- How dazed a player is now, and how unsteady (for tests and for other modules).
function Re.Daze(ply)
	local v = vict[ply]
	if not v then return 0, 0 end
	local now = CurTime()
	return Faded(v.daze, v.dazeT, now, C.React.dazeHalf), Faded(v.bal, v.balT, now, C.React.balHalf)
end

-- What a dazed player's arms have left (sv_main.lua multiplies the arm's force with it).
function Re.Weak(ply)
	local v = vict[ply]
	if v and v.weakUntil > CurTime() then return C.React.weak end
	return 1
end

------------------------------------------------------------------------------------------
-- What the hand feels of a blow it gave or stopped: to that player alone.
------------------------------------------------------------------------------------------
function Re.Jolt(ply, c)
	if not IsValid(ply) or not ply:IsPlayer() or ply:IsBot() then return end
	local k = min(c.impulse / C.React.joltFull, 1)
	if k < 0.08 then return end
	net.Start("fh_ev", true)
	net.WriteUInt(1, 3)
	net.WriteFloat(k)
	net.WriteVector(Vector(c.dx, c.dy, c.dz))
	net.Send(ply)
end

------------------------------------------------------------------------------------------
-- Going down
------------------------------------------------------------------------------------------
local function Standing(ply)
	return ply:IsPlayer() and ply:Alive() and not FH.Body.Ragdolled(ply)
end

local function Down(ply, seconds, hard)
	if not hg then return end
	if hard and hg.StunPlayer then
		hg.StunPlayer(ply, seconds)
	elseif hg.LightStunPlayer then
		hg.LightStunPlayer(ply, seconds)
	end
end

local function CapConsciousness(org, cap)
	local nt = NeuroTrauma
	if istable(nt) and istable(nt.ZC) and nt.ZC.CapConsciousness then return nt.ZC.CapConsciousness(org, cap) end
	local c = tonumber(org.consciousness)
	if c and c > cap then org.consciousness = cap end
	-- (see lua/neurotrauma/sv_zcity.lua: a check Z-City runs when a player goes out fails on a
	-- timer that is missing for players who carry an achievement's state from an earlier session)
	local owner = org.owner
	if cap < 0.1 and IsValid(owner) and owner:IsPlayer() and owner.illbeback == nil then owner.illbeback = 0 end
end

-- Out: Z-City's own unconsciousness, held for as long as the blow says (Z-City lets
-- consciousness come back by itself; while the knockout lasts it is kept under the line).
hook.Add("Think", "FH_Knockout", function()
	local now = CurTime()
	for ply, v in pairs(vict) do
		if v.koUntil > now and IsValid(ply) and ply:Alive() and istable(ply.organism) then
			CapConsciousness(ply.organism, 0.05)
		end
	end
end)

------------------------------------------------------------------------------------------
-- The head
------------------------------------------------------------------------------------------
local function HeadCentre(ent, target)
	if ent ~= target and ent:IsRagdoll() then
		local bone = ent:LookupBone("ValveBiped.Bip01_Head1")
		local pb = bone and ent:TranslateBoneToPhysBone(bone)
		local phys = pb and pb >= 0 and ent:GetPhysicsObjectNum(pb)
		if IsValid(phys) then return phys:GetPos() + phys:GetAngles():Forward() * 2.5 end
	end
	-- a standing player: the same middle the contact was worked out with
	local x, y, z = FH.Contact.HeadCentre(target)
	if x then return Vector(x, y, z) end
	return target:EyePos()
end

-- Before the damage is given (the damage may put the player into a ragdoll, and the head is
-- then somewhere else): how the head is moved by this blow. Kept for Re.Head.
-- (The neurotrauma module is not told. It works out how a head was struck from the damage
-- Z-City books, the place and the direction, on a scale of its own that its lines are set on;
-- the place and the direction it reads there are the real ones of this blow.)
function Re.BeforeHead(target, attacker, c)
	if not IsValid(target) then return end
	local r = C.React
	local v = V(target)
	local centre = HeadCentre(c.ent, target)
	local rx, ry, rz = (c.x - centre.x) * FH.U2M, (c.y - centre.y) * FH.U2M, (c.z - centre.z) * FH.U2M
	local lx, ly, lz = M.Cross(rx, ry, rz, c.dx, c.dy, c.dz)
	local lever = math.sqrt(lx * lx + ly * ly + lz * lz)
	local dv = min(c.impulse / C.Hit.mass.head, r.dvMax)
	local dOmega = min(c.impulse * lever / r.headInertia, r.omegaMax)
	v.dv, v.dOmega, v.lever = dv, dOmega, lever
	-- (the axis the head is turned about, for what is seen of it)
	local l = lever > 1e-5 and 1 / lever or 0
	v.ax, v.ay, v.az = lx * l, ly * l, lz * l
end

function Re.Head(target, attacker, c, prof)
	if not IsValid(target) then return end
	local r = C.React
	local v = V(target)
	local now = CurTime()
	local dv, dOmega = v.dv or 0, v.dOmega or 0
	local hardness = (c.kind == "bar" and prof.shaft) or prof.hardness or r.hardRef
	local hard = (hardness / r.hardRef) ^ 2
	local gate = M.Clamp((c.closing - r.sevFrom) / (r.sevFull - r.sevFrom), 0, 1)
	local sev = (dOmega / r.koOmega + dv / r.koDv) * hard * gate * C.cv.knockout:GetFloat()
	v.daze = Faded(v.daze, v.dazeT, now, r.dazeHalf) + sev
	v.dazeT = now
	v.lastSev = sev
	if FH.OnHead then FH.OnHead(target, attacker, c, sev, v.daze, dv, dOmega) end

	-- the view of who was struck goes the way the head goes
	if target:IsPlayer() and not target:IsBot() then
		local ang = target:EyeAngles()
		local f, rt, u = ang:Forward(), ang:Right(), ang:Up()
		local df, dr = c.dx * f.x + c.dy * f.y + c.dz * f.z, c.dx * rt.x + c.dy * rt.y + c.dz * rt.z
		local du = c.dx * u.x + c.dy * u.y + c.dz * u.z
		local a = min(sev * r.viewKick, r.viewKickMax)
		-- (struck from the front the head goes back and the view up; from one side, to the other)
		target:ViewPunch(Angle((df - du * 0.6) * a, -dr * a * 0.8, dr * a * 0.5))
	end
	-- everybody sees the head go
	net.Start("fh_ev", true)
	net.WriteUInt(2, 3)
	net.WriteUInt(target:EntIndex(), 8)
	net.WriteVector(Vector(c.dx, c.dy, c.dz))
	net.WriteFloat(min(sev, 2))
	net.SendPVS(target:GetPos())

	-- controlled, shaken, down, out
	if v.daze >= r.knockout then
		local t = min(r.outTime + (v.daze - r.knockout) * r.outPerDaze, r.outMax)
		v.koUntil = now + t
		v.weakUntil = now + t + r.weakTime
		if istable(target.organism) then CapConsciousness(target.organism, 0.05) end
		if Standing(target) then Down(target, t, true) end
		v.last = "out"
	elseif v.daze >= r.knockdown then
		v.weakUntil = now + r.weakTime * 2
		if Standing(target) then Down(target, r.downTime, false) end
		v.last = "down"
	elseif v.daze >= r.stagger then
		v.weakUntil = now + r.weakTime
		v.last = "shaken"
	else
		v.last = "held"
	end
	-- the body goes with the head a little
	Re.Push(target, c, 0.5)
end

------------------------------------------------------------------------------------------
-- The body
------------------------------------------------------------------------------------------
-- The whole body takes up the impulse (share: how much of it; a blow to the head mostly turns
-- the head).
function Re.Push(target, c, share)
	if not Standing(target) then return end
	local dv = c.impulse * share / C.Body.bodyMass * FH.M2U * C.React.pushGain
	if dv < 2 then return end
	dv = min(dv, C.React.pushMax)
	local z = c.dz
	if target:OnGround() and z < 0 then z = 0 end
	target:SetVelocity(Vector(c.dx * dv, c.dy * dv, z * dv * 0.5))
end

function Re.Body(target, attacker, c, part)
	if not IsValid(target) then return end
	local r = C.React
	local v = V(target)
	local now = CurTime()
	local leg = c.hitgroup == HITGROUP_LEFTLEG or c.hitgroup == HITGROUP_RIGHTLEG
	local k = part == "arm" and r.armFactor or (leg and r.legFactor or 1)
	v.bal = Faded(v.bal, v.balT, now, r.balHalf) + c.impulse / r.fallImpulse * k
	v.balT = now
	if FH.OnBody then FH.OnBody(target, attacker, c, v.bal) end
	Re.Push(target, c, 1)
	-- everybody sees the trunk give
	if part ~= "arm" and c.impulse > 2 then
		net.Start("fh_ev", true)
		net.WriteUInt(3, 3)
		net.WriteUInt(target:EntIndex(), 8)
		net.WriteVector(Vector(c.dx, c.dy, c.dz))
		net.WriteFloat(min(c.impulse, 40))
		net.SendPVS(target:GetPos())
	end
	if v.bal >= 1 and Standing(target) then
		v.bal = 0
		v.weakUntil = now + r.weakTime
		Down(target, r.downTime, false)
		v.last = "down"
	end
end

------------------------------------------------------------------------------------------
-- The fall
------------------------------------------------------------------------------------------
-- Whoever puts a struck player down (this module's count, Z-City's own rules for a wound, the
-- neurotrauma module), it is Z-City that makes the ragdoll, and it says so: hook "Fake". A body
-- that goes limp a moment after a blow still has what the blow did to it: the part that was
-- struck was thrown, what is joined to it less, and the far end of the body not at all. Given
-- to the ragdoll's parts that way, the body topples the way it was struck: over its feet for
-- a blow to the head, legs first for a blow to a leg, down for a blow from above.
-- (A rule of the game, not a measurement: the impulse of a punch on the whole of a body moves
-- it a hand's width. What is seen of a real knockdown is the body losing its footing while its
-- upper part is still going.)
function Re.Struck(target, c)
	if not IsValid(target) or not target:IsPlayer() then return end
	local v = V(target)
	v.blowT, v.blowImp = CurTime(), c.impulse
	v.bdx, v.bdy, v.bdz = c.dx, c.dy, c.dz
	v.blowZ = c.z
end

hook.Add("Fake", "FH_FallWithBlow", function(ply, rag)
	local v = vict[ply]
	if not v or not v.blowT or not IsValid(rag) then return end
	local r = C.React
	local age = CurTime() - v.blowT
	v.blowT = nil
	if age > r.fallWindow then return end
	local top = min(v.blowImp * r.fallPerNs, r.fallMax) * (1 - age / r.fallWindow)
	if top < 4 then return end
	local n = rag:GetPhysicsObjectCount()
	local low, high = math.huge, -math.huge
	for i = 0, n - 1 do
		local phys = rag:GetPhysicsObjectNum(i)
		if IsValid(phys) then
			local z = phys:GetPos().z
			low, high = min(low, z), max(high, z)
		end
	end
	if high <= low then return end
	local span = max(high - low, 20)
	local at = M.Clamp((v.blowZ - low) / span, 0, 1)
	local dir = Vector(v.bdx, v.bdy, v.bdz)
	for i = 0, n - 1 do
		local phys = rag:GetPhysicsObjectNum(i)
		if IsValid(phys) then
			local k = 1 - math.abs((phys:GetPos().z - low) / span - at) / r.fallReach
			if k > 0 then phys:AddVelocity(dir * (top * k)) end
		end
	end
	if FH.OnFall then FH.OnFall(ply, rag, top, age, dir) end
end)

hook.Add("PlayerSpawn", "FH_ReactReset", function(ply) vict[ply] = nil end)
