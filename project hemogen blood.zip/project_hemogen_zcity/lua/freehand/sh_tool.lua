-- A tool in the hands: the crowbar and the axes.
--
-- The weapon is a rigid body (sh_weapon.lua). A hand that holds it does not carry it anywhere: the
-- arm pulls on the handle at the place it grips, toward where the player wants that hand. Two
-- hands are two forces at two places: together they move the weapon, against each other they
-- turn it, and how fast depends on how far apart they hold and on where the weight of the weapon
-- sits. One hand is one force and what a wrist can add; a heavy head then goes its own way for a
-- while and comes round late. Nothing here knows what a swing is.
--
-- The arms' own weight rides on the handle at the grips, so the body that is stepped is the
-- weapon and those weights together (their centre, their inertia), and the weapon's own centre
-- is carried along.
--
-- Hands: the right one leads and is always on the handle; the left one holds the butt when it
-- holds at all, and the right hand slides up the handle to make room for it.

FreeHand.SameOnBothSides()
local FH = FreeHand
local C, M, B, W, S = FH.Config, FH.Math, FH.Body, FH.Weapon, FH.Sim
local sqrt, abs, min, max, atan2, sin, cos, rad = math.sqrt, math.abs, math.min, math.max, math.atan2, math.sin, math.cos, math.rad
local Clamp = M.Clamp
local R, L = 2, 1
S.RIGHT, S.LEFT = R, L

------------------------------------------------------------------------------------------
-- Guard: where the grips rest.
------------------------------------------------------------------------------------------
function S.ToolGuard(st, prof, i)
	local g, u = prof.guard, prof.u
	if st.twoHand then
		if i == L then return g.two[1], g.two[2], g.two[3] end
		local d = u.two - u.butt
		return g.two[1] + g.dir[1] * d, g.two[2] + g.dir[2] * d, g.two[3] + g.dir[3] * d
	end
	if i == R then return g.one[1], g.one[2], g.one[3] end
	-- (the free hand of a one-handed grip is a fist at its guard)
	local f = C.Guard.fists[L]
	return B.PolarTarget(L, f.azIn, f.el, f.ext * B.ArmLength())
end

-- The wrist of the hand that holds alone. Where it holds the handle when nothing pulls on it,
-- and the middle of what the joint allows (unit vectors, world). gx..: the grip.
local function WristRest(st, h, gx, gy, gz)
	local bd = C.Body
	local ex, ey, ez = B.Elbow(R, h.sx, h.sy, h.sz, gx, gy, gz, st.fx, st.fy, st.fz, st.lx, st.ly, st.lz, st.ux, st.uy, st.uz,
		bd.upperArm, bd.foreArm, st.tax, st.tay, st.tlow, st.thigh, st.tr)
	local px, py, pz = M.Norm(gx - ex, gy - ey, gz - ez)
	-- the thumb's side of a hand that holds a handle: up, and a little back
	local rx, ry, rz = st.ux * 0.95 - st.fx * 0.2, st.uy * 0.95 - st.fy * 0.2, st.uz * 0.95 - st.fz * 0.2
	local k = rx * px + ry * py + rz * pz
	local rl
	rx, ry, rz, rl = M.Norm(rx - px * k, ry - py * k, rz - pz * k)
	if rl < 1e-4 then rx, ry, rz = M.Norm(M.Cross(px, py, pz, st.lx, st.ly, st.lz)) end
	local a = C.Arm
	local c1, s1, c2, s2 = cos(rad(a.wristRest)), sin(rad(a.wristRest)), cos(rad(a.wristMid)), sin(rad(a.wristMid))
	return px * c1 + rx * s1, py * c1 + ry * s1, pz * c1 + rz * s1, px * c2 + rx * s2, py * c2 + ry * s2, pz * c2 + rz * s2
end
S.WristRest = WristRest

-- Lays the weapon in the hands at their targets, at rest with the body.
function S.ToolReset(st, prof)
	local u = prof.u
	local b = W.NewBody()
	st.w = b
	local hr, hl = st.h[R], st.h[L]
	local ax, ay, az
	if st.twoHand then
		b.slide, b.slideWant = u.two, u.two
		ax, ay, az = M.Norm(hr.wx - hl.wx, hr.wy - hl.wy, hr.wz - hl.wz)
	else
		b.slide, b.slideWant = u.one, u.two
		ax, ay, az = WristRest(st, hr, hr.wx, hr.wy, hr.wz)
	end
	-- the blade's side: forward as far as the handle allows
	local k = st.fx * ax + st.fy * ay + st.fz * az
	local ex, ey, ez, el = M.Norm(st.fx - ax * k, st.fy - ay * k, st.fz - az * k)
	if el < 1e-3 then ex, ey, ez = M.Norm(M.Cross(ax, ay, az, st.lx, st.ly, st.lz)) end
	b.qw, b.qx, b.qy, b.qz = M.QFromAxes(ax, ay, az, ex, ey, ez)
	local d = u.com - b.slide
	b.x, b.y, b.z = hr.wx + ax * d, hr.wy + ay * d, hr.wz + az * d
	b.vx, b.vy, b.vz = st.bvx, st.bvy, st.bvz
	b.wx, b.wy, b.wz = 0, 0, 0
	b.rdx, b.rdy, b.rdz = ax, ay, az
	b.px, b.py, b.pz, b.pqw, b.pqx, b.pqy, b.pqz = b.x, b.y, b.z, b.qw, b.qx, b.qy, b.qz
	hr.px, hr.py, hr.pz = hr.wx, hr.wy, hr.wz
	hr.grip = true
	hl.grip = st.twoHand
	if st.twoHand then
		local s = u.butt - b.slide
		hl.px, hl.py, hl.pz = hr.wx + ax * s, hr.wy + ay * s, hr.wz + az * s
	end
	for i = 1, 2 do
		local h = st.h[i]
		h.qx, h.qy, h.qz = h.px, h.py, h.pz
		h.vx, h.vy, h.vz = st.bvx, st.bvy, st.bvz
	end
end

------------------------------------------------------------------------------------------
-- Targets: which hand the mouse moves, and what the grip allows.
------------------------------------------------------------------------------------------
function S.ToolTargets(st, prof, inp, across, up, out, dt)
	local u = prof.u
	local a = C.Arm
	local b = st.w
	local hr, hl = st.h[R], st.h[L]
	-- the grip key puts the left hand on the handle or takes it off (a left arm that is gone is off)
	if (prof.canSwitch and inp.grip and not st.gripKeyWas and not inp.noL) or (inp.noL and st.twoHand) then
		st.twoHand = not st.twoHand
		if st.twoHand then
			b.slideWant = u.two
		else
			hl.grip = false
			hl.tf, hl.tl, hl.tu = S.ToolGuard(st, prof, L)
			b.rdx, b.rdy, b.rdz = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
		end
	end
	st.gripKeyWas = inp.grip
	if st.twoHand and hl.grip then
		if hr.on or hl.on then
			-- Two hands on one handle: the mouse steers the weapon, whichever arm is held.
			-- The grip is carried the way the mouse goes, as a hand is (over the sphere about the
			-- leading hand's shoulder), by a share. And the handle is turned: its direction is
			-- a point on the half of a ball that faces away from the player, and the mouse rolls
			-- that point right and left, up and down. So the head goes where the mouse goes in
			-- the picture, and through the front: brought down from upright it tips forward, and
			-- swept from one side to the other it passes pointing straight ahead. It cannot be
			-- turned to point back at its holder. Which arm is held says how much is carried and
			-- how fast it is turned (sh_config.lua, C.Arm.steer).
			local sv = (hr.on and hl.on) and a.steer.both or (hr.on and a.steer.lead or a.steer.butt)
			local ux, uy, uz = hr.tf - hl.tf, hr.tl - hl.tl, hr.tu - hl.tu
			local sep = sqrt(ux * ux + uy * uy + uz * uz)
			if sep < 1e-3 then
				ux, uy, uz, sep = prof.guard.dir[1], prof.guard.dir[2], prof.guard.dir[3], u.two - u.butt
			else
				ux, uy, uz = ux / sep, uy / sep, uz / sep
			end
			-- (the arm at the butt alone, with the depth key: the hands apart or together)
			local reach = out
			if hl.on and not hr.on and inp.depth then
				sep = Clamp(sep + out, u.twoMin - u.butt, u.twoMax - u.butt)
				reach = 0
			end
			local nf, nl, nu = B.MoveTarget(R, hr.tf, hr.tl, hr.tu, across, up, reach, nil, true)
			hr.tf, hr.tl, hr.tu = hr.tf + (nf - hr.tf) * sv[1], hr.tl + (nl - hr.tl) * sv[1], hr.tu + (nu - hr.tu) * sv[1]
			-- (to the right is the other way from "left" of the aim's frame)
			local wr, wu = -uy + rad(across) * sv[2], uz + rad(up) * sv[2]
			local w2 = wr * wr + wu * wu
			if w2 > 1 then
				local k = 1 / sqrt(w2)
				wr, wu, w2 = wr * k, wu * k, 1
			end
			local wf = sqrt(1 - w2)
			hl.tf, hl.tl, hl.tu = hr.tf - wf * sep, hr.tl + wr * sep, hr.tu - wu * sep
			-- (the hand at the butt is wanted in front of the body too: the grip is carried
			-- forward by what is missing, and the weapon keeps its direction)
			local miss = (a.front + 1.5) - hl.tf
			if miss > 0 then hl.tf, hr.tf = hl.tf + miss, hr.tf + miss end
			-- (nor far across to the right, its arm laid over the chest: the grip is carried to
			-- the left by what is too much, as a swing to the left takes both hands to that side)
			local over = -a.cross - 2 - hl.tl
			if over > 0 then hl.tl, hr.tl = hl.tl + over, hr.tl + over end
			-- (and the leading hand no further across to the left than an arm lies easily)
			over = hr.tl - (a.cross + 4)
			if over > 0 then hl.tl, hr.tl = hl.tl - over, hr.tl - over end
		end
		-- The two grips are on one handle: their targets are never further apart, or nearer, than
		-- the right hand can slide. The hand that is not being moved gives way (and when both or
		-- neither is, the left one does).
		local dx, dy, dz = hr.tf - hl.tf, hr.tl - hl.tl, hr.tu - hl.tu
		local d = sqrt(dx * dx + dy * dy + dz * dz)
		if d < 1e-3 then dx, dy, dz, d = prof.guard.dir[1], prof.guard.dir[2], prof.guard.dir[3], 1 end
		local want = Clamp(d, u.twoMin - u.butt, u.twoMax - u.butt)
		if want ~= d then
			local k = want / d
			if hl.on and not hr.on then
				hr.tf, hr.tl, hr.tu = hl.tf + dx * k, hl.tl + dy * k, hl.tu + dz * k
			else
				hl.tf, hl.tl, hl.tu = hr.tf - dx * k, hr.tl - dy * k, hr.tu - dz * k
			end
		end
		-- where the right hand holds follows how far apart the hands are wanted
		b.slideWant = u.butt + want
	else
		if hr.on then hr.tf, hr.tl, hr.tu = B.MoveTarget(R, hr.tf, hr.tl, hr.tu, across, up, out) end
		if st.twoHand then
			-- on its way to the handle: its target is the butt, where the weapon is now
			local s = u.butt - u.com
			local gx, gy, gz = M.QRot(b.qw, b.qx, b.qy, b.qz, s, 0, 0)
			hl.tf, hl.tl, hl.tu = B.ToAim(st, b.x + gx, b.y + gy, b.z + gz)
		elseif hl.on then
			-- (the free hand of a one-handed grip is a fist)
			hl.tf, hl.tl, hl.tu = B.MoveTarget(L, hl.tf, hl.tl, hl.tu, across, up, out, C.Guard.fists[L])
		end
	end
end

------------------------------------------------------------------------------------------
-- The step
------------------------------------------------------------------------------------------
-- An impulse along n at a place s (units along the handle from the weapon's centre) that takes
-- away the speed vn the place has along n. sc, mt, it, ia: the body of weapon and arms together.
local function StopAt(st, b, ax, ay, az, s, sc, mt, it, ia, nx, ny, nz, vn)
	local lev = s - sc
	local rcx, rcy, rcz = M.Cross(ax * lev, ay * lev, az * lev, nx, ny, nz)
	local kk = rcx * ax + rcy * ay + rcz * az
	local ix, iy, iz = (rcx - ax * kk) / it + ax * kk / ia, (rcy - ay * kk) / it + ay * kk / ia, (rcz - az * kk) / it + az * kk / ia
	local eff = 1 / (1 / mt + rcx * ix + rcy * iy + rcz * iz)
	local j = -vn * eff
	-- on the common centre, then back to the weapon's own
	local ccx, ccy, ccz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
	local vx, vy, vz = b.vx + ccx * sc + nx * j / mt, b.vy + ccy * sc + ny * j / mt, b.vz + ccz * sc + nz * j / mt
	b.wx, b.wy, b.wz = b.wx + ix * j, b.wy + iy * j, b.wz + iz * j
	ccx, ccy, ccz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
	b.vx, b.vy, b.vz = vx - ccx * sc, vy - ccy * sc, vz - ccz * sc
end

function S.ToolStep(st, prof, inp, dt, n, strength)
	local u, a = prof.u, C.Arm
	local b = st.w
	local hr, hl = st.h[R], st.h[L]
	local m, mh = prof.mass, a.mass
	local g = C.Sim.gravity * FH.M2U
	-- (where the weapon was a tick ago is kept by S.Step, before the turn of the view carries it)
	local wristMax, rollMax = FH.NM(a.wrist) * strength, FH.NM(a.rollTorque) * strength
	local kWrist, kStop = FH.NM(a.wristStiff), FH.NM(a.wristStop)
	local cone = rad(a.wristCone)
	local kRoll = FH.NM(a.rollStiff)
	local slideStep = a.slideSpeed * FH.M2U * dt
	local handRoll = FH.KGM2(0.003)
	-- the left hand takes hold when it has come to the butt
	if st.twoHand and not hl.grip then
		local s = u.butt - u.com
		local gx, gy, gz = M.QRot(b.qw, b.qx, b.qy, b.qz, s, 0, 0)
		local dx, dy, dz = b.x + gx - hl.px, b.y + gy - hl.py, b.z + gz - hl.pz
		if dx * dx + dy * dy + dz * dz < a.takeHold * a.takeHold then
			hl.grip = true
			-- (where the two hands are now is where they are wanted, until the mouse says otherwise)
			hl.tf, hl.tl, hl.tu = B.ToAim(st, b.x + gx, b.y + gy, b.z + gz)
			local rx, ry, rz = M.QRot(b.qw, b.qx, b.qy, b.qz, b.slide - u.com, 0, 0)
			hr.tf, hr.tl, hr.tu = B.ToAim(st, b.x + rx, b.y + ry, b.z + rz)
		end
	end
	for _ = 1, n do
		local two = hl.grip
		-- the right hand slides along the handle, not faster than a hand does
		local want = st.twoHand and b.slideWant or u.one
		b.slide = b.slide + Clamp(want - b.slide, -slideStep, slideStep)
		local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
		local sr, sl = b.slide - u.com, u.butt - u.com
		-- weapon and arms together: mass, centre (along the handle from the weapon's own), inertia
		local mt = m + mh + (two and mh or 0)
		local sc = (mh * sr + (two and mh * sl or 0)) / mt
		local it = u.it + m * sc * sc + mh * (sr - sc) * (sr - sc) + (two and mh * (sl - sc) * (sl - sc) or 0)
		local ia = u.ia + handRoll * (two and 2 or 1)
		-- the right grip, and how fast it moves
		local cx, cy, cz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
		local grx, gry, grz = b.x + ax * sr, b.y + ay * sr, b.z + az * sr
		-- (what a grip weighs to the arm that pulls on it)
		local er = 1 / (1 / mt + (sr - sc) * (sr - sc) / it)
		local fx, fy, fz = S.ArmForce(st, hr, grx, gry, grz, b.vx + cx * sr, b.vy + cy * sr, b.vz + cz * sr, er, strength)
		hr.fx, hr.fy, hr.fz = fx, fy, fz
		local pw = fx * (b.vx + cx * sr - st.bvx) + fy * (b.vy + cy * sr - st.bvy) + fz * (b.vz + cz * sr - st.bvz)
		if pw > 0 then st.work = st.work + pw * dt end
		-- torque about the common centre: lever (along the handle) times force
		local lev = sr - sc
		local tx, ty, tz = M.Cross(ax * lev, ay * lev, az * lev, fx, fy, fz)
		local sumx, sumy, sumz = fx, fy, fz
		if two then
			local elm = 1 / (1 / mt + (sl - sc) * (sl - sc) / it)
			local ox, oy, oz = S.ArmForce(st, hl, b.x + ax * sl, b.y + ay * sl, b.z + az * sl, b.vx + cx * sl, b.vy + cy * sl, b.vz + cz * sl, elm, strength)
			hl.fx, hl.fy, hl.fz = ox, oy, oz
			pw = ox * (b.vx + cx * sl - st.bvx) + oy * (b.vy + cy * sl - st.bvy) + oz * (b.vz + cz * sl - st.bvz)
			if pw > 0 then st.work = st.work + pw * dt end
			lev = sl - sc
			local qx, qy, qz = M.Cross(ax * lev, ay * lev, az * lev, ox, oy, oz)
			tx, ty, tz = tx + qx, ty + qy, tz + qz
			sumx, sumy, sumz = sumx + ox, sumy + oy, sumz + oz
		else
			-- One hand: the wrist holds the handle at its own angle to the forearm, as far as a
			-- wrist can; past what the joint allows, the joint itself stops it.
			local dx, dy, dz, mx, my, mz = WristRest(st, hr, grx, gry, grz)
			local qx, qy, qz = M.ArcVector(ax, ay, az, dx, dy, dz)
			-- (turning about the handle's own line is the edge's business, below)
			local wa = b.wx * ax + b.wy * ay + b.wz * az
			local ox, oy, oz = b.wx - ax * wa, b.wy - ay * wa, b.wz - az * wa
			-- How fast the forearm itself is turning the place the wrist holds for: a wrist stills
			-- the handle against the forearm, not against the room. (An arm that swings carries
			-- the tool round with it; a wrist that braked that would brake the swing.)
			local rwx, rwy, rwz = M.Cross(b.rdx, b.rdy, b.rdz, dx, dy, dz)
			rwx, rwy, rwz = rwx / dt, rwy / dt, rwz / dt
			b.rdx, b.rdy, b.rdz = dx, dy, dz
			-- (how hard the weapon is to turn about the grip decides how much damping stills it)
			local ig = it + mt * (sr - sc) * (sr - sc)
			local cWrist = 2 * a.wristDamp * sqrt(kWrist * ig)
			local wx, wy, wz = M.Limit(kWrist * qx - cWrist * (ox - rwx), kWrist * qy - cWrist * (oy - rwy), kWrist * qz - cWrist * (oz - rwz), wristMax)
			tx, ty, tz = tx + wx, ty + wy, tz + wz
			qx, qy, qz = M.ArcVector(ax, ay, az, mx, my, mz)
			local ang = sqrt(qx * qx + qy * qy + qz * qz)
			if ang > cone then
				local nx, ny, nz = qx / ang, qy / ang, qz / ang
				-- (leaving the cone is braked, coming back into it is not)
				local away = -(ox * nx + oy * ny + oz * nz)
				local t = kStop * (ang - cone) + (away > 0 and 1.2 * sqrt(kStop * ig) * away or 0)
				tx, ty, tz = tx + nx * t, ty + ny * t, tz + nz * t
			end
		end
		-- the weapon's weight, at its own centre
		local wgt = -m * g
		sumz = sumz + wgt
		local qx, qy, qz = M.Cross(-ax * sc, -ay * sc, -az * sc, 0, 0, wgt)
		tx, ty, tz = tx + qx, ty + qy, tz + qz
		-- The edge. The hands turn the handle about its own line so that the blade's side leads
		-- where the head is going; at rest it looks forward. Not faster than wrists can.
		do
			local ex, ey, ez = M.QRot(b.qw, b.qx, b.qy, b.qz, 0, 1, 0)
			local sh = u.length * 0.9 - u.com
			local hx, hy, hz = b.vx + cx * sh - st.bvx, b.vy + cy * sh - st.bvy, b.vz + cz * sh - st.bvz
			local k = hx * ax + hy * ay + hz * az
			hx, hy, hz = hx - ax * k, hy - ay * k, hz - az * k
			local sp = sqrt(hx * hx + hy * hy + hz * hz)
			-- (forward, as far as the handle's direction leaves a forward)
			local k2 = st.fx * ax + st.fy * ay + st.fz * az
			local dx, dy, dz, dl = M.Norm(st.fx - ax * k2, st.fy - ay * k2, st.fz - az * k2)
			if dl < 0.2 then dx, dy, dz = ex, ey, ez end
			local wgtv = Clamp((sp - a.edgeFrom * FH.M2U) / ((a.edgeFull - a.edgeFrom) * FH.M2U), 0, 1)
			if wgtv > 0 then
				local l
				dx, dy, dz, l = M.Norm(dx * (1 - wgtv) + hx / sp * wgtv, dy * (1 - wgtv) + hy / sp * wgtv, dz * (1 - wgtv) + hz / sp * wgtv)
				if l < 1e-4 then dx, dy, dz = ex, ey, ez end
			end
			local sx, sy, sz = M.Cross(ex, ey, ez, dx, dy, dz)
			local phi = atan2(sx * ax + sy * ay + sz * az, ex * dx + ey * dy + ez * dz)
			local wa = b.wx * ax + b.wy * ay + b.wz * az
			local tr = Clamp(kRoll * phi - 2 * sqrt(kRoll * ia) * wa, -rollMax, rollMax)
			tx, ty, tz = tx + ax * tr, ty + ay * tr, tz + az * tr
		end
		-- step the common body; carry the weapon's own centre with it
		local vcx, vcy, vcz = b.vx + cx * sc + sumx / mt * dt, b.vy + cy * sc + sumy / mt * dt, b.vz + cz * sc + sumz / mt * dt
		local pcx, pcy, pcz = b.x + ax * sc + vcx * dt, b.y + ay * sc + vcy * dt, b.z + az * sc + vcz * dt
		local k = tx * ax + ty * ay + tz * az
		local dmp = max(1 - prof.spinDamp * dt, 0)
		local wxn = (b.wx + ((tx - ax * k) / it + ax * k / ia) * dt) * dmp
		local wyn = (b.wy + ((ty - ay * k) / it + ay * k / ia) * dt) * dmp
		local wzn = (b.wz + ((tz - az * k) / it + az * k / ia) * dt) * dmp
		b.wx, b.wy, b.wz = wxn, wyn, wzn
		b.qw, b.qx, b.qy, b.qz = M.QStep(b.qw, b.qx, b.qy, b.qz, wxn, wyn, wzn, dt)
		ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
		cx, cy, cz = M.Cross(wxn, wyn, wzn, ax, ay, az)
		b.vx, b.vy, b.vz = vcx - cx * sc, vcy - cy * sc, vcz - cz * sc
		b.x, b.y, b.z = pcx - ax * sc, pcy - ay * sc, pcz - az * sc

		-- What holds the weapon in: arms that end, and the body in the way. A grip that is beyond
		-- its arm's reach, or inside the trunk or the head, is put back, the weapon with it, and
		-- what it had of speed that way is taken from it there.
		for i = 1, 2 do
			if i == R or two then
				local h = st.h[i]
				local s = i == R and sr or sl
				local px, py, pz = b.x + ax * s, b.y + ay * s, b.z + az * s
				local qx2, qy2, qz2, deep = B.KeepOut(st, px, py, pz, 0.8, true)
				local rx, ry, rz, over = B.WithinReach(h, qx2, qy2, qz2)
				if deep > 0 or over > 0 then
					local dx, dy, dz = rx - px, ry - py, rz - pz
					local nx, ny, nz, l = M.Norm(dx, dy, dz)
					if l > 1e-4 then
						b.x, b.y, b.z = b.x + dx, b.y + dy, b.z + dz
						local ccx, ccy, ccz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
						local vn = (b.vx + ccx * s - st.bvx) * nx + (b.vy + ccy * s - st.bvy) * ny + (b.vz + ccz * s - st.bvz) * nz
						if vn < 0 then StopAt(st, b, ax, ay, az, s, sc, mt, it, ia, nx, ny, nz, vn) end
					end
				end
			end
		end
		-- The weapon itself against its owner: a place on it that is inside the trunk or too near
		-- the face is put out again and stopped there, like a grip.
		local us = prof.usamples
		for k = 1, #us do
			local s = us[k].at - u.com
			local px, py, pz = b.x + ax * s, b.y + ay * s, b.z + az * s
			local qx2, qy2, qz2, deep = B.KeepOut(st, px, py, pz, 0.4)
			if deep > 0 then
				local dx, dy, dz = qx2 - px, qy2 - py, qz2 - pz
				local nx, ny, nz, l = M.Norm(dx, dy, dz)
				if l > 1e-4 then
					b.x, b.y, b.z = b.x + dx * 0.5, b.y + dy * 0.5, b.z + dz * 0.5
					local ccx, ccy, ccz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
					local vn = (b.vx + ccx * s - st.bvx) * nx + (b.vy + ccy * s - st.bvy) * ny + (b.vz + ccz * s - st.bvz) * nz
					if vn < 0 then StopAt(st, b, ax, ay, az, s, sc, mt, it, ia, nx, ny, nz, vn) end
				end
			end
		end
		if not two then
			S.StepFist(st, hl, L, dt, strength)
			-- A free fist is not in its own weapon's shaft. Nearer to it than the two are thick,
			-- the fist is put out sideways from the shaft and loses what speed it had into it:
			-- the fist gives way, not the weapon. (Not while that hand is on its way to the
			-- handle to take hold of it: st.twoHand.) Measured before: 1.7 units between the
			-- two where touching is 3.2, tools/fhsim/t_feel.lua.
			if not st.twoHand then
				local t = Clamp((hl.px - b.x) * ax + (hl.py - b.y) * ay + (hl.pz - b.z) * az, -u.com, u.length - u.com)
				local dx, dy, dz = hl.px - (b.x + ax * t), hl.py - (b.y + ay * t), hl.pz - (b.z + az * t)
				local need = C.Hit.fistR + C.Hit.barR
				local d2 = dx * dx + dy * dy + dz * dz
				if d2 < need * need and d2 > 1e-6 then
					local d = sqrt(d2)
					local nx, ny, nz = dx / d, dy / d, dz / d
					hl.px, hl.py, hl.pz = hl.px + nx * (need - d), hl.py + ny * (need - d), hl.pz + nz * (need - d)
					local ccx, ccy, ccz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
					local vn = (hl.vx - b.vx - ccx * t) * nx + (hl.vy - b.vy - ccy * t) * ny + (hl.vz - b.vz - ccz * t) * nz
					if vn < 0 then hl.vx, hl.vy, hl.vz = hl.vx - nx * vn, hl.vy - ny * vn, hl.vz - nz * vn end
				end
			end
		end
	end
	S.ToolHands(st, prof)
end

-- The hands are where their grips are.
function S.ToolHands(st, prof)
	local u, b = prof.u, st.w
	local hr, hl = st.h[R], st.h[L]
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local cx, cy, cz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
	local sr = b.slide - u.com
	hr.px, hr.py, hr.pz = b.x + ax * sr, b.y + ay * sr, b.z + az * sr
	hr.vx, hr.vy, hr.vz = b.vx + cx * sr, b.vy + cy * sr, b.vz + cz * sr
	if hl.grip then
		local sl = u.butt - u.com
		hl.px, hl.py, hl.pz = b.x + ax * sl, b.y + ay * sl, b.z + az * sl
		hl.vx, hl.vy, hl.vz = b.vx + cx * sl, b.vy + cy * sl, b.vz + cz * sl
	end
end

------------------------------------------------------------------------------------------
-- The weapon as something that is struck or strikes (sh_contact.lua): the body of weapon and
-- arms together, at a place given by its offset r (world) from the weapon's own centre.
------------------------------------------------------------------------------------------
-- mass, where its centre is along the handle from the weapon's own, inertia across and along
function S.ToolMass(st, prof)
	local u, b, mh = prof.u, st.w, C.Arm.mass
	local two = st.h[L].grip
	local sr, sl = b.slide - u.com, u.butt - u.com
	local mt = prof.mass + mh + (two and mh or 0)
	local sc = (mh * sr + (two and mh * sl or 0)) / mt
	local it = u.it + prof.mass * sc * sc + mh * (sr - sc) * (sr - sc) + (two and mh * (sl - sc) * (sl - sc) or 0)
	return mt, sc, it, u.ia + FH.KGM2(0.003) * (two and 2 or 1)
end

-- How heavy it is to what meets it at r along n (kg).
function S.ToolEffMass(st, prof, rx, ry, rz, nx, ny, nz)
	local b = st.w
	local mt, sc, it, ia = S.ToolMass(st, prof)
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local cx, cy, cz = M.Cross(rx - ax * sc, ry - ay * sc, rz - az * sc, nx, ny, nz)
	local k = cx * ax + cy * ay + cz * az
	local ix, iy, iz = (cx - ax * k) / it + ax * k / ia, (cy - ay * k) / it + ay * k / ia, (cz - az * k) / it + az * k / ia
	return 1 / (1 / mt + cx * ix + cy * iy + cz * iz)
end

-- An impulse j (kg unit / s) at r.
function S.ToolImpulse(st, prof, rx, ry, rz, jx, jy, jz)
	local b = st.w
	local mt, sc, it, ia = S.ToolMass(st, prof)
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	-- on the common centre, then back to the weapon's own
	local ccx, ccy, ccz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
	local vx, vy, vz = b.vx + ccx * sc + jx / mt, b.vy + ccy * sc + jy / mt, b.vz + ccz * sc + jz / mt
	local tx, ty, tz = M.Cross(rx - ax * sc, ry - ay * sc, rz - az * sc, jx, jy, jz)
	local k = tx * ax + ty * ay + tz * az
	b.wx, b.wy, b.wz = b.wx + (tx - ax * k) / it + ax * k / ia, b.wy + (ty - ay * k) / it + ay * k / ia, b.wz + (tz - az * k) / it + az * k / ia
	ccx, ccy, ccz = M.Cross(b.wx, b.wy, b.wz, ax, ay, az)
	b.vx, b.vy, b.vz = vx - ccx * sc, vy - ccy * sc, vz - ccz * sc
end
