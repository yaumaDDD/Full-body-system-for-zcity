-- Client: the view while an arm is held.
--
-- While a hand is held the mouse is the arm's and the eye stands still (cl_input.lua). A hand
-- or a weapon's head that is sent toward the edge of the picture would leave it: the view then
-- turns after it, a little and smoothly, and turns back when the hand comes back.
--
--   * The picture only. The eye (where the player aims, what the simulation is stepped with,
--     what the server hears) is not touched: the turn is added to the view Z-City has made,
--     in the two hooks Z-City runs when it has made it.
--   * Measured against the eye, not against the picture that has already turned: how far the
--     hand is outside a zone about the eye's own line is how far the view is to turn. A view
--     that measured against itself would chase the hand.
--   * A spring without overshoot (critically damped), stepped with the frame's own time.
--   * Several things to keep in the picture (two fists; a hand and its weapon's head): what
--     the one asks to the right and the other to the left is added, so two arms sent apart
--     leave the view where it is.
--   * Nothing held: the view goes back to the eye by the same spring, while the mouse turns
--     the eye again.
--
-- The view turns about the eye's own place; it is not moved, so nothing new can be looked
-- through. Numbers: sh_config.lua, C.Cam.
--
-- How much: one setting, fh_camera_follow, from 0 (never) to 1. Since phase 42 it is little by
-- default and it follows hands only. Until then it followed a weapon's head too, by up to 22
-- degrees: the head of an axe leaves the picture in every full swing, so every swing turned the
-- view the way the mouse had gone, which is what a player who holds an arm must not get.

FreeHand.NoJIT()
local FH = FreeHand
local C, M, W = FH.Config, FH.Math, FH.Weapon
FH.Cam = FH.Cam or { yaw = 0, pitch = 0, vyaw = 0, vpitch = 0, wantYaw = 0, wantPitch = 0, frame = -1 }
local cam = FH.Cam
local cl = FH.cl
local deg, atan2, sqrt, abs, tan, rad, min, max = math.deg, math.atan2, math.sqrt, math.abs, math.tan, math.rad, math.min, math.max

-- How far outside the zone a place is: degrees to the right (+) and up (+) of it. eye: the
-- view's place; f, r, u: its axes; zx, zy: half the zone (degrees).
local function Outside(x, y, z, eye, f, r, u, zx, zy)
	local dx, dy, dz = x - eye.x, y - eye.y, z - eye.z
	local df, dr, du = dx * f.x + dy * f.y + dz * f.z, dx * r.x + dy * r.y + dz * r.z, dx * u.x + dy * u.y + dz * u.z
	-- (a place beside or behind the eye is as far out as a place can be)
	local az = deg(atan2(dr, max(df, 0.01)))
	local el = deg(atan2(du, max(sqrt(df * df + dr * dr), 0.01)))
	return az - M.Clamp(az, -zx, zx), el - M.Clamp(el, -zy, zy), az, el
end

-- What the view is asked to turn by now: degrees to the right and up.
local function Want(lp, view)
	local c = C.Cam
	local much = M.Clamp(C.cv.camFollow:GetFloat(), 0, 1)
	-- (a scene is running: the default, as for every other setting)
	if FH.testRun and not FH.testPrefs then much = tonumber(C.cv.camFollow:GetDefault()) or 0.4 end
	if not cl.held or much <= 0 then return 0, 0 end
	local rs = FH.RenderHands(lp)
	if not rs then return 0, 0 end
	local ang = view.angles
	local f, r, u = ang:Forward(), ang:Right(), ang:Up()
	local eye = view.origin
	-- half the picture, in degrees (the engine's angle is the picture's width at 4:3)
	local th = tan(rad((view.fov or 90) * 0.5))
	local zone = c.zone
	local zx = deg(math.atan(th * (ScrW() / ScrH()) / (4 / 3))) * zone
	local zy = deg(math.atan(th * 0.75)) * zone
	local right, left, up, down = 0, 0, 0, 0
	local function Keep(x, y, z)
		local ox, oy, az, el = Outside(x, y, z, eye, f, r, u, zx, zy)
		right, left, up, down = max(right, ox), min(left, ox), max(up, oy), min(down, oy)
		cam.az, cam.el = az, el
	end
	if rs.tool and rs.w then
		-- a tool: the hand that leads it (not its head: see above)
		local hr = rs.h[2]
		Keep(hr.x, hr.y, hr.z)
	else
		for i = 1, 2 do
			local h = rs.h[i]
			if h.on then Keep(h.x, h.y, h.z) end
		end
	end
	local most = c.max * much * (rs.tool and c.toolShare or 1)
	return M.Clamp(right + left, -most, most), M.Clamp(up + down, -most * c.pitchShare, most * c.pitchShare)
end

local function Update(lp, view)
	local frame = FrameNumber()
	if cam.frame == frame then return end
	cam.frame = frame
	local dt = min(RealFrameTime(), 0.1)
	local wy, wp = Want(lp, view)
	cam.wantYaw, cam.wantPitch = wy, wp
	local w = C.Cam.speed
	cam.yaw, cam.vyaw = M.Spring(cam.yaw, cam.vyaw, wy, w, dt)
	cam.pitch, cam.vpitch = M.Spring(cam.pitch, cam.vpitch, wp, w, dt)
	if wy == 0 and wp == 0 and abs(cam.yaw) < 0.005 and abs(cam.pitch) < 0.005 then
		cam.yaw, cam.pitch, cam.vyaw, cam.vpitch = 0, 0, 0, 0
	end
	if cam.rec then
		-- (the eye: what the last command said it was. Z-City's own answer to EyeAngles on the
		-- client is not the aim.)
		cam.rec[#cam.rec + 1] = { RealTime(), cam.yaw, cam.pitch, wy, wp, cl.cmdYaw or 0, cl.cmdPitch or 0, cam.az or 0, cam.el or 0, cl.held and 1 or 0 }
	end
end

local function Follow(ply, view)
	if ply ~= LocalPlayer() or not istable(view) or not view.angles or not view.origin then return end
	Update(ply, view)
	if cam.yaw ~= 0 or cam.pitch ~= 0 then
		-- (to the right is a smaller yaw, up is a smaller pitch)
		local a = view.angles
		view.angles = Angle(a.p - cam.pitch, a.y - cam.yaw, a.r)
	end
	-- (for a scene: the picture's direction as it leaves here)
	if cam.watch then
		local a, v = view.angles, cam.watch
		v.frame, v.y, v.p, v.r = FrameNumber(), a.y, a.p, a.r
	end
end

hook.Add("PostHGCalcView", "FH_CameraFollow", function(ply, view) Follow(ply, view) end)
hook.Add("PostPostHGCalcView", "FH_CameraFollow", function(ply, view) Follow(ply, view) end)
