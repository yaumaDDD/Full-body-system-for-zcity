-- What the hands and the weapon run into.
--
-- Every place of a weapon that can touch something (the samples of its profile), and the
-- knuckles of a free hand, are followed from where they were a tick ago to where they are now.
-- What lies on that way is found by a line through the world and the hitboxes of whoever stands
-- in it, and by measuring against the weapons and forearms of other fighters, which are no
-- objects of the engine. The first thing met stops the place: the weapon gets the impulse that
-- takes away its speed into the surface (and gives some of it back: steel on stone rebounds),
-- it is put back outside, and on the server the impulse is handed on as a blow (sv_impact.lua).
--
-- Nothing here knows an attack. A weapon carried into a wall is stopped by the wall in the same
-- way; it is not a blow only because nothing was moving fast.

FreeHand.SameOnBothSides()
local FH = FreeHand
local C, M, B, W, S = FH.Config, FH.Math, FH.Body, FH.Weapon, FH.Sim
FH.Contact = FH.Contact or {}
local K = FH.Contact
local sqrt, abs, min, max = math.sqrt, math.abs, math.min, math.max
local R, L = 2, 1
local HUGE = 1e9

------------------------------------------------------------------------------------------
-- What of a fighter can strike: places, where they were, how fast they are.
------------------------------------------------------------------------------------------
local pts = {}
local function Point(n)
	local p = pts[n]
	if not p then p = {} pts[n] = p end
	return p
end

local function Fist(n, st, i)
	local h = st.h[i]
	local p = Point(n)
	p.px, p.py, p.pz = h.kx, h.ky, h.kz
	p.qx, p.qy, p.qz = h.kqx, h.kqy, h.kqz
	p.r, p.kind, p.idx, p.hand = C.Hit.fistR, "fist", 0, i
	p.rx, p.ry, p.rz = 0, 0, 0
end

local function Gather(st, prof)
	local n = 0
	if prof.kind == "tool" and st.w then
		local b, u = st.w, prof.u
		local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
		local ex, ey, ez = M.QRot(b.qw, b.qx, b.qy, b.qz, 0, 1, 0)
		local pax, pay, paz = M.QRot(b.pqw, b.pqx, b.pqy, b.pqz, 1, 0, 0)
		local pex, pey, pez = M.QRot(b.pqw, b.pqx, b.pqy, b.pqz, 0, 1, 0)
		local us = prof.usamples
		for k = 1, #us do
			local s = us[k]
			n = n + 1
			local p = Point(n)
			local d = s.at - u.com
			p.rx, p.ry, p.rz = ax * d + ex * s.off, ay * d + ey * s.off, az * d + ez * s.off
			p.px, p.py, p.pz = b.x + p.rx, b.y + p.ry, b.z + p.rz
			p.qx, p.qy, p.qz = b.px + pax * d + pex * s.off, b.py + pay * d + pey * s.off, b.pz + paz * d + pez * s.off
			p.r, p.kind, p.idx, p.hand = s.r, s.kind, k, nil
		end
		if not st.h[L].grip then n = n + 1 Fist(n, st, L) end
	else
		n = 1 Fist(1, st, L)
		n = 2 Fist(2, st, R)
	end
	return n
end

------------------------------------------------------------------------------------------
-- What of other fighters is in the way: their weapons and their forearms, as capsules.
-- (Server only: a client steps no fighter but its own.)
------------------------------------------------------------------------------------------
local caps = {}
local function Cap(n)
	local c = caps[n]
	if not c then c = {} caps[n] = c end
	return c
end

local function Capsules(ply, st)
	local n = 0
	local near2 = C.Hit.near * C.Hit.near
	for other, os in pairs(FH.states) do
		if other ~= ply and os.active and os.ok and IsValid(other) then
			local dx, dy = os.bx - st.bx, os.by - st.by
			if dx * dx + dy * dy < near2 then
				local op = os.prof
				if op.kind == "tool" and os.w then
					local b, u = os.w, op.u
					local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
					n = n + 1
					local c = Cap(n)
					c.ax, c.ay, c.az = b.x - ax * u.com, b.y - ay * u.com, b.z - az * u.com
					c.bx, c.by, c.bz = c.ax + ax * u.length, c.ay + ay * u.length, c.az + az * u.length
					c.r, c.kind, c.ply, c.st, c.i = C.Hit.barR, "tool", other, os, 0
				end
				for i = 1, 2 do
					local h = os.h[i]
					if h.ex then
						n = n + 1
						local c = Cap(n)
						c.ax, c.ay, c.az = h.ex, h.ey, h.ez
						c.bx, c.by, c.bz = h.kx, h.ky, h.kz
						c.r, c.kind, c.ply, c.st, c.i = C.Hit.armR, "arm", other, os, i
					end
				end
			end
		end
	end
	return n
end

------------------------------------------------------------------------------------------
-- One place against what lies on its way.
------------------------------------------------------------------------------------------
local vStart, vEnd = Vector(0, 0, 0), Vector(0, 0, 0)
local trRes = {}
local filt = {}
local trace = { start = vStart, endpos = vEnd, filter = filt, mask = MASK_SHOT, output = trRes }
local con = {}          -- the contact that is handed on (one table, used again)

local function Owner(ent)
	if ent:IsPlayer() then return ent end
	if hg and hg.RagdollOwner then
		local o = hg.RagdollOwner(ent)
		if IsValid(o) then return o end
	end
	return nil
end

local function Fights(ply)
	if SERVER then
		local s = FH.states[ply]
		return s ~= nil and s.active == true
	end
	return FH.Applies(ply) ~= nil
end

local ARM = { [HITGROUP_LEFTARM] = true, [HITGROUP_RIGHTARM] = true }

-- The middle of a head (world), from its bone (whose x axis runs up through the head).
local headBone = {}
function K.HeadCentre(ent)
	if not ent.LookupBone then return nil end
	local mdl = ent:GetModel() or ""
	local b = headBone[mdl]
	if b == nil then
		b = ent:LookupBone("ValveBiped.Bip01_Head1") or false
		headBone[mdl] = b
	end
	if b then
		local p, a = ent:GetBonePosition(b)
		if p and p ~= ent:GetPos() then
			local f = a:Forward()
			return p.x + f.x * 3.2, p.y + f.y * 3.2, p.z + f.z * 3.2
		end
	end
	if ent:IsPlayer() then
		local e = ent:EyePos()
		return e.x, e.y, e.z - 0.5
	end
	return nil
end

-- What a struck part of a body weighs to the blow.
local function PartMass(hitgroup)
	local m = C.Hit.mass
	if hitgroup == HITGROUP_HEAD then return m.head end
	if hitgroup == HITGROUP_CHEST or hitgroup == HITGROUP_STOMACH then return m.trunk end
	if ARM[hitgroup] then return m.arm end
	if hitgroup == HITGROUP_LEFTLEG or hitgroup == HITGROUP_RIGHTLEG then return m.leg end
	return m.other
end

-- The velocity of the place now (the weapon may have been struck already this tick).
local function Velocity(st, p)
	if p.hand then
		local h = st.h[p.hand]
		return h.vx, h.vy, h.vz
	end
	local b = st.w
	local cx, cy, cz = M.Cross(b.wx, b.wy, b.wz, p.rx, p.ry, p.rz)
	return b.vx + cx, b.vy + cy, b.vz + cz
end

-- Returns true when the place met something.
local function Touch(ply, wep, st, prof, p, ncap)
	local H = C.Hit
	local dx, dy, dz = p.px - p.qx, p.py - p.qy, p.pz - p.qz
	local len = sqrt(dx * dx + dy * dy + dz * dz)
	if len < H.minMove then return false end
	local ux, uy, uz = dx / len, dy / len, dz / len

	-- other fighters' weapons and arms
	local best, cap, capT = 2, nil, 0
	for k = 1, ncap do
		local c = caps[k]
		local s, t, d2 = M.SegSeg(p.qx, p.qy, p.qz, p.px, p.py, p.pz, c.ax, c.ay, c.az, c.bx, c.by, c.bz)
		local rr = p.r + c.r
		if d2 < rr * rr then
			-- Where the two are nearest the place is moving past, not into: they first touch
			-- earlier on the way, by as much as it takes to come from the touching distance to
			-- the nearest one across the other's line.
			local wx, wy, wz = M.Norm(c.bx - c.ax, c.by - c.ay, c.bz - c.az)
			local along = ux * wx + uy * wy + uz * wz
			local across2 = 1 - along * along
			if across2 > 0.01 then s = s - sqrt((rr * rr - d2) / across2) / len end
			if s < 0 then s = 0 end
			if s < best then best, cap = s, c end
		end
	end

	-- the world, and the hitboxes of whoever stands in it
	local ent, hitgroup, physbone, hitbox, mat, surf
	local hx, hy, hz, nx, ny, nz
	vStart:SetUnpacked(p.qx, p.qy, p.qz)
	vEnd:SetUnpacked(p.px + ux * p.r, p.py + uy * p.r, p.pz + uz * p.r)
	util.TraceLine(trace)
	if trRes.Hit and not trRes.StartSolid then
		local e = trRes.Entity
		-- (the arms of a fighter are where the simulation has them, not where the animation of
		-- the body under them puts their hitboxes: those are passed through, once)
		if IsValid(e) and ARM[trRes.HitGroup] then
			local o = Owner(e)
			if o and e == o and Fights(o) then
				local hp = trRes.HitPos
				vStart:SetUnpacked(hp.x + ux * 4.5, hp.y + uy * 4.5, hp.z + uz * 4.5)
				local left = (vEnd.x - vStart.x) * ux + (vEnd.y - vStart.y) * uy + (vEnd.z - vStart.z) * uz
				if left > 0.5 then util.TraceLine(trace) else trRes.Hit = false end
			end
		end
	end
	if trRes.Hit and not trRes.StartSolid then
		local hp = trRes.HitPos
		local f = ((hp.x - p.qx) * ux + (hp.y - p.qy) * uy + (hp.z - p.qz) * uz) / len
		if f < best then
			best, cap = min(f, 1), nil
			ent = trRes.Entity
			hx, hy, hz = hp.x, hp.y, hp.z
			local hn = trRes.HitNormal
			nx, ny, nz = hn.x, hn.y, hn.z
			hitgroup, physbone, hitbox, mat, surf = trRes.HitGroup or 0, trRes.PhysicsBone or 0, trRes.HitBox or 0, trRes.MatType, trRes.SurfaceProps
		end
	end
	if best > 1.5 then return false end

	-- the other side: how fast it moves there and what it weighs
	local tvx, tvy, tvz, tm = 0, 0, 0, HUGE
	local soft, target = false, nil
	if cap then
		local s = min(best, 1)
		hx, hy, hz = p.qx + dx * s, p.qy + dy * s, p.qz + dz * s
		-- the place on the other's line that is nearest then
		local wx, wy, wz, wl = M.Norm(cap.bx - cap.ax, cap.by - cap.ay, cap.bz - cap.az)
		capT = wl > 1e-6 and M.Clamp(((hx - cap.ax) * wx + (hy - cap.ay) * wy + (hz - cap.az) * wz) / wl, 0, 1) or 0
		local qx, qy, qz = cap.ax + (cap.bx - cap.ax) * capT, cap.ay + (cap.by - cap.ay) * capT, cap.az + (cap.bz - cap.az) * capT
		local l
		nx, ny, nz, l = M.Norm(hx - qx, hy - qy, hz - qz)
		if l < 1e-3 then nx, ny, nz = -ux, -uy, -uz end
		-- (the surface of what was met, not its middle line)
		hx, hy, hz = qx + nx * cap.r, qy + ny * cap.r, qz + nz * cap.r
		local os = cap.st
		if cap.kind == "tool" then
			local b = os.w
			local rx, ry, rz = qx - b.x, qy - b.y, qz - b.z
			tvx, tvy, tvz = W.VelAt(b, rx, ry, rz)
			tm = S.ToolEffMass(os, os.prof, rx, ry, rz, nx, ny, nz)
		else
			local h = os.h[cap.i]
			tvx, tvy, tvz = os.bvx + (h.vx - os.bvx) * capT, os.bvy + (h.vy - os.bvy) * capT, os.bvz + (h.vz - os.bvz) * capT
			tm = H.mass.arm
			soft = true
		end
		ent = cap.ply
		target = cap.ply
		hitgroup, physbone, hitbox, mat, surf = 0, 0, 0, nil, nil
	elseif IsValid(ent) then
		target = Owner(ent)
		if target then
			soft = true
			tm = PartMass(hitgroup)
			local v = ent:GetVelocity()
			tvx, tvy, tvz = v.x, v.y, v.z
			-- A head is round and its hitbox is a box: which face of the box a fist happens to
			-- meet would decide how square the blow is (a rising straight right met the box from
			-- below and lost half its speed, run fh15). The surface a head is struck on faces
			-- away from the head's middle.
			if hitgroup == HITGROUP_HEAD then
				local cx, cy, cz = K.HeadCentre(ent)
				if cx then
					local lx, ly, lz, l = M.Norm(hx - cx, hy - cy, hz - cz)
					if l > 1.5 then nx, ny, nz = lx, ly, lz end
				end
			end
		else
			local v = ent:GetVelocity()
			tvx, tvy, tvz = v.x, v.y, v.z
			if ent:IsNPC() or (ent.IsNextBot and ent:IsNextBot()) then
				soft, tm = true, H.mass.other
			else
				local phys = SERVER and ent:GetPhysicsObjectNum(physbone) or nil
				if IsValid(phys) and phys:IsMotionEnabled() and phys:IsMoveable() then
					tm = max(phys:GetMass(), 0.2)
					if ent:IsRagdoll() then soft, tm = true, min(tm * 3, H.mass.other) end
				elseif ent:IsRagdoll() then
					soft, tm = true, H.mass.other
				end
			end
		end
	end

	-- how fast the two close on each other
	local vx, vy, vz = Velocity(st, p)
	local rvx, rvy, rvz = vx - tvx, vy - tvy, vz - tvz
	local vn = rvx * nx + rvy * ny + rvz * nz
	if vn >= 0 then return false end

	local fist = p.hand ~= nil
	-- A place that lay against the same thing a tick ago is pressed against it, not thrown at it.
	-- The arm goes on pushing, and stepped in ticks that is a small speed gained and lost again
	-- every tick: a force, and no blow however long it lasts.
	local key = fist and (100 + p.hand) or p.idx
	local what = target or (IsValid(ent) and ent) or "world"
	local tch = st.touch[key]
	if not tch then tch = { tick = -10 } st.touch[key] = tch end
	local pressing = tch.what == what and st.tick - tch.tick <= H.pressTicks
	tch.tick, tch.what = st.tick, what
	if pressing then st.pressTick = st.tick end
	local e = (prof.restitution or 0.25) * (soft and H.flesh or 1)
	if pressing then e = 0 end
	local mw
	if fist then mw = C.Arm.mass else mw = S.ToolEffMass(st, prof, p.rx, p.ry, p.rz, nx, ny, nz) end
	local mu = mw * tm / (mw + tm)
	local j = -(1 + e) * mu * vn
	-- scraping along the surface
	local sx, sy, sz = rvx - nx * vn, rvy - ny * vn, rvz - nz * vn
	local sl = sqrt(sx * sx + sy * sy + sz * sz)
	local jt = 0
	if sl > 1e-3 then
		jt = min(H.friction * j, mu * sl)
		sx, sy, sz = sx / sl, sy / sl, sz / sl
	end
	local jx, jy, jz = nx * j - sx * jt, ny * j - sy * jt, nz * j - sz * jt
	-- back outside (a place is a ball: half of it may sink in, as knuckles do into what they hit)
	local depth = (hx - p.px) * nx + (hy - p.py) * ny + (hz - p.pz) * nz + H.skin + p.r * 0.5
	if depth < 0 then depth = 0 end
	if fist then
		local h = st.h[p.hand]
		local m = C.Arm.mass
		h.vx, h.vy, h.vz = h.vx + jx / m, h.vy + jy / m, h.vz + jz / m
		h.px, h.py, h.pz = h.px + nx * depth, h.py + ny * depth, h.pz + nz * depth
		h.kx, h.ky, h.kz = h.kx + nx * depth, h.ky + ny * depth, h.kz + nz * depth
	else
		S.ToolImpulse(st, prof, p.rx, p.ry, p.rz, jx, jy, jz)
		local b = st.w
		b.x, b.y, b.z = b.x + nx * depth, b.y + ny * depth, b.z + nz * depth
	end

	if CLIENT then return true end

	-- the same and opposite on another fighter's weapon or arm
	if cap then
		local os = cap.st
		if cap.kind == "tool" then
			local b = os.w
			S.ToolImpulse(os, os.prof, hx - nx * cap.r - b.x, hy - ny * cap.r - b.y, hz - nz * cap.r - b.z, -jx, -jy, -jz)
			S.ToolHands(os, os.prof)
		else
			local h = os.h[cap.i]
			if os.prof.kind == "tool" and os.w and (cap.i == R or h.grip) then
				local b = os.w
				S.ToolImpulse(os, os.prof, h.px - b.x, h.py - b.y, h.pz - b.z, -jx * capT, -jy * capT, -jz * capT)
				S.ToolHands(os, os.prof)
			else
				local m = C.Arm.mass
				h.vx, h.vy, h.vz = h.vx - jx * capT / m, h.vy - jy * capT / m, h.vz - jz * capT / m
			end
		end
	end

	-- the blow, in metres, newton seconds and joules
	local U = FH.U2M
	local mb = fist and H.fistMass or mw
	local mub = mb * tm / (mb + tm)
	local c = con
	c.ent, c.target = ent, target
	c.x, c.y, c.z = hx, hy, hz
	c.nx, c.ny, c.nz = nx, ny, nz
	local rl = sqrt(rvx * rvx + rvy * rvy + rvz * rvz)
	c.dx, c.dy, c.dz = rvx / rl, rvy / rl, rvz / rl
	c.speed = rl * U
	c.closing = -vn * U
	c.impulse = (1 + e) * mub * -vn * U
	c.energy = 0.5 * mub * vn * vn * U * U * (1 - e * e)
	c.mass, c.tmass = mb, tm
	c.kind, c.idx, c.hand = p.kind, p.idx, p.hand
	c.hitgroup, c.physbone, c.hitbox, c.mat, c.surf = hitgroup, physbone, hitbox, mat, surf
	c.soft = soft
	c.block = cap and cap.kind or nil
	c.blockArm = cap and cap.i or 0
	c.pressing = pressing
	-- an edge: how well it leads (1: the blade goes first, 0: the flat or the back does)
	c.edge = 0
	if p.kind == "edge" and st.w then
		local b = st.w
		local ex, ey, ez = M.QRot(b.qw, b.qx, b.qy, b.qz, 0, 1, 0)
		c.edge = M.Clamp(c.dx * ex + c.dy * ey + c.dz * ez, 0, 1)
	end
	if FH.Impact and FH.Impact.Blow then FH.Impact.Blow(ply, wep, st, prof, c) end
	return true
end

------------------------------------------------------------------------------------------
-- A tick's contacts for one fighter.
------------------------------------------------------------------------------------------
function K.Run(ply, wep, st, prof)
	if st.contactTick == st.tick then return end
	st.contactTick = st.tick
	local n = Gather(st, prof)
	local ncap = SERVER and Capsules(ply, st) or 0
	filt[1], filt[2] = ply, wep
	local any = false
	-- (from the head of the weapon down: what is fastest meets first)
	for k = n, 1, -1 do
		if Touch(ply, wep, st, prof, pts[k], ncap) then any = true end
	end
	if any and prof.kind == "tool" and st.w then S.ToolHands(st, prof) end
	return any
end

-- Server: inside the player's command (the weapon's Think), so that whoever stands in the way
-- stands where the player saw them.
function K.Think(ply, wep)
	local st = FH.states[ply]
	if not st or not st.active or not st.ok or st.wep ~= wep then return end
	local pf = FH.Perf
	local t0 = pf and SysTime()
	ply:LagCompensation(true)
	local ok, err = pcall(K.Run, ply, wep, st, st.prof)
	ply:LagCompensation(false)
	if pf then pf.contact, pf.contacts = pf.contact + SysTime() - t0, pf.contacts + 1 end
	if not ok then
		wep.FH_broken = true
		FH.Print("contact error for %s with %s: %s", ply:Nick(), wep:GetClass(), tostring(err))
		if FH.TestLog then FH.TestLog("  CONTACT ERROR %s", tostring(err)) end
	end
	if FH.OnContact then FH.OnContact(ply, st) end
end
