-- Taking over six weapon classes of Z-City at run time, and only those.
--
-- Z-City's files are not edited. A method of a class is replaced by one that asks first whether
-- this module holds the player's hands (FH.Applies) and otherwise calls the method that was
-- there: a ragdolled player, a player in a car, a cuffed one, an NPC with the weapon, the module
-- switched off, all get Z-City's own behaviour unchanged. The replacement is put on the class's
-- own stored table, never on weapon_melee, which thirty other weapons inherit from.
--
-- A fault inside a replacement must not leave a player with a dead weapon: it is caught, the
-- weapon is marked, and that weapon is Z-City's from then on.

local FH = FreeHand
local C = FH.Config
FH.Patch = FH.Patch or {}
local P = FH.Patch
P.done = P.done or {}

-- The method a class has under a name, its own or inherited.
local function Lookup(class, name)
	local seen = 0
	while class and seen < 8 do
		local t = weapons.GetStored(class)
		if not t then return nil end
		local key = "FH_orig_" .. name
		if t[key] then return t[key] end
		if t[name] ~= nil and not t["FH_is_" .. name] then return t[name] end
		class, seen = t.Base, seen + 1
	end
	return nil
end

-- fn(orig, self, ...): the replacement; orig may be nil when the class never had the method.
function P.Wrap(class, name, fn)
	local t = weapons.GetStored(class)
	if not t then return false end
	if t["FH_orig_" .. name] == nil then t["FH_orig_" .. name] = (not t["FH_is_" .. name] and t[name]) or Lookup(t.Base, name) or false end
	local orig = t["FH_orig_" .. name] or nil
	local function wrapper(self, ...)
		if self.FH_broken or not orig and not fn then return orig and orig(self, ...) end
		local ok, a, b, c = pcall(fn, orig, self, ...)
		if ok then return a, b, c end
		self.FH_broken = true
		FH.Print("%s:%s failed, this weapon is Z-City's again: %s", class, name, tostring(a))
		if FH.TestLog then FH.TestLog("  PATCH ERROR %s:%s %s", class, name, tostring(a)) end
		if CLIENT and FH.cl then FH.cl.held = false end
		if orig then return orig(self, ...) end
	end
	t[name] = wrapper
	t["FH_is_" .. name] = true
	-- weapons that exist already carry copies of their class's methods
	for _, e in ipairs(ents.FindByClass(class)) do e[name] = wrapper end
	return true
end

------------------------------------------------------------------------------------------
-- Hands: while the fists are raised and ours, a button holds a hand and nothing else.
------------------------------------------------------------------------------------------
local function PatchHands()
	local class = "weapon_hands_sh"
	if not weapons.GetStored(class) then return false end

	-- (lowered hands: Z-City raises them on the first press. Raised: no punch is played)
	P.Wrap(class, "PrimaryAttack", function(orig, self, ...)
		if FH.Applies(self:GetOwner(), self) then return end
		return orig(self, ...)
	end)

	P.Wrap(class, "Think", function(orig, self)
		local owner = self:GetOwner()
		if not FH.Applies(owner, self) then return orig(self) end
		-- What Z-City's Think does for raised fists, without its block (a guard here is where the
		-- hands are, not a state) and without the block's sound and view kick.
		self.Checking = math.max((self.Checking or 0) - FrameTime(), 0)
		if owner:GetNWBool("TauntHolsterWeapons", false) then return orig(self) end
		if self:GetBlocking() then self:SetBlocking(false) end
		self.blockSound = nil
		if owner:KeyDown(IN_SPEED) then
			self:SetNextDown(CurTime() + 1)
			self:SetFists(false)
			return
		end
		if SERVER then
			if self:GetHoldType() ~= C.HoldType then self:SetHoldType(C.HoldType) end
			if FH.Contact and FH.Contact.Think then FH.Contact.Think(owner, self) end
		end
	end)

	if CLIENT then
		P.Wrap(class, "SetHandPos", function(orig, self, ...)
			local pf = FH.PerfCl
			if not pf then return FH.Render.FistsSetHandPos(orig, self, ...) end
			local t0 = SysTime()
			FH.Render.FistsSetHandPos(orig, self, ...)
			pf.hands, pf.handsN = pf.hands + SysTime() - t0, pf.handsN + 1
		end)
	end
	return true
end

------------------------------------------------------------------------------------------
-- Tools (crowbar, axes): no timed attack and no block while the weapon is ours. Z-City's Think
-- goes on running: it drops the weapon from a stunned hand, knows about lost arms, and finds no
-- attack to carry on with, because none was started.
------------------------------------------------------------------------------------------
local function UseHeld(owner)
	return hg and hg.KeyDown and hg.KeyDown(owner, IN_USE)
end

local function PatchTool(class)
	if not weapons.GetStored(class) then return false end
	local prof = C.Weapons[class]

	P.Wrap(class, "PrimaryAttack", function(orig, self, ...)
		local owner = self:GetOwner()
		if not FH.Applies(owner, self) then return orig(self, ...) end
		-- What Z-City does with this tool when USE is held with the button (the crowbar on a
		-- locked door) stays; the attack it would go on to when there is no door does not happen.
		if prof.useAction and orig and UseHeld(owner) then
			local real = self.BaseClass
			self.BaseClass = setmetatable({ PrimaryAttack = function() end }, { __index = real })
			local ok, err = pcall(orig, self, ...)
			self.BaseClass = real
			if not ok then error(err, 0) end
		end
	end)

	P.Wrap(class, "SecondaryAttack", function(orig, self, ...)
		local owner = self:GetOwner()
		if not FH.Applies(owner, self) then return orig(self, ...) end
		-- (a blade's own use on a taped or nailed door, with USE held, stays)
		if UseHeld(owner) and self.CutDuct then self:CutDuct() end
	end)

	P.Wrap(class, "CanBlock", function(orig, self, ...)
		if FH.Applies(self:GetOwner(), self) then return false end
		if orig then return orig(self, ...) end
		return true
	end)

	P.Wrap(class, "Think", function(orig, self, ...)
		local owner = self:GetOwner()
		local ours = FH.Applies(owner, self) ~= nil
		-- The body under the arms. Z-City's Think sets the weapon's hold type from its HoldType
		-- every time; some of these weapons have one that turns the trunk and cocks an arm (for
		-- an animated swing). With the trunk turned the shoulders are not where the hands are
		-- worked out from, and the first-person camera, which sits in the head, is somewhere else
		-- again (run fh8). While the weapon is ours its HoldType is the plain one.
		if ours then
			if self.HoldType ~= C.HoldType then self.FH_hold, self.HoldType = self.HoldType, C.HoldType end
		elseif self.FH_hold then
			self.HoldType, self.FH_hold = self.FH_hold, nil
		end
		if orig then orig(self, ...) end
		if SERVER and ours and FH.Contact and FH.Contact.Think then FH.Contact.Think(owner, self) end
	end)

	if CLIENT then
		P.Wrap(class, "SetHandPos", function(orig, self, ...)
			local pf = FH.PerfCl
			if not pf then return FH.Render.ToolSetHandPos(orig, self, ...) end
			local t0 = SysTime()
			FH.Render.ToolSetHandPos(orig, self, ...)
			pf.hands, pf.handsN = pf.hands + SysTime() - t0, pf.handsN + 1
		end)
		P.Wrap(class, "DrawWorldModel2", function(orig, self, ...)
			local pf = FH.PerfCl
			if not pf then return FH.Render.ToolDraw(orig, self, ...) end
			local t0 = SysTime()
			FH.Render.ToolDraw(orig, self, ...)
			pf.prop, pf.propN = pf.prop + SysTime() - t0, pf.propN + 1
		end)
		P.Wrap(class, "Camera", function(orig, self, ...) return FH.Render.ToolCamera(orig, self, ...) end)
	end
	return true
end

function P.Apply()
	if not weapons or not weapons.GetStored then return end
	local n = 0
	if PatchHands() then n = n + 1 end
	for class, prof in pairs(C.Weapons) do
		if prof.kind == "tool" and PatchTool(class) then n = n + 1 end
	end
	P.count = n
	return n
end

hook.Add("InitPostEntity", "FH_Patch", function() P.Apply() end)
hook.Add("HomigradRun", "FH_Patch", function() timer.Simple(0, P.Apply) end)
-- (a Lua refresh of this file, or of the weapon's own)
timer.Simple(0, function() P.Apply() end)
hook.Add("OnReloaded", "FH_Patch", function() timer.Simple(0.1, P.Apply) end)
