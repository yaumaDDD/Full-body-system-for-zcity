-- Client: a tool as it is seen. The prop is drawn where the simulated weapon is, the hands are
-- closed round the handle at the places the simulation grips it, and the arms follow the hands
-- (cl_render.lua). Nothing of Z-City's animated model is shown: it has no attack to play.

FreeHand.NoJIT()
local FH = FreeHand
local C, M, B, W = FH.Config, FH.Math, FH.Body, FH.Weapon
local R = FH.Render
local sqrt, abs = math.sqrt, math.abs

------------------------------------------------------------------------------------------
-- Where a prop's handle lies in its own model.
--
-- A weapon of the simulation is a bar along its x axis from the butt, with its blade (or hook)
-- toward y. A model is whatever its maker made it: along any axis, about any origin (some are
-- built round the hand bone they are meant to hang from). The frame is worked out from the
-- model's own triangles: the handle is the direction the surface is spread out along most, the
-- head is the end where it stands out furthest from that line, and the blade's side is where it
-- stands out to there. Done once for a model.
------------------------------------------------------------------------------------------
local frames = {}

local function FromBounds(path)
	-- (no triangles to be had: the longest side of the box, from its lower end)
	local m = ClientsideModel(path)
	local mins, maxs = Vector(-1, -1, -10), Vector(1, 1, 10)
	if IsValid(m) then mins, maxs = m:GetModelBounds() m:Remove() end
	local d = maxs - mins
	local f = { guess = true }
	local c = (mins + maxs) * 0.5
	if d.x >= d.y and d.x >= d.z then
		f.x, f.y, f.len, f.o = Vector(1, 0, 0), Vector(0, 1, 0), d.x, Vector(mins.x, c.y, c.z)
	elseif d.y >= d.z then
		f.x, f.y, f.len, f.o = Vector(0, 1, 0), Vector(1, 0, 0), d.y, Vector(c.x, mins.y, c.z)
	else
		f.x, f.y, f.len, f.o = Vector(0, 0, 1), Vector(1, 0, 0), d.z, Vector(c.x, c.y, mins.z)
	end
	f.z = f.x:Cross(f.y)
	return f
end

function R.ModelFrame(path)
	local f = frames[path]
	if f then return f end
	util.PrecacheModel(path)
	local meshes = util.GetModelMeshes(path)
	local tris, verts = {}, {}
	local total, mean = 0, Vector(0, 0, 0)
	for _, mesh in ipairs(meshes or {}) do
		local t = mesh.triangles
		if t then
			for i = 1, #t - 2, 3 do
				local a, b, c = t[i].pos, t[i + 1].pos, t[i + 2].pos
				local area = (b - a):Cross(c - a):Length() * 0.5
				verts[#verts + 1], verts[#verts + 2], verts[#verts + 3] = a, b, c
				if area > 1e-6 then
					local cen = (a + b + c) / 3
					tris[#tris + 1] = { cen, area }
					total = total + area
					mean = mean + cen * area
				end
			end
		end
	end
	if total < 1e-3 or #tris < 4 then
		f = FromBounds(path)
		frames[path] = f
		return f
	end
	mean = mean / total
	-- how the surface is spread about its middle (a symmetric 3 x 3)
	local xx, xy, xz, yy, yz, zz = 0, 0, 0, 0, 0, 0
	for _, t in ipairs(tris) do
		local d, w = t[1] - mean, t[2]
		xx, xy, xz = xx + w * d.x * d.x, xy + w * d.x * d.y, xz + w * d.x * d.z
		yy, yz, zz = yy + w * d.y * d.y, yz + w * d.y * d.z, zz + w * d.z * d.z
	end
	-- the direction it is spread along most: multiply a vector by that matrix until it stops turning
	local ax = Vector(0.577, 0.577, 0.577)
	for _ = 1, 40 do
		ax = Vector(xx * ax.x + xy * ax.y + xz * ax.z, xy * ax.x + yy * ax.y + yz * ax.z, xz * ax.x + yz * ax.y + zz * ax.z)
		ax:Normalize()
	end
	-- its two ends (the outermost corners, not the middles of the outermost triangles)
	local tmin, tmax = math.huge, -math.huge
	for _, v in ipairs(verts) do
		local s = (v - mean):Dot(ax)
		tmin, tmax = math.min(tmin, s), math.max(tmax, s)
	end
	local len = tmax - tmin
	-- the handle's own line: the middle of the surface between a sixth and a half of the way up
	-- (looked for from both ends: which one is the butt is not known yet)
	local function Offset(from, to)
		local sum, w = Vector(0, 0, 0), 0
		for _, t in ipairs(tris) do
			local d = t[1] - mean
			local s = d:Dot(ax)
			if s >= from and s <= to then sum, w = sum + (d - ax * s) * t[2], w + t[2] end
		end
		return w > 0 and sum / w or Vector(0, 0, 0)
	end
	-- how far the surface stands out from the middle line at each end
	local function Out(from, to, off)
		local sum, far = Vector(0, 0, 0), 0
		for _, t in ipairs(tris) do
			local d = t[1] - mean
			local s = d:Dot(ax)
			if s >= from and s <= to then
				local r = d - ax * s - off
				sum = sum + r * t[2]
				far = far + r:Length() * t[2]
			end
		end
		return far, sum
	end
	local off = Offset(tmin + len * 0.3, tmax - len * 0.3)
	local farLo = Out(tmin, tmin + len * 0.25, off)
	local farHi = Out(tmax - len * 0.25, tmax, off)
	if farLo > farHi then ax, tmin, tmax = -ax, -tmax, -tmin end
	-- The head is heavy with surface and pulls that direction toward itself (the hatchet's came
	-- out 6 degrees off its handle, run fh8). The handle's own direction: the same again, over
	-- the handle alone, about its own middle.
	do
		local hm, hw = Vector(0, 0, 0), 0
		for _, t in ipairs(tris) do
			local s = (t[1] - mean):Dot(ax)
			if s <= tmin + len * 0.6 then hm, hw = hm + t[1] * t[2], hw + t[2] end
		end
		if hw > total * 0.08 then
			hm = hm / hw
			xx, xy, xz, yy, yz, zz = 0, 0, 0, 0, 0, 0
			for _, t in ipairs(tris) do
				local s = (t[1] - mean):Dot(ax)
				if s <= tmin + len * 0.6 then
					local d, w = t[1] - hm, t[2]
					xx, xy, xz = xx + w * d.x * d.x, xy + w * d.x * d.y, xz + w * d.x * d.z
					yy, yz, zz = yy + w * d.y * d.y, yz + w * d.y * d.z, zz + w * d.z * d.z
				end
			end
			local h = Vector(ax.x, ax.y, ax.z)
			for _ = 1, 40 do
				h = Vector(xx * h.x + xy * h.y + xz * h.z, xy * h.x + yy * h.y + yz * h.z, xz * h.x + yz * h.y + zz * h.z)
				h:Normalize()
			end
			-- (only if it is the same line a little straighter, not some other feature)
			if h:Dot(ax) > 0.94 then
				ax = h
				tmin, tmax = math.huge, -math.huge
				for _, v in ipairs(verts) do
					local s = (v - mean):Dot(ax)
					tmin, tmax = math.min(tmin, s), math.max(tmax, s)
				end
				len = tmax - tmin
			end
		end
	end
	off = Offset(tmin + len * 0.15, tmin + len * 0.55)
	local _, side = Out(tmax - len * 0.25, tmax, off)
	side = side - ax * side:Dot(ax)
	if side:Length() < total * 0.002 then
		-- (a head that stands out to no side: any direction across)
		side = ax:Cross(Vector(0, 0, 1))
		if side:Length() < 0.1 then side = ax:Cross(Vector(0, 1, 0)) end
	end
	side:Normalize()
	f = { x = ax, y = side, z = ax:Cross(side), len = len, o = mean + off + ax * tmin, tris = #tris }
	frames[path] = f
	return f
end

------------------------------------------------------------------------------------------
-- A pair of closed hands to take fingers from: Z-City's fists use the game's own model of two
-- arms, whose hands a sequence closes. One copy, posed once, serves every hand that is closed
-- round nothing or round a handle.
------------------------------------------------------------------------------------------
local fistModel
function R.ClosedHands()
	if not IsValid(fistModel) then
		fistModel = ClientsideModel("models/weapons/c_arms.mdl")
		if not IsValid(fistModel) then return nil end
		fistModel:SetNoDraw(true)
		local seq = fistModel:LookupSequence("fists_draw")
		if seq and seq >= 0 then fistModel:SetSequence(seq) end
		fistModel:SetCycle(1)
		fistModel.FH_frame = -1
	end
	-- (posed until its fingers have been read once: cl_render.lua keeps them from then on)
	local rel = fistModel.FH_rel
	if not (rel and rel[1] and rel[2]) and fistModel.FH_frame ~= FrameNumber() then
		fistModel.FH_frame = FrameNumber()
		fistModel:SetCycle(1)
		fistModel:SetupBones()
	end
	return fistModel
end

------------------------------------------------------------------------------------------
-- The hands on the handle.
------------------------------------------------------------------------------------------
local GRIP_OUT, GRIP_PALM = 3.0, 1.1      -- from the wrist to the middle of what a closed hand holds [M: the citizen's hand]

-- The hand bone's place and attitude for a hand that holds the handle at g (world), the handle
-- pointing along a (toward the head). Returns the wrist's position and the Angle.
local function GripPose(i, ply, bones, gx, gy, gz, ax, ay, az, fx, fy, fz, lx, ly, lz, ux, uy, uz, tk, rec)
	local b = bones[i]
	local len = ply:BoneLength(b.fore)
	if not len or len <= 0 then len = 12 end
	-- (the shoulder first: the arm is taken from where its joint will be)
	R.Shoulder(ply, b, i, gx, gy, gz, len, rec)
	local upM = ply:GetBoneMatrix(b.up)
	if not upM then return nil end
	local s = upM:GetTranslation()
	-- where the forearm comes from (the elbow as it was last drawn, turned on no faster than an elbow goes)
	local qx, qy, qz, turn
	if rec then qx, qy, qz, turn = R.LastPole(rec, i) end
	local ex, ey, ez = B.Elbow(i, s.x, s.y, s.z, gx, gy, gz, fx, fy, fz, lx, ly, lz, ux, uy, uz, len, len, tk[1], tk[2], tk[3], tk[4], tk[5], qx, qy, qz, turn)
	local px, py, pz = M.Norm(gx - ex, gy - ey, gz - ez)
	-- the hand's own axes (measured, run fh1): x toward the knuckles, y out of its back, z across;
	-- a handle runs through a closed hand along z, and comes out at the thumb on -z for the right
	-- hand, on +z for the left
	local zs = i == 2 and -1 or 1
	local k = px * ax + py * ay + pz * az
	local xx, xy, xz, xl = M.Norm(px - ax * k, py - ay * k, pz - az * k)
	if xl < 0.05 then
		-- (the forearm along the handle: the hand turns toward the front)
		local kf = fx * ax + fy * ay + fz * az
		xx, xy, xz = M.Norm(fx - ax * kf, fy - ay * kf, fz - az * kf)
	end
	-- The wrist. With the hand's knuckles as near the forearm's line as the handle lets them,
	-- the wrist is bent sideways by as much as the forearm is out of square with the handle:
	-- up to a right angle, where the forearm lies along the handle (47 degrees on average over
	-- everything the mouse can ask, tools/fhsim/t_feel.lua). A wrist goes about 60 degrees
	-- toward the little finger with a handle in the fist, the way a blade is pointed, and
	-- about 25 the other way. Past that the hand is turned back toward its forearm and the
	-- handle lies askew in the fist by what is left over: a loosened grip, not a broken wrist.
	local bd = C.Body
	local bend = math.deg(math.asin(M.Clamp(k, -1, 1)))
	local kept = M.Clamp(bend, -bd.wristBack, bd.wristFwd)
	local hx, hy, hz = ax, ay, az
	if kept ~= bend then
		local t = math.rad(bend - kept)
		local c, s = math.cos(t), math.sin(t)
		xx, xy, xz, hx, hy, hz = xx * c + ax * s, xy * c + ay * s, xz * c + az * s, ax * c - xx * s, ay * c - xy * s, az * c - xz * s
	end
	local zx, zy, zz = hx * zs, hy * zs, hz * zs
	local yx, yy, yz = M.Cross(zx, zy, zz, xx, xy, xz)
	local wx, wy, wz = gx - xx * GRIP_OUT + yx * GRIP_PALM, gy - xy * GRIP_OUT + yy * GRIP_PALM, gz - xz * GRIP_OUT + yz * GRIP_PALM
	return wx, wy, wz, M.Ang(xx, xy, xz, zx, zy, zz)
end

-- A tool's SetHandPos while it is ours.
function R.ToolSetHandPos(orig, self, noset)
	local ply = self:GetOwner()
	local rs = IsValid(ply) and FH.RenderHands(ply)
	if not rs or not rs.tool or not hg or not hg.bone_apply_matrix then return orig(self, noset) end
	R.HookIK()
	self.rhandik, self.lhandik = false, false
	if not ply.shouldTransmit or ply.NotSeen then return end
	local bones = R.Bones(ply)
	if not bones.okay then return orig(self, noset) end
	local rec = R.last[ply]
	if not rec then rec = { pole = {}, hand = {} } R.last[ply] = rec end
	ply.rhold = ply:GetBoneMatrix(bones[2].hand)
	ply.lhold = ply:GetBoneMatrix(bones[1].hand)
	local fx, fy, fz, lx, ly, lz, ux, uy, uz = R.DrawnFrame(rs)
	local tk = R.DrawnTrunk(ply, rs)
	local w = rs.w
	local ax, ay, az = M.QRot(w.qw, w.qx, w.qy, w.qz, 1, 0, 0)
	local closed = R.ClosedHands()
	for i = 2, 1, -1 do
		local h = rs.h[i]
		local m
		if i == 2 or h.grip then
			local wx, wy, wz, ang = GripPose(i, ply, bones, h.x, h.y, h.z, ax, ay, az, fx, fy, fz, lx, ly, lz, ux, uy, uz, tk, rec)
			if wx then m = R.PlaceHand(ply, ply, i, bones, wx, wy, wz, fx, fy, fz, lx, ly, lz, ux, uy, uz, rec, tk, ang, closed) end
		elseif hg.CanUseLeftHand(ply) then
			-- the free hand of a one-handed grip is a fist
			m = R.PlaceHand(ply, ply, i, bones, h.x, h.y, h.z, fx, fy, fz, lx, ly, lz, ux, uy, uz, rec, tk, nil, closed)
		end
		if i == 2 then self.rhandik = m and true or false else self.lhandik = m and true or false end
	end
end

------------------------------------------------------------------------------------------
-- The prop.
------------------------------------------------------------------------------------------
local function Prop(self, path)
	local p = self.FH_prop
	if IsValid(p) and p:GetModel() == path then return p end
	if IsValid(p) then p:Remove() end
	p = ClientsideModel(path)
	if not IsValid(p) then return nil end
	p:SetNoDraw(true)
	self.FH_prop = p
	self:CallOnRemove("FH_prop", function() if IsValid(p) then p:Remove() end end)
	return p
end

-- Where the prop goes for a weapon at (COM x, y, z; attitude q): its origin and Angle.
function R.PropTransform(prof, fr, x, y, z, qw, qx, qy, qz)
	local ax, ay, az = M.QRot(qw, qx, qy, qz, 1, 0, 0)
	local ex, ey, ez = M.QRot(qw, qx, qy, qz, 0, 1, 0)
	local zx, zy, zz = M.Cross(ax, ay, az, ex, ey, ez)
	local s = prof.u.length / fr.len
	-- the model's own x and z axes, said in the weapon's
	local X, Y, Z = fr.x, fr.y, fr.z
	local fwx, fwy, fwz = ax * X.x + ex * Y.x + zx * Z.x, ay * X.x + ey * Y.x + zy * Z.x, az * X.x + ez * Y.x + zz * Z.x
	local upx, upy, upz = ax * X.z + ex * Y.z + zx * Z.z, ay * X.z + ey * Y.z + zy * Z.z, az * X.z + ez * Y.z + zz * Z.z
	-- the butt in the world, and from it back to the model's origin
	local u = prof.u
	local bx, by, bz = x - ax * u.com, y - ay * u.com, z - az * u.com
	local o = fr.o
	local ox, oy, oz = o:Dot(X) * s, o:Dot(Y) * s, o:Dot(Z) * s
	return Vector(bx - ax * ox - ex * oy - zx * oz, by - ay * ox - ey * oy - zy * oz, bz - az * ox - ez * oy - zz * oz), M.Ang(fwx, fwy, fwz, upx, upy, upz), s
end

-- A tool's DrawWorldModel2 while it is ours.
function R.ToolDraw(orig, self)
	local ply = self:GetOwner()
	local rs = IsValid(ply) and FH.RenderHands(ply)
	if not rs or not rs.tool then return orig(self) end
	-- (Z-City's own animated model stays what other code expects it to be: there, and not drawn)
	if not IsValid(self.worldModel) and self.GetWM then self.worldModel = self:GetWM() end
	if IsValid(self.worldModel) then self.worldModel:SetNoDraw(true) end
	if not ply.shouldTransmit or ply.NotSeen then return end
	local prof = rs.prof
	local prop = Prop(self, prof.model.path)
	if not prop then return end
	local fr = R.ModelFrame(prof.model.path)
	local w = rs.w
	local pos, ang, scale = R.PropTransform(prof, fr, w.x, w.y, w.z, w.qw, w.qx, w.qy, w.qz)
	prop:SetModelScale(scale)
	prop:SetRenderOrigin(pos)
	prop:SetRenderAngles(ang)
	prop:SetPos(pos)
	prop:SetAngles(ang)
	prop:SetupBones()
	prop:DrawModel()
	self.FH_drawn = FrameNumber()
	if self.DrawPostWorldModel then self:DrawPostWorldModel() end
end

-- A tool's Camera while it is ours: the eye as it is, with no animated model to sway it.
function R.ToolCamera(orig, self, eyePos, eyeAng, view, vellen)
	local ply = self:GetOwner()
	if not (IsValid(ply) and FH.Applies(ply, self)) then return orig(self, eyePos, eyeAng, view, vellen) end
	view.origin = eyePos
	view.angles = eyeAng
	return view
end

------------------------------------------------------------------------------------------
-- Developer drawing (fh_debug 2): the simulated weapon as a line with its samples.
------------------------------------------------------------------------------------------
local colBar, colEdge, colGrip = Color(255, 220, 60), Color(255, 80, 80), Color(90, 255, 120)
hook.Add("PostDrawTranslucentRenderables", "FH_DebugTool", function(depth, sky)
	if sky or C.cv.debug:GetInt() < 2 then return end
	render.SetColorMaterialIgnoreZ()
	for _, ply in ipairs(player.GetAll()) do
		local rs = FH.RenderHands(ply)
		if rs and rs.tool then
			local w, prof = rs.w, rs.prof
			local ax, ay, az = M.QRot(w.qw, w.qx, w.qy, w.qz, 1, 0, 0)
			local ex, ey, ez = M.QRot(w.qw, w.qx, w.qy, w.qz, 0, 1, 0)
			local u = prof.u
			local butt = Vector(w.x - ax * u.com, w.y - ay * u.com, w.z - az * u.com)
			local tip = butt + Vector(ax, ay, az) * u.length
			render.DrawLine(butt, tip, colBar, false)
			for _, s in ipairs(prof.usamples) do
				local p = butt + Vector(ax, ay, az) * s.at + Vector(ex, ey, ez) * s.off
				render.DrawSphere(p, s.r, 6, 6, s.kind == "edge" and colEdge or colBar)
			end
			render.DrawSphere(Vector(rs.h[2].x, rs.h[2].y, rs.h[2].z), 0.6, 6, 6, colGrip)
			if rs.h[1].grip then render.DrawSphere(Vector(rs.h[1].x, rs.h[1].y, rs.h[1].z), 0.6, 6, 6, colGrip) end
		end
	end
end)
