-- Client: what a player can set, said plainly and in one place.
--
--   fh_help      prints the controls as they are bound now, and every setting with its value
--   fh_menu      a panel with the same (also under Utilities in the spawn menu, where the
--                gamemode has one)
--   fh_defaults  puts the player's own settings back to what they were
--   a hint       which key holds which arm, for a few seconds when a weapon of the module is
--                taken in hand for the first time (fh_hints 0: never)
--
-- Nothing in here is needed by the simulation: the settings are console variables
-- (sh_config.lua), read and made safe in one function (C.Prefs).

local FH = FreeHand
local C, S = FH.Config, FH.Sim

-- A key of the settings as the player knows it: the button its command is bound to.
local BIND = { attack = "+attack", attack2 = "+attack2", walk = "+walk", reload = "+reload", zoom = "+zoom", alt1 = "+alt1", alt2 = "+alt2", duck = "+duck", speed = "+speed", use = "+use" }
local NICE = { MOUSE1 = "LEFT MOUSE BUTTON", MOUSE2 = "RIGHT MOUSE BUTTON", MOUSE3 = "MIDDLE MOUSE BUTTON", MOUSE4 = "MOUSE BUTTON 4", MOUSE5 = "MOUSE BUTTON 5" }
local function KeyName(key)
	local b = input.LookupBinding(BIND[key] or "", true)
	if not b then return string.upper(key) .. " (no key bound to " .. (BIND[key] or key) .. ")" end
	b = string.upper(b)
	return NICE[b] or b
end
FH.KeyName = KeyName

-- The player's own settings, in the order they are shown. { variable, name, what it does }
local OWN = {
	{ "fh_bind_right_arm", "Right arm", "the key that holds the right arm" },
	{ "fh_bind_left_arm", "Left arm", "the key that holds the left arm" },
	{ "fh_bind_reach", "Reach", "held with an arm: mouse forward and back is reach" },
	{ "fh_bind_grip", "Second hand", "takes the second hand off the weapon or puts it back" },
	{ "fh_sensitivity", "Arm sensitivity", "how far a hand goes for a movement of the mouse (0.2 to 4)" },
	{ "fh_smoothing", "Smoothing", "0: the hand follows the mouse at once; 1: steadier and later (0 to 1)" },
	{ "fh_reach", "Arm reach", "how far the arms stretch, as a share of their length (0.85 to 1)" },
	{ "fh_camera_follow", "Camera follow", "how much the view turns after a held hand that leaves the picture (0: never, to 1)" },
	{ "fh_invert_y", "Invert up and down", "1: mouse forward lowers the hand" },
	{ "fh_hints", "Show the controls", "1: for a few seconds when a weapon of the module is taken in hand" },
}
-- For everybody on the server.
local ALL = {
	{ "fh_enabled", "FreeHand melee", "0: hands, crowbar and axes are Z-City's own again" },
	{ "fh_strength", "Arm strength", "swing responsiveness: how hard the arms pull (0.25 to 3)" },
	{ "fh_weapon_inertia", "Weapon inertia", "the weapons' weight, multiplied: slower to start and to stop, harder where it lands (0.5 to 2)" },
	{ "fh_damage", "Damage", "multiplies what a blow does (0 to 5)" },
	{ "fh_knockout", "Knockout", "multiplies how much a blow to the head counts (0 to 5)" },
}

local function Controls()
	local p = S.Prefs(LocalPlayer())
	return {
		{ KeyName(p.right), "hold: the mouse moves the RIGHT arm" },
		{ KeyName(p.left), "hold: the mouse moves the LEFT arm" },
		{ "both", "both arms together" },
		{ KeyName(p.depth), "with an arm held: mouse forward and back is reach" },
		{ KeyName(p.grip), "second hand off the weapon, or back on" },
		{ "no arm held", "the mouse looks around, as always" },
	}, p
end
FH.Controls = Controls

-- Says so when a setting was not understood and what is used in its place.
local function Complain()
	local _, p = Controls()
	if p.clash then
		FH.Print("two of the four keys (right arm, left arm, reach, second hand) are the same key: the defaults are used (right arm: %s, left arm: %s, reach: %s, second hand: %s)", C.Defaults.right, C.Defaults.left, C.Defaults.depth, C.Defaults.grip)
	elseif p.unknown then
		FH.Print("a key setting is not one of: %s. Its default is used. (fh_help shows what is in use.)", table.concat(C.KeyOrder, ", "))
	end
end
for _, name in ipairs({ "fh_bind_right_arm", "fh_bind_left_arm", "fh_bind_reach", "fh_bind_grip" }) do
	cvars.AddChangeCallback(name, function() timer.Create("FH_Complain", 0.1, 1, Complain) end, "FH_Menu")
end

concommand.Add("fh_help", function()
	local list = Controls()
	FH.Print("controls (hands, crowbar, axes):")
	for _, e in ipairs(list) do MsgN(string.format("    %-26s %s", e[1], e[2])) end
	FH.Print("your settings (fh_menu shows the same as a panel; fh_defaults puts them back):")
	for _, e in ipairs(OWN) do
		local cv = GetConVar(e[1])
		MsgN(string.format("    %-20s = %-8s %s", e[1], cv and cv:GetString() or "?", e[3]))
	end
	FH.Print("for everybody (set by the host or a superadmin):")
	for _, e in ipairs(ALL) do
		local cv = GetConVar(e[1])
		MsgN(string.format("    %-20s = %-8s %s", e[1], cv and cv:GetString() or "?", e[3]))
	end
	Complain()
end, nil, "FreeHand: the controls as they are bound now, and every setting")

concommand.Add("fh_defaults", function()
	for _, e in ipairs(OWN) do
		local cv = GetConVar(e[1])
		if cv then RunConsoleCommand(e[1], cv:GetDefault()) end
	end
	FH.Print("your settings are the defaults again")
end, nil, "FreeHand: puts the player's own settings back to their defaults")

------------------------------------------------------------------------------------------
-- The panel. One function fills a form; the spawn menu and fh_menu both use it.
------------------------------------------------------------------------------------------
-- (The game's skins disagree on whether a form is light or dark, and a form's own labels are
-- made for a light one: on Z-City's dark skin they could not be read, run fh51. The form is
-- painted here and its letters are light.)
local BACK, LIGHT = Color(38, 38, 42), Color(228, 228, 228)
local function Light(l)
	if IsValid(l) and l.SetTextColor then l:SetTextColor(LIGHT) end
	return l
end

local function Fill(form)
	form.Paint = function(_, w, h) draw.RoundedBox(4, 0, 0, w, h, BACK) end
	local list, p = Controls()
	local lines = {}
	for _, e in ipairs(list) do lines[#lines + 1] = e[1] .. ":  " .. e[2] end
	Light(form:Help(table.concat(lines, "\n")))

	local function Key(label, cv, now)
		local combo, l = form:ComboBox(label, nil)
		Light(l)
		for _, k in ipairs(C.KeyOrder) do combo:AddChoice(k .. "   (" .. KeyName(k) .. ")", k) end
		combo:SetValue(now .. "   (" .. KeyName(now) .. ")")
		combo.OnSelect = function(_, _, _, data) RunConsoleCommand(cv, data) end
	end
	-- the player's own: the slider and the variable are one
	local function Slider(label, cv, lo, hi)
		local s = form:NumSlider(label, cv, lo, hi, 2)
		Light(s.Label)
		return s
	end
	local function Box(label, cv) return Light(form:CheckBox(label, cv)) end
	-- The server's: shown as they are, and written only when the player has moved them. (Tied
	-- to the variable, a slider writes it when the panel opens: every opening told the server's
	-- console that three variables had changed, run fh51.)
	local function ServerSlider(label, cv, lo, hi)
		local s = form:NumSlider(label, nil, lo, hi, 2)
		Light(s.Label)
		local c = GetConVar(cv)
		s:SetValue(c and c:GetFloat() or lo)
		s.OnValueChanged = function(_, v)
			timer.Create("FH_Menu_" .. cv, 0.3, 1, function()
				local now = GetConVar(cv)
				if now and math.abs(now:GetFloat() - v) > 0.004 then RunConsoleCommand(cv, string.format("%.2f", v)) end
			end)
		end
	end
	local function ServerBox(label, cv)
		local b = Light(form:CheckBox(label, nil))
		local c = GetConVar(cv)
		b:SetChecked(c and c:GetBool() or false)
		b.OnChange = function(_, on)
			local now = GetConVar(cv)
			if now and now:GetBool() ~= on then RunConsoleCommand(cv, on and "1" or "0") end
		end
	end

	Key("Right arm", "fh_bind_right_arm", p.right)
	Key("Left arm", "fh_bind_left_arm", p.left)
	Key("Reach (with an arm)", "fh_bind_reach", p.depth)
	Key("Second hand", "fh_bind_grip", p.grip)
	form:ControlHelp("A key is whatever the game has bound to that command. Four different keys are needed.")

	Slider("Arm sensitivity", "fh_sensitivity", 0.2, 4)
	form:ControlHelp("How far a hand goes for a movement of the mouse.")
	Slider("Smoothing", "fh_smoothing", 0, 1)
	form:ControlHelp("0: the hand follows the mouse at once. More: steadier, and later.")
	Slider("Arm reach", "fh_reach", 0.85, 1)
	form:ControlHelp("How far the arms stretch.")
	Slider("Camera follow", "fh_camera_follow", 0, 1)
	form:ControlHelp("How much the view turns after a held hand that leaves the picture. 0: never.")
	Box("Invert up and down", "fh_invert_y")
	Box("Show the controls when a weapon is taken in hand", "fh_hints")
	form:Button("Put my settings back to the defaults", "fh_defaults")

	Light(form:Help("For everybody on the server (the host or a superadmin sets these):"))
	ServerBox("FreeHand melee on", "fh_enabled")
	ServerSlider("Arm strength", "fh_strength", 0.25, 3)
	form:ControlHelp("Swing responsiveness: how hard the arms pull.")
	ServerSlider("Weapon inertia", "fh_weapon_inertia", 0.5, 2)
	form:ControlHelp("The weapons' weight, multiplied: slower to start and to stop, harder where it lands.")
	ServerSlider("Damage", "fh_damage", 0, 5)
end

local frame
concommand.Add("fh_menu", function()
	if IsValid(frame) then frame:Remove() frame = nil return end
	frame = vgui.Create("DFrame")
	frame:SetTitle("FreeHand melee: controls and settings")
	frame:SetSize(480, math.min(ScrH() - 60, 760))
	frame:Center()
	frame:MakePopup()
	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:Dock(FILL)
	local form = vgui.Create("DForm", scroll)
	form:Dock(TOP)
	form:SetName("Hands, crowbar, axes")
	local ok, err = pcall(Fill, form)
	if not ok then FH.Print("the panel could not be filled: %s (fh_help prints the same)", tostring(err)) end
end, nil, "FreeHand: a panel with the controls and the settings")

hook.Add("PopulateToolMenu", "FH_Menu", function()
	spawnmenu.AddToolMenuOption("Utilities", "FreeHand", "fh_melee", "Melee controls", "", "", function(panel)
		if panel.ClearControls then panel:ClearControls() end
		local ok, err = pcall(Fill, panel)
		if not ok then FH.Print("the panel could not be filled: %s", tostring(err)) end
	end)
end)

------------------------------------------------------------------------------------------
-- The hint.
------------------------------------------------------------------------------------------
local HINT_SECONDS = 10
local hintFont, hintSize
local function HintFont()
	local size = math.Clamp(math.floor(ScrH() / 46), 16, 40)
	if size ~= hintSize then
		hintSize = size
		hintFont = "FH_Hint" .. size
		surface.CreateFont(hintFont, { font = "Tahoma", size = size, weight = 700, antialias = true })
	end
	return hintFont, size
end
local shown = {}                 -- what was shown this session: by kind of weapon and the keys in use
local hintUntil, hintLines, nextLook = 0, nil, 0
FH.Hint = { shows = 0 }
function FH.Hint.Again() shown = {} end

local function Look()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	local prof = FH.Applies(lp)
	if not prof then return end
	local p = S.Prefs(lp)
	local tool = prof.kind == "tool"
	local key = (tool and "tool" or "fists") .. p.right .. p.left .. p.depth .. p.grip
	if shown[key] then return end
	shown[key] = true
	hintLines = {
		KeyName(p.right) .. "  hold: right arm      " .. KeyName(p.left) .. "  hold: left arm      both: both arms",
		KeyName(p.depth) .. "  with an arm held: reach" .. (tool and ("      " .. KeyName(p.grip) .. "  second hand on / off") or ""),
		"No arm held: the mouse looks around.      Settings: console, fh_menu",
	}
	hintUntil = RealTime() + HINT_SECONDS
	FH.Hint.shows = FH.Hint.shows + 1
end

hook.Add("HUDPaint", "FH_Hint", function()
	local now = RealTime()
	if now >= nextLook then
		nextLook = now + 0.3
		-- (not in a scene's pictures, unless the scene is about the hint)
		if C.cv.hints:GetBool() and (not FH.testRun or FH.testHint) then Look() end
	end
	if now >= hintUntil or not hintLines then return end
	if not C.cv.hints:GetBool() then hintUntil = 0 return end
	local a = math.Clamp((hintUntil - now) / 1.2, 0, 1) * 255
	local font, size = HintFont()
	local x, y = ScrW() * 0.5, ScrH() * 0.70
	for i, line in ipairs(hintLines) do
		draw.SimpleTextOutlined(line, font, x, y + (i - 1) * (size + 6), Color(240, 240, 240, a), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, a))
	end
end)
