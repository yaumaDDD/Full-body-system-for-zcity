-- Server: every fighter is stepped from the commands the server gets, and what comes of it is
-- sent to the clients. This is the simulation that counts: contacts, impacts and what they do are
-- worked out from these states and from no other.

local FH = FreeHand
local C, M, B, S = FH.Config, FH.Math, FH.Body, FH.Sim

util.AddNetworkString("fh_s")
util.AddNetworkString("fh_ev")
util.AddNetworkString("fh_o")

-- For test scenes: a function that says what a player's command would have said.
--   FH.TestInput[ply] = function(ply, cmdNumber) return { L, R, depth, grip, mx, my } end
FH.TestInput = FH.TestInput or setmetatable({}, { __mode = "k" })

-- What a player's arms have of their force now: less when Z-City's stamina is spent, less for a
-- moment after a blow to the head. The client steps its own hands with the same number, so it
-- is sent in steps (a sixteenth) and what is sent is what is used.
local function Strength(ply)
	return C.cv.strength:GetFloat() * ply:GetNW2Float("fh_str", 1)
end
FH.Strength = Strength

local function Condition(ply)
	local r = C.React
	local k = 1
	local org = ply.organism
	local sta = istable(org) and org.stamina
	if istable(sta) and tonumber(sta[1]) and tonumber(sta.max) and sta.max > 0 then
		local s = sta[1] / sta.max
		if s < r.tiredAt then k = r.tired + (1 - r.tired) * math.max(s, 0) / r.tiredAt end
	end
	if FH.React and FH.React.Weak then k = k * FH.React.Weak(ply) end
	return math.Round(k * 16) / 16
end

-- Four times a second: what swinging has cost, and what the arms have left.
timer.Create("FH_Condition", 0.25, 0, function()
	for ply, st in pairs(FH.states) do
		if IsValid(ply) and st.active then
			local org = ply.organism
			if st.work > 0 and istable(org) and istable(org.stamina) then
				local joules = st.work * FH.U2M * FH.U2M
				org.stamina.subadd = (org.stamina.subadd or 0) + joules * C.React.staminaPerJoule
			end
			st.work = 0
			local k = Condition(ply)
			if ply:GetNW2Float("fh_str", 1) ~= k then ply:SetNW2Float("fh_str", k) end
		end
	end
end)

local function Deactivate(ply, st)
	if not st.active then return end
	st.active = false
	st.ok = false
	st.gone = 6                 -- snapshots that still say so
end

hook.Add("StartCommand", "FH_Sim", function(ply, cmd)
	local st = FH.states[ply]
	local wep = ply:GetActiveWeapon()
	local prof = FH.Applies(ply, wep)
	if not prof then
		if st then Deactivate(ply, st) end
		return
	end
	st = st or FH.State(ply)
	-- (a bot's command says nothing about where it looks)
	local ang = ply:IsBot() and ply:EyeAngles() or cmd:GetViewAngles()
	local inp
	local test = FH.TestInput[ply]
	if test then
		local t = test(ply, cmd:CommandNumber()) or {}
		inp = S.Input(ply, 0, t.mx or 0, t.my or 0, t.yaw or ang.y, t.pitch or ang.p)
		inp.L, inp.R, inp.depth, inp.grip = t.L == true, t.R == true, t.depth == true, t.grip == true
	else
		inp = S.Input(ply, cmd:GetButtons(), cmd:GetMouseX(), cmd:GetMouseY(), ang.y, ang.p)
		-- (the mouse only counts while a hand is held: otherwise it turned the view)
		if not (inp.L or inp.R) then inp.mx, inp.my = 0, 0 end
	end
	local px, py, pz, vx, vy, vz, eyeZ = S.BodyOf(ply)
	local pf = FH.Perf
	local t0 = pf and SysTime()
	local ok, err = pcall(S.Step, st, prof, inp, px, py, pz, vx, vy, vz, eyeZ, engine.TickInterval(), Strength(ply))
	if pf then pf.step, pf.steps = pf.step + SysTime() - t0, pf.steps + 1 end
	if not ok then
		-- (a fault in here must not leave anybody with frozen hands: this weapon is Z-City's again)
		wep.FH_broken = true
		FH.Print("simulation error for %s with %s: %s", ply:Nick(), wep:GetClass(), tostring(err))
		if FH.TestLog then FH.TestLog("  SIM ERROR %s", tostring(err)) end
		Deactivate(ply, st)
		return
	end
	st.active = true
	st.wep = wep
	st.cmd = cmd:CommandNumber()
	st.inp = inp
	if FH.OnCmd then FH.OnCmd(ply, cmd, inp, st) end
end)

------------------------------------------------------------------------------------------
-- Snapshots for the clients: where each fighter's hands (and weapon) are, relative to the feet.
------------------------------------------------------------------------------------------
local function Q16(v) return math.Clamp(math.Round(v * 16), -32767, 32767) end

local tickN = 0
hook.Add("Tick", "FH_Net", function()
	tickN = tickN + 1
	if tickN % C.Sim.netEvery ~= 0 then return end
	local list = {}
	for _, ply in ipairs(player.GetAll()) do
		local st = FH.states[ply]
		if st and (st.active or (st.gone or 0) > 0) then
			if not st.active then st.gone = st.gone - 1 end
			-- (a fighter whose weapon went away between two commands)
			if st.active and not FH.Applies(ply) then Deactivate(ply, st) end
			list[#list + 1] = ply
			if #list >= 60 then break end
		end
	end
	if #list == 0 then return end
	net.Start("fh_s", true)
	net.WriteUInt(#list, 6)
	for _, ply in ipairs(list) do
		local st = FH.states[ply]
		net.WriteUInt(ply:EntIndex(), 8)
		net.WriteBool(st.active == true)
		if st.active then
			local tool = st.prof.kind == "tool" and st.w ~= nil
			net.WriteBool(tool)
			net.WriteUInt(st.cmd % 65536, 16)
			-- (the frame the hands were stepped in: elbows and wrists are drawn in it)
			net.WriteInt(math.Round(math.NormalizeAngle(st.yaw) * 100), 16)
			net.WriteInt(math.Round(math.Clamp(st.pitch, -90, 90) * 100), 16)
			for i = 1, 2 do
				local h = st.h[i]
				net.WriteInt(Q16(h.px - st.bx), 16) net.WriteInt(Q16(h.py - st.by), 16) net.WriteInt(Q16(h.pz - st.bz), 16)
				net.WriteBool(h.on) net.WriteBool(h.grip)
			end
			if tool then
				local w = st.w
				net.WriteInt(Q16(w.x - st.bx), 16) net.WriteInt(Q16(w.y - st.by), 16) net.WriteInt(Q16(w.z - st.bz), 16)
				net.WriteInt(math.Round(w.qw * 32767), 16) net.WriteInt(math.Round(w.qx * 32767), 16)
				net.WriteInt(math.Round(w.qy * 32767), 16) net.WriteInt(math.Round(w.qz * 32767), 16)
			end
		end
	end
	net.Broadcast()
end)

------------------------------------------------------------------------------------------
-- A player's own state back to that player.
--
-- The client steps its own hands and weapon from the commands it sends, and the server steps
-- them from the commands it gets: the same arithmetic, the same result, as long as nothing but
-- the commands goes in. But what the weapon runs into is not the same on both sides (another
-- fighter's weapon is known to the server alone, a body stands a little elsewhere for each),
-- a command can be lost, and the arms' strength changes on the server first. So the server says
-- what it had after a command, and the client, which remembers what it had after that command,
-- takes the difference (cl_input.lua).
------------------------------------------------------------------------------------------
local function SendOwn(ply, st)
	net.Start("fh_o", true)
	net.WriteUInt(st.cmd % 65536, 16)
	net.WriteBool(st.twoHand == true)
	for i = 1, 2 do
		local h = st.h[i]
		net.WriteBool(h.grip == true)
		net.WriteFloat(h.tf) net.WriteFloat(h.tl) net.WriteFloat(h.tu)
		net.WriteFloat(h.px - st.bx) net.WriteFloat(h.py - st.by) net.WriteFloat(h.pz - st.bz)
		net.WriteFloat(h.vx - st.bvx) net.WriteFloat(h.vy - st.bvy) net.WriteFloat(h.vz - st.bvz)
	end
	local w = st.prof.kind == "tool" and st.w or nil
	net.WriteBool(w ~= nil)
	if w then
		net.WriteFloat(w.x - st.bx) net.WriteFloat(w.y - st.by) net.WriteFloat(w.z - st.bz)
		net.WriteFloat(w.qw) net.WriteFloat(w.qx) net.WriteFloat(w.qy) net.WriteFloat(w.qz)
		net.WriteFloat(w.vx - st.bvx) net.WriteFloat(w.vy - st.bvy) net.WriteFloat(w.vz - st.bvz)
		net.WriteFloat(w.wx) net.WriteFloat(w.wy) net.WriteFloat(w.wz)
		net.WriteFloat(w.slide) net.WriteFloat(w.slideWant)
	end
	net.Send(ply)
end

hook.Add("Tick", "FH_Own", function()
	if tickN % C.Sim.ownEvery ~= 0 then return end
	for ply, st in pairs(FH.states) do
		if st.active and st.ok and IsValid(ply) and not ply:IsBot() then SendOwn(ply, st) end
	end
end)

hook.Add("PlayerDisconnected", "FH_Forget", function(ply) FH.states[ply] = nil end)
