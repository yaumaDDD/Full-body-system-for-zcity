-- Client: the mouse and the buttons of the local player.
--
-- A held button gives the mouse to a hand. While one is held the mouse no longer turns the view:
-- what it moved is added up here and sent to the server inside the command (the same two numbers
-- a command always carries for the mouse), so that the server steps the hands from exactly what
-- the client stepped them from. The local player's own hands are stepped here, once for every
-- command that is made, and never from a frame's time.

FreeHand.NoJIT()
local FH = FreeHand
local C, M, B, S = FH.Config, FH.Math, FH.Body, FH.Sim
FH.cl = FH.cl or {}
local cl = FH.cl
cl.accX, cl.accY = 0, 0
cl.held = false                 -- a hand is held (as of the last command)
cl.frozen = nil                 -- the view's angles while it is

-- For test scenes: what the buttons and the mouse would have said, per command.
--   cl.testInput = function(cmdNumber) return { L, R, depth, grip, mx, my } end
cl.testInput = nil

-- LOOK and SWING. With no arm held the mouse is the view's, as ever. While an arm is held the
-- mouse is that arm's and nothing of it reaches the view.
--
-- Z-City applies the mouse to the view itself (homigrad/fake/cl_fake.lua): its hook on
-- InputMouseApply hands the movement to everything hooked on "HG.InputMouseApply", in no order
-- that can be counted on, and several of those turn, tilt or sway the picture by it (the weight
-- of the weapon in the hands sways the view with the mouse, for one). Until phase 42 a held arm
-- took the mouse inside that second round, as one hook among them: whichever ran before it had
-- already seen the movement. It is taken before the round begins now: Z-City's own hook is
-- called with a mouse that stands still.
local function TakeMouse(x, y)
	-- (a scene is running: the mouse of whoever sits at the machine turns nothing; what the
	-- scene itself sends this way, cl.synth, is the mouse)
	if FH.testRun and not cl.synth then return 0, 0 end
	if not cl.held then return x, y end
	cl.accX, cl.accY = cl.accX + x, cl.accY + y
	return 0, 0
end

local inner, outer, inOuter
local function WrapMouse()
	local t = hook.GetTable().InputMouseApply
	local f = t and t.fakeCameraAngles
	if not isfunction(f) or f == outer then return end
	inner = f
	outer = function(cmd, x, y, ang)
		-- (cl.noWrap: as it was until phase 42, for a scene that compares)
		if cl.noWrap then return inner(cmd, x, y, ang) end
		x, y = TakeMouse(x or 0, y or 0)
		inOuter = true
		local a, b = inner(cmd, x, y, ang)
		inOuter = false
		return a, b
	end
	hook.Add("InputMouseApply", "fakeCameraAngles", outer)
end
FH.WrapMouse = WrapMouse
WrapMouse()
hook.Add("InitPostEntity", "FH_WrapMouse", WrapMouse)

-- (Where Z-City's hook is not there to be wrapped, or has been put back by a reload of its
-- file: taken in the second round, as before.)
hook.Add("HG.InputMouseApply", "FH_Mouse", function(t)
	if inOuter then return end
	t.x, t.y = TakeMouse(t.x or 0, t.y or 0)
end)

local band, bor, bnot = bit.band, bit.bor, bit.bnot
local band, bor, bnot = bit.band, bit.bor, bit.bnot

------------------------------------------------------------------------------------------
-- What was predicted, command by command, and the server's word on it (sv_main.lua, "A player's
-- own state back to that player").
------------------------------------------------------------------------------------------
local HIST = 128
cl.hist = cl.hist or {}
-- what is still to be made up to the eye: a correction moves the state at once and is drawn in
-- over a tenth of a second (cl_state.lua)
cl.fix = cl.fix or { h = { { 0, 0, 0 }, { 0, 0, 0 } }, w = { 0, 0, 0 } }
cl.fixes = 0

local function Record(st, n)
	local e = cl.hist[n % HIST]
	if not e then e = { h = { {}, {} }, w = {} } cl.hist[n % HIST] = e end
	e.cmd = n
	e.two = st.twoHand == true
	for i = 1, 2 do
		local h, d = st.h[i], e.h[i]
		d.grip = h.grip == true
		d.tf, d.tl, d.tu = h.tf, h.tl, h.tu
		d.x, d.y, d.z = h.px - st.bx, h.py - st.by, h.pz - st.bz
		d.vx, d.vy, d.vz = h.vx - st.bvx, h.vy - st.bvy, h.vz - st.bvz
	end
	local w = st.prof.kind == "tool" and st.w or nil
	e.tool = w ~= nil
	if w then
		local d = e.w
		d.x, d.y, d.z = w.x - st.bx, w.y - st.by, w.z - st.bz
		d.qw, d.qx, d.qy, d.qz = w.qw, w.qx, w.qy, w.qz
		d.vx, d.vy, d.vz = w.vx - st.bvx, w.vy - st.bvy, w.vz - st.bvz
		d.wx, d.wy, d.wz = w.wx, w.wy, w.wz
		d.slide, d.slideWant = w.slide, w.slideWant
	end
end

local sv = { h = { {}, {} }, w = {} }
net.Receive("fh_o", function()
	sv.cmd = net.ReadUInt(16)
	sv.two = net.ReadBool()
	for i = 1, 2 do
		local d = sv.h[i]
		d.grip = net.ReadBool()
		d.tf, d.tl, d.tu = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
		d.x, d.y, d.z = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
		d.vx, d.vy, d.vz = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
	end
	sv.tool = net.ReadBool()
	if sv.tool then
		local d = sv.w
		d.x, d.y, d.z = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
		d.qw, d.qx, d.qy, d.qz = net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
		d.vx, d.vy, d.vz = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
		d.wx, d.wy, d.wz = net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
		d.slide, d.slideWant = net.ReadFloat(), net.ReadFloat()
	end
	local lp = LocalPlayer()
	local st = IsValid(lp) and FH.states[lp]
	if not st or not st.active or not st.ok or not C.cv.predict:GetBool() or cl.noFix then return end
	-- what was predicted after that very command
	local e
	for _, c in pairs(cl.hist) do
		if c.cmd % 65536 == sv.cmd and (not e or c.cmd > e.cmd) then e = c end
	end
	if not e or (cl.lastCmd or 0) - e.cmd > HIST - 8 or e.tool ~= sv.tool or (sv.tool and not st.w) then return end
	local fixed = false
	-- which hands hold: the server's word, as it is
	if e.two ~= sv.two then st.twoHand = sv.two fixed = true end
	for i = 1, 2 do
		if e.h[i].grip ~= sv.h[i].grip then st.h[i].grip = sv.h[i].grip fixed = true end
	end
	-- everything else: the difference between what the server had then and what was predicted
	-- then is added to what is predicted now, and to what was predicted since
	local function Later(fn)
		for _, c in pairs(cl.hist) do if c.cmd > e.cmd then fn(c) end end
	end
	for i = 1, 2 do
		local a, b, h = e.h[i], sv.h[i], st.h[i]
		local dtf, dtl, dtu = b.tf - a.tf, b.tl - a.tl, b.tu - a.tu
		if math.abs(dtf) + math.abs(dtl) + math.abs(dtu) > 0.01 then
			h.tf, h.tl, h.tu = h.tf + dtf, h.tl + dtl, h.tu + dtu
			Later(function(c) local d = c.h[i] d.tf, d.tl, d.tu = d.tf + dtf, d.tl + dtl, d.tu + dtu end)
			fixed = true
		end
		-- (a hand on a handle is where the handle is: the weapon is put right, below)
		if not (sv.tool and (i == 2 or b.grip)) then
			local dx, dy, dz = b.x - a.x, b.y - a.y, b.z - a.z
			local dvx, dvy, dvz = b.vx - a.vx, b.vy - a.vy, b.vz - a.vz
			if math.abs(dx) + math.abs(dy) + math.abs(dz) > 0.03 or math.abs(dvx) + math.abs(dvy) + math.abs(dvz) > 1.5 then
				h.px, h.py, h.pz = h.px + dx, h.py + dy, h.pz + dz
				h.qx, h.qy, h.qz = h.qx + dx, h.qy + dy, h.qz + dz
				if h.kx then
					h.kx, h.ky, h.kz = h.kx + dx, h.ky + dy, h.kz + dz
					h.kqx, h.kqy, h.kqz = h.kqx + dx, h.kqy + dy, h.kqz + dz
				end
				h.vx, h.vy, h.vz = h.vx + dvx, h.vy + dvy, h.vz + dvz
				local f = cl.fix.h[i]
				f[1], f[2], f[3] = f[1] - dx, f[2] - dy, f[3] - dz
				Later(function(c)
					local d = c.h[i]
					d.x, d.y, d.z = d.x + dx, d.y + dy, d.z + dz
					d.vx, d.vy, d.vz = d.vx + dvx, d.vy + dvy, d.vz + dvz
				end)
				fixed = true
			end
		end
	end
	if sv.tool then
		local a, b, w = e.w, sv.w, st.w
		local dx, dy, dz = b.x - a.x, b.y - a.y, b.z - a.z
		local dvx, dvy, dvz = b.vx - a.vx, b.vy - a.vy, b.vz - a.vz
		local dwx, dwy, dwz = b.wx - a.wx, b.wy - a.wy, b.wz - a.wz
		-- the turn that takes the predicted attitude to the server's
		local rw, rx, ry, rz = M.QMul(b.qw, b.qx, b.qy, b.qz, a.qw, -a.qx, -a.qy, -a.qz)
		if rw < 0 then rw, rx, ry, rz = -rw, -rx, -ry, -rz end
		local ds, dsw = b.slide - a.slide, b.slideWant - a.slideWant
		if math.abs(dx) + math.abs(dy) + math.abs(dz) > 0.03 or math.abs(dvx) + math.abs(dvy) + math.abs(dvz) > 1.5
			or math.abs(dwx) + math.abs(dwy) + math.abs(dwz) > 0.05 or rw < 0.999999 or math.abs(ds) + math.abs(dsw) > 0.01 then
			w.x, w.y, w.z = w.x + dx, w.y + dy, w.z + dz
			w.px, w.py, w.pz = w.px + dx, w.py + dy, w.pz + dz
			w.vx, w.vy, w.vz = w.vx + dvx, w.vy + dvy, w.vz + dvz
			w.wx, w.wy, w.wz = w.wx + dwx, w.wy + dwy, w.wz + dwz
			w.qw, w.qx, w.qy, w.qz = M.QNorm(M.QMul(rw, rx, ry, rz, w.qw, w.qx, w.qy, w.qz))
			w.pqw, w.pqx, w.pqy, w.pqz = M.QNorm(M.QMul(rw, rx, ry, rz, w.pqw, w.pqx, w.pqy, w.pqz))
			w.slide, w.slideWant = w.slide + ds, w.slideWant + dsw
			local f = cl.fix.w
			f[1], f[2], f[3] = f[1] - dx, f[2] - dy, f[3] - dz
			Later(function(c)
				if not c.tool then return end
				local d = c.w
				d.x, d.y, d.z = d.x + dx, d.y + dy, d.z + dz
				d.vx, d.vy, d.vz = d.vx + dvx, d.vy + dvy, d.vz + dvz
				d.wx, d.wy, d.wz = d.wx + dwx, d.wy + dwy, d.wz + dwz
				d.qw, d.qx, d.qy, d.qz = M.QNorm(M.QMul(rw, rx, ry, rz, d.qw, d.qx, d.qy, d.qz))
				d.slide, d.slideWant = d.slide + ds, d.slideWant + dsw
			end)
			S.ToolHands(st, st.prof)
			fixed = true
		end
	end
	if fixed then cl.fixes = cl.fixes + 1 end
end)

hook.Add("CreateMove", "FH_Input", function(cmd)
	-- (extra samples of the mouse between two commands carry no command number)
	if cmd:CommandNumber() == 0 then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	-- (A scene is running: whoever sits at the machine is not one of its fighters. Their keys
	-- and buttons are taken out of the command before anything reads it; what the scene plays
	-- is put in below. In runs fh20 to fh36 a click, a key or a nudge of the mouse made single
	-- scenes fail that passed in the runs before and after.)
	if FH.testRun then
		cmd:ClearMovement()
		cmd:SetButtons(0)
	end
	-- (Z-City's hook wrapped still? looked at now and then: a reload of its file puts it back)
	if cmd:CommandNumber() % 64 == 0 then WrapMouse() end
	local st = FH.states[lp]
	local wep = lp:GetActiveWeapon()
	local prof = FH.Applies(lp, wep)
	if not prof then
		cl.held, cl.accX, cl.accY = false, 0, 0
		if st then st.active, st.ok = false, false end
		return
	end
	local buttons = cmd:GetButtons()
	local test = cl.testInput and cl.testInput(cmd:CommandNumber())
	if test then
		-- (as if the player had done it: the buttons and the mouse go into the command)
		local p, K = S.Prefs(lp), C.Keys
		buttons = band(buttons, bnot(bor(K[p.left], K[p.right], K[p.depth], K[p.grip])))
		if test.L then buttons = bor(buttons, K[p.left]) end
		if test.R then buttons = bor(buttons, K[p.right]) end
		if test.depth then buttons = bor(buttons, K[p.depth]) end
		if test.grip then buttons = bor(buttons, K[p.grip]) end
		-- (the buttons themselves, whatever they are set to hold; and a scene's legs)
		if test.buttons then buttons = bor(buttons, test.buttons) end
		if test.duck then buttons = bor(buttons, IN_DUCK) end
		if test.run then buttons = bor(buttons, IN_SPEED) end
		if test.fwd then
			cmd:SetForwardMove(test.fwd)
			buttons = bor(buttons, test.fwd > 0 and IN_FORWARD or IN_BACK)
		end
		cmd:SetButtons(buttons)
		if test.real then
			-- (A movement of the mouse sent the game's own way: through Z-City's hook on
			-- InputMouseApply and everything it hands the movement to, as the engine does
			-- with a real one. What an arm takes of it arrives in cl.accX as from a real mouse.)
			cl.synth = true
			hook.Run("InputMouseApply", cmd, test.real[1] or 0, test.real[2] or 0, cmd:GetViewAngles())
			cl.synth = false
		else
			cl.accX, cl.accY = test.mx or 0, test.my or 0
		end
	elseif FH.testRun then
		-- (A scene is running and plays nothing into this command. Whoever sits at the machine
		-- is not one of its fighters: a click into the game's window held an arm, and the mouse
		-- then swung it, in runs fh20, fh23 and fh24.)
		local p, K = S.Prefs(lp), C.Keys
		buttons = band(buttons, bnot(bor(K[p.left], K[p.right], K[p.depth], K[p.grip])))
		cmd:SetButtons(buttons)
		cl.accX, cl.accY = 0, 0
	end
	local ang = cmd:GetViewAngles()
	-- (the eye as the server will hear it: for scenes that ask whether it moved)
	cl.cmdYaw, cl.cmdPitch = ang.y, ang.p
	local inp = S.Input(lp, buttons, 0, 0, ang.y, ang.p)
	local held = inp.L or inp.R
	if held then
		-- whole counts go into the command; what is left of a count waits for the next
		local mx, my = M.Clamp(math.Round(cl.accX), -32000, 32000), M.Clamp(math.Round(cl.accY), -32000, 32000)
		cl.accX, cl.accY = cl.accX - mx, cl.accY - my
		cmd:SetMouseX(mx)
		cmd:SetMouseY(my)
		inp.mx, inp.my = mx, my
	else
		cl.accX, cl.accY = 0, 0
	end
	cl.held = held
	cl.lastCmd = cmd:CommandNumber()
	if not C.cv.predict:GetBool() or cl.forceNet then
		if st then st.active = false end
		return
	end
	st = st or FH.State(lp)
	local px, py, pz, vx, vy, vz, eyeZ = S.BodyOf(lp)
	local ok, err = pcall(S.Step, st, prof, inp, px, py, pz, vx, vy, vz, eyeZ, engine.TickInterval(), C.cv.strength:GetFloat() * (lp:GetNW2Float("fh_str", 1)))
	if not ok then
		wep.FH_broken = true
		st.active = false
		cl.held = false
		FH.Print("simulation error: %s", tostring(err))
		return
	end
	st.active = true
	st.cmd = cmd:CommandNumber()
	st.stamp = RealTime()
	st.simTick = cmd:TickCount()
	st.work = 0
	if cl.onDump then cl.onDump(st, cmd:CommandNumber(), inp) end
	-- what the weapon runs into, as far as this side can know it (the server decides what it did)
	if FH.Contact then
		local okc, errc = pcall(FH.Contact.Run, lp, wep, st, prof)
		if not okc and not cl.contactErr then cl.contactErr = true FH.Print("contact error: %s", tostring(errc)) end
	end
	Record(st, cmd:CommandNumber())
	if cl.onStep then cl.onStep(st, cmd:CommandNumber()) end
end)
