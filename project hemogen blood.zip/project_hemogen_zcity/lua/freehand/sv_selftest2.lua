-- Test scenes of the free-hand module, second part: a tool in the hands (developer tool; see
-- sv_selftest.lua for when these exist at all, and docs/FREEHAND_TESTING.md for what they measure).

local FH = FreeHand
if not (istable(ABL) and istable(ABL.SelfTest)) or not FH.Test then return end
local S = ABL.SelfTest
local Log, Wait = S.Log, S.Wait
local C, M, B, Sim = FH.Config, FH.Math, FH.Body, FH.Sim
local T = FH.Test
local Ask, Check, Tally, Play, Fighter, WaitFor, Rel = T.Ask, T.Check, T.Tally, T.Play, T.Fighter, T.WaitFor, T.Rel
local V = Vector
local sqrt = math.sqrt

-- A place on the weapon (units from the butt; nil: the tip), relative to the feet.
local function At(st, at)
	local b, u = st.w, st.prof.u
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local s = (at or u.length) - u.com
	return b.x + ax * s - st.bx, b.y + ay * s - st.by, b.z + az * s - st.bz
end
-- How fast it moves against the body (m/s).
local function SpeedAt(st, at)
	local b, u = st.w, st.prof.u
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	local s = (at or u.length) - u.com
	local cx, cy, cz = M.Cross(b.wx, b.wy, b.wz, ax * s, ay * s, az * s)
	return sqrt((b.vx + cx - st.bvx) ^ 2 + (b.vy + cy - st.bvy) ^ 2 + (b.vz + cz - st.bvz) ^ 2) * FH.U2M
end
local function HandSpeed(st, i)
	local h = st.h[i]
	return sqrt((h.vx - st.bvx) ^ 2 + (h.vy - st.bvy) ^ 2 + (h.vz - st.bvz) ^ 2) * FH.U2M
end
-- The handle's direction in the frame of the aim (forward, left, up).
local function Handle(st)
	local b = st.w
	local ax, ay, az = M.QRot(b.qw, b.qx, b.qy, b.qz, 1, 0, 0)
	return ax * st.fx + ay * st.fy + az * st.fz, ax * st.lx + ay * st.ly + az * st.lz, ax * st.ux + ay * st.uy + az * st.uz
end
local function Dist(a, b, c, d, e, f) return sqrt((a - d) ^ 2 + (b - e) ^ 2 + (c - f) ^ 2) end

local function ToolScene(name, class)
	S.Add(name, function()
		local prof = C.Weapons[class]
		local p = S.FindSpot({ open = 170, outdoor = true })
		-- (the host where it can see the scene's bot: T.HostAlone)
		T.HostAlone(S.Host(), p + V(0, -220, 0), { see = p })
		-- (Z-City takes this class from anybody who is not of its player class "Gordon", and
		-- gives the ordinary crowbar instead)
		local bot = Fighter(p, 0, class, class == "weapon_hg_crowbar_gordon" and function(b) b.FH_class, b.PlayerClassName = b.PlayerClassName, "Gordon" end or nil)
		if not IsValid(bot) then Log("no bot") return end
		local st = FH.State(bot)
		S.Client("fhmeasure", { on = true })
		RunConsoleCommand("fh_debug", "2")
		local front, side, quarter = p + V(88, 0, 60), p + V(6, -88, 58), p + V(68, -58, 72)
		local look = p + V(6, 0, 52)
		S.View(quarter, look)
		Wait(1.4)
		local wep = bot:GetActiveWeapon()
		Log("  %s: weapon in hand %s, held by the module %s", class, tostring(IsValid(wep) and wep:GetClass()), tostring(st.active))
		local function Done()
			S.Client("fhmeasure", { on = false })
			RunConsoleCommand("fh_debug", "0")
			FH.TestInput[bot] = nil
			FH.OnCmd, FH.OnContact = nil, nil
			if class == "weapon_hg_crowbar_gordon" then
				bot:StripWeapon(class)
				bot.PlayerClassName, bot.FH_class = bot.FH_class, nil
			end
			Tally(name)
		end
		if not Check("the module holds the bot's " .. prof.name, st.active == true and st.ok == true and st.w ~= nil and st.prof == prof) then Done() return end
		Check("it is held the way its profile says", st.twoHand == (prof.hands == 2) and st.h[1].grip == (prof.hands == 2), string.format("%d hand(s)", st.twoHand and 2 or 1))
		Ask("fhframe", { class = class }, "frame", 3)
		Log("  %s: %.2f kg, %.0f cm, centre of mass %.0f cm from the butt, inertia %.4f kg m2", prof.name, prof.mass, prof.length * 100, prof.comM * 100, prof.inertiaT)

		local worst = { net = 0, palm = 0, fist = 0, len = 0, elbowIn = 0, prop = 0, wnet = 0 }
		local nMeasured = 0
		local function Measure(tag, shot)
			Wait(0.55)
			local r = Ask("fhmeasure", { ent = bot:EntIndex(), get = true }, "meas", 3)
			if not r or not r.h then Log("  %s: the client did not answer", tag) Check("the client measured " .. tag, false) return end
			nMeasured = nMeasured + 1
			Log("  %s", tag)
			for i = 2, 1, -1 do
				local sx, sy, sz = Rel(st, i)
				local m = r.h[i]
				local holds = i == 2 or st.h[1].grip
				if m and m.bx then
					local dn = Dist(m.dx, m.dy, m.dz, sx, sy, sz)
					worst.net = math.max(worst.net, dn)
					worst.len = math.max(worst.len, math.abs(m.upper / m.bone - 1), math.abs(m.fore / m.bone - 1))
					worst.elbowIn = math.max(worst.elbowIn, m.elbowIn or 0)
					local what
					if holds then
						local dp = math.max(Dist(m.px, m.py, m.pz, m.dx, m.dy, m.dz) - (m.clamp or 0), 0)
						worst.palm = math.max(worst.palm, dp)
						what = string.format("its palm %.2f from its grip (arm short by %.2f)", dp, m.clamp or 0)
					else
						local db = math.max(Dist(m.bx, m.by, m.bz, m.dx, m.dy, m.dz) - (m.clamp or 0), 0)
						worst.fist = math.max(worst.fist, db)
						what = string.format("free, its bone %.2f from the fist", db)
					end
					local tf, tl, tu = B.ToAim(st, st.h[i].px, st.h[i].py, st.h[i].pz)
					Log("     %s hand at (%5.1f %5.1f %5.1f) in the aim's frame | drawn off by %.2f | %s | upper %.2f fore %.2f of %.2f | elbow %.1f inside",
						i == 1 and "L" or "R", tf, tl, tu, dn, what, m.upper, m.fore, m.bone, m.elbowIn or 0)
				else
					Log("     %s hand: not drawn", i == 1 and "L" or "R")
				end
			end
			local hf, hl, hu = Handle(st)
			local tx, ty, tz = At(st)
			local line = string.format("     handle points (%.2f %.2f %.2f), tip at (%.1f %.1f %.1f) from the feet, right hand %.0f cm from the butt", hf, hl, hu, tx, ty, tz, st.w.slide * FH.U2M * 100)
			if r.prop then
				local bx, by, bz = At(st, 0)
				local wn = math.max(Dist(r.prop.bx, r.prop.by, r.prop.bz, bx, by, bz), Dist(r.prop.tx, r.prop.ty, r.prop.tz, tx, ty, tz))
				worst.prop = math.max(worst.prop, r.prop.butt, r.prop.tip)
				worst.wnet = math.max(worst.wnet, wn)
				line = line .. string.format(" | prop drawn %.2f (butt) %.2f (tip) from the weapon, the weapon %.2f from the server's", r.prop.butt, r.prop.tip, wn)
			else
				line = line .. " | NO PROP DRAWN"
				worst.prop = 99
			end
			Log("%s", line)
			if shot then S.Shot(name .. "_" .. shot) end
		end
		local function Go(tag, moves, shot)
			WaitFor(Play(bot, moves, true), 6)
			Measure(tag, shot)
		end

		Log("-- at rest")
		Measure("in the guard", "rest")
		S.View(front, look) Wait(0.4) S.Shot(name .. "_rest_front")
		S.View(side, look) Wait(0.4) S.Shot(name .. "_rest_side")
		S.View(quarter, look)
		do
			local x0, y0, z0 = At(st)
			local wander, fastest = 0, 0
			FH.OnCmd = function(ply, cmd, inp, s)
				if ply ~= bot then return end
				local x, y, z = At(s)
				wander = math.max(wander, Dist(x, y, z, x0, y0, z0))
				fastest = math.max(fastest, SpeedAt(s))
			end
			Wait(1.5)
			FH.OnCmd = nil
			Check("at rest the weapon is still", wander < 0.8 and fastest < 0.6, string.format("its tip wandered %.2f units, fastest %.2f m/s", wander, fastest))
		end

		Log("-- a small movement of the mouse")
		do
			local x0, y0, z0 = At(st)
			WaitFor(Play(bot, { { R = true, mx = 3, my = 0, n = 10 } }, true), 3)
			Wait(0.5)
			local x1, y1, z1 = At(st)
			local d = Dist(x0, y0, z0, x1, y1, z1)
			Check("moves the weapon a little, and not more", d > 0.03 and d < 3, string.format("30 counts moved the tip %.2f units", d))
			FH.TestInput[bot] = function() return nil end
			Wait(1.6)
		end

		Log("-- the hands move it")
		if st.twoHand then
			-- (the mouse steers the weapon, whichever arm is held: its head goes the mouse's way.
			-- The bot looks along +x: its left is +y.)
			local function Head() local x, y, z = At(st) return y, z end
			local function Home()
				FH.TestInput[bot] = function() return nil end
				Wait(1.6)
			end
			Go("both buttons, up", { { L = true, R = true, mx = 0, my = -45, n = 25 } }, "both_up")
			local y0, z0 = Head()
			Go("both buttons, down and to the left", { { L = true, R = true, mx = -45, my = 55, n = 30 } }, "both_downleft")
			local y1, z1 = Head()
			Check("with both buttons the head goes where the mouse goes", y1 - y0 > 4 and z1 - z0 < -4, string.format("%.1f units to the left, %.1f down", y1 - y0, z0 - z1))
			Home()
			y0, z0 = Head()
			Go("the leading arm alone, across to the left", { { R = true, mx = -55, my = 0, n = 30 } }, "right_across")
			y1, z1 = Head()
			Check("with the leading arm alone too", y1 - y0 > 4 and math.abs(z1 - z0) < (y1 - y0), string.format("%.1f units to the left, %.1f up", y1 - y0, z1 - z0))
			Home()
			y0, z0 = Head()
			local l0 = { Rel(st, 1) }
			Go("the arm at the butt alone, to the left", { { L = true, mx = -55, my = 0, n = 30 } }, "left_across")
			y1, z1 = Head()
			local l1 = { Rel(st, 1) }
			Check("and with the arm at the butt alone", y1 - y0 > 3, string.format("the head %.1f units to the left; the hand at the butt %.1f", y1 - y0, l1[2] - l0[2]))
			Check("which pulls the other way less than the head goes the mouse's", (l1[2] - l0[2]) < (y1 - y0) - 2)
			Home()
			local s0 = st.w.slide
			Go("the arm at the butt with the depth key, the mouse back", { { L = true, depth = true, mx = 0, my = 60, n = 30 } }, "left_slide")
			Check("the hands come together along the handle", st.w.slide < s0 - 0.5,
				string.format("the right hand holds %.0f cm from the butt, %.0f before", st.w.slide * FH.U2M * 100, s0 * FH.U2M * 100))
		else
			Go("the right hand up", { { R = true, mx = 0, my = -50, n = 25 } }, "right_up")
			Go("the right hand out to the right", { { R = true, mx = 55, my = 20, n = 30 } }, "right_out")
			Go("the right hand across the body", { { R = true, mx = -60, my = 20, n = 45 } }, "right_across")
			Go("the free left hand up", { { L = true, mx = 0, my = -50, n = 25 } }, "left_up")
		end
		FH.TestInput[bot] = function() return nil end
		Wait(2.4)
		Measure("let go: back in the guard", "released")

		Log("-- a blow: raised, then the right hand hard down")
		do
			WaitFor(Play(bot, { { L = st.twoHand, R = true, mx = 0, my = -60, n = 25 }, { L = st.twoHand, R = true, n = 12 } }, true), 4)
			S.Shot(name .. "_raised")
			local peakTip, peakHand, tPeak, n, late = 0, 0, 0, 0, 0
			local bad = false
			FH.OnCmd = function(ply, cmd, inp, s)
				if ply ~= bot then return end
				n = n + 1
				local v = SpeedAt(s)
				if v ~= v then bad = true end
				if v > peakTip then peakTip, tPeak = v, n end
				peakHand = math.max(peakHand, HandSpeed(s, 2))
				if n > 45 then late = math.max(late, v) end
			end
			Play(bot, { { R = true, mx = 0, my = 500, n = 9 }, { R = true, n = 80 } }, true)
			Wait(0.16)
			S.Shot(name .. "_blow")
			Wait(1.3)
			FH.OnCmd = nil
			local tick = engine.TickInterval()
			Log("  the head reached %.1f m/s %.0f ms after the pull began; the right hand %.1f m/s; 0.7 s after it the head still moved at up to %.2f m/s", peakTip, tPeak * tick * 1000, peakHand, late)
			Check("the head is faster than the hand that swings it", peakTip > peakHand * 1.1 and not bad, string.format("%.1f against %.1f m/s", peakTip, peakHand))
			Check("a blow is fast and not instant", peakTip > 5 and peakTip < 30 and tPeak >= 3, string.format("%.1f m/s after %d ticks", peakTip, tPeak))
			Check("and comes to rest", late < 1.5, string.format("%.2f m/s", late))
			Measure("after the blow", "after_blow")
		end

		Log("-- thrown about: the mouse to and fro as fast as it goes")
		do
			local moves = {}
			for i = 1, 10 do moves[#moves + 1] = { L = i % 3 == 0, R = true, mx = (i % 2 == 0) and 1400 or -1400, my = (i % 4 < 2) and 900 or -900, n = 4 } end
			local peak, bad = 0, false
			FH.OnCmd = function(ply, cmd, inp, s)
				if ply ~= bot then return end
				local v = SpeedAt(s)
				if v ~= v or v > 200 then bad = true end
				peak = math.max(peak, v)
			end
			WaitFor(Play(bot, moves, false), 4)
			Wait(0.3)
			FH.OnCmd = nil
			Check("nothing breaks when the mouse is thrown about", not bad and st.active == true and wep.FH_broken ~= true, string.format("fastest head %.1f m/s", peak))
			FH.TestInput[bot] = function() return nil end
			Wait(2.2)
			Measure("after that", "after_abuse")
		end

		if prof.canSwitch then
			Log("-- the grip key: the left hand %s the handle", st.twoHand and "off" or "onto")
			local was = st.twoHand
			local function Switch(tag)
				local jump = 0
				local last = { { Rel(st, 1) }, { Rel(st, 2) } }
				FH.OnCmd = function(ply, cmd, inp, s)
					if ply ~= bot then return end
					for i = 1, 2 do
						local x, y, z = Rel(s, i)
						jump = math.max(jump, Dist(x, y, z, last[i][1], last[i][2], last[i][3]))
						last[i][1], last[i][2], last[i][3] = x, y, z
					end
				end
				Play(bot, { { grip = true, n = 2 }, { n = 100 } }, false)
				Wait(1.6)
				FH.OnCmd = nil
				local tick = engine.TickInterval()
				Log("  %s: two hands wanted %s, the left hand holds %s; no hand moved more than %.2f units in a tick (%.1f m/s)", tag, tostring(st.twoHand), tostring(st.h[1].grip), jump, jump / tick * FH.U2M)
				return jump
			end
			local j1 = Switch("first press")
			Check("the grip key changes the grip", st.twoHand == not was and st.h[1].grip == st.twoHand)
			Measure("the other grip", "switched")
			local j2 = Switch("second press")
			Check("and changes it back", st.twoHand == was and st.h[1].grip == was)
			-- (a hand goes for the handle as fast as a hand goes; a hand that was put there would
			-- have crossed the whole way, 15 units and more, in one tick)
			Check("no hand snaps when the grip changes", math.max(j1, j2) < 9, string.format("%.2f units in a tick at most, %.1f m/s", math.max(j1, j2), math.max(j1, j2) / engine.TickInterval() * FH.U2M))
			Measure("the first grip again", "switched_back")
		end

		Log("-- over all %d postures", nMeasured)
		Check("the hands the client draws are the hands the server has", worst.net < 1.2, string.format("worst %.2f units", worst.net))
		Check("the weapon the client draws is the weapon the server has", worst.wnet < 1.5, string.format("worst %.2f units", worst.wnet))
		Check("the prop is drawn where the weapon is", worst.prop < 0.5, string.format("worst %.2f units", worst.prop))
		Check("a hand that holds the handle has it in its palm", worst.palm < 1.2, string.format("worst %.2f units", worst.palm))
		Check("a free hand's bone is on its fist", worst.fist < 1.2, string.format("worst %.2f units", worst.fist))
		Check("no arm is stretched or shortened", worst.len < 0.06, string.format("worst %.1f %% of a bone", worst.len * 100))
		Check("no elbow is inside the trunk", worst.elbowIn < 1.0, string.format("deepest %.2f units", worst.elbowIn))

		Log("-- the host's own weapon: predicted on the client, stepped on the server from the same commands")
		do
			local host = S.Host()
			if not host:HasWeapon(class) then host:Give(class) end
			host:SelectWeapon(class)
			host:SetEyeAngles(Angle(6, 0, 0))
			-- (rested: tired arms are weaker, and the client hears of that a moment late)
			if T.Rested then T.Rested(host) end
			Log("  (%s)", T.HostPlace(host, p + Vector(0, -220, 0), { see = p }))
			Wait(1.4)
			local hs = FH.State(host)
			local server, sdump = {}, {}
			-- (The state as the step left it, for the question in what the two sides differ; and
			-- where hands and weapon are after the server's contacts, as the client's record is
			-- after the client's. Until run fh44 the server's side was taken before them: a
			-- weapon that touched a wall was a difference between two sides that agreed.)
			FH.OnCmd = function(ply, cmd, inp, s)
				if ply == host and s.w then sdump[cmd:CommandNumber()] = FH.Sim.Dump(s, inp) end
			end
			FH.OnContact = function(ply, s)
				if ply == host and s.w then
					local a, b, c = Rel(s, 1)
					local d, e, f = Rel(s, 2)
					server[s.cmd] = { a, b, c, d, e, f, s.w.x - s.bx, s.w.y - s.by, s.w.z - s.bz, s.w.qw, s.w.qx, s.w.qy, s.w.qz }
				end
			end
			S.Client("fhinput", { record = true, moves = {
				{ R = true, mx = 30, my = -40, n = 20 }, { R = true, mx = 0, my = 0, n = 10 }, { L = true, mx = -50, my = -20, n = 20 },
				{ L = true, R = true, mx = 25, my = 35, n = 25 }, { R = true, mx = 0, my = 400, n = 8 }, { R = true, mx = 0, my = 0, n = 30 },
				{ grip = true, n = 2 }, { R = true, mx = -200, my = -100, n = 10 }, { n = 30 },
			} })
			Wait(3.0)
			local r = Ask("fhinput", { report = true }, "pred", 3)
			FH.OnCmd, FH.OnContact = nil, nil
			local n, worstH, worstW, worstQ = 0, 0, 0, 0
			if r and r.list then
				for _, e in ipairs(r.list) do
					local sv = server[e[1]]
					if sv and e[8] then
						n = n + 1
						worstH = math.max(worstH, Dist(e[2], e[3], e[4], sv[1], sv[2], sv[3]), Dist(e[5], e[6], e[7], sv[4], sv[5], sv[6]))
						worstW = math.max(worstW, Dist(e[8], e[9], e[10], sv[7], sv[8], sv[9]))
						worstQ = math.max(worstQ, 1 - math.abs(e[11] * sv[10] + e[12] * sv[11] + e[13] * sv[12] + e[14] * sv[13]))
					end
				end
			end
			Log("  %d commands compared: hands differ by %.4f units at the worst, the weapon's centre by %.4f, its attitude by %.6f (the arms' strength now: %.3f)", n, worstH, worstW, worstQ, host:GetNW2Float("fh_str", 1))
			-- (which commands, and what the two sides may not have agreed on)
			local firstBad, lastBad, bad = nil, nil, 0
			if worstH > 0.01 then
				for k, e in ipairs(r and r.list or {}) do
					local sv = server[e[1]]
					if sv and e[8] and Dist(e[5], e[6], e[7], sv[4], sv[5], sv[6]) > 0.01 then
						firstBad, lastBad, bad = firstBad or k, k, bad + 1
					end
				end
				Log("  the difference: in %d of them, the %s to the %s of the client's record; %s", bad, tostring(firstBad), tostring(lastBad), T.PredictionNotes(host, server, r and r.list)())
				-- (in what the two states differ: at the record's first command, and in the
				-- commands up to the first in which the hand is somewhere else)
				Log("  in what the client's state differs from the server's:")
				T.DumpCompare(Ask, Log, sdump, r.list, firstBad)
			end
			-- (One or two commands that differ while every command after them is the same again
			-- are not two states that have come apart: seen in runs fh30 and fh31, a single
			-- command of 200 each, not explained. More than that is.)
			Check("the client's own weapon is the server's", n >= 80 and worstQ < 0.001 and ((worstH < 0.5 and worstW < 0.5) or bad <= 2),
				bad > 0 and string.format("%d commands, %d of them differ, by %.2f units at the most", n, bad, worstH) or string.format("%d commands", n))
			-- what the player sees of it: Z-City's own first-person camera
			S.Client("fhinput", {})
			S.Client("view", {})
			S.Client("zview", { on = true })
			Wait(3.0)
			-- (the scene's switch above may have left the host in the other grip)
			if hs.twoHand ~= (prof.hands == 2) and prof.canSwitch then
				S.Client("fhinput", { moves = { { grip = true, n = 2 }, { n = 5 } } })
				Wait(1.6)
			end
			S.Shot(name .. "_own_rest")
			S.Client("fhinput", { moves = { { L = hs.twoHand, R = true, mx = 0, my = -55, n = 22 }, { L = hs.twoHand, R = true, n = 300 } } })
			Wait(1.2)
			S.Shot(name .. "_own_raised")
			S.Client("fhinput", { moves = { { R = true, mx = -20, my = 420, n = 9 }, { R = true, n = 300 } } })
			Wait(0.14)
			S.Shot(name .. "_own_blow")
			Wait(1.0)
			S.Shot(name .. "_own_after")
			S.Client("fhinput", {})
			S.Client("zview", { on = false })
			host:SelectWeapon("weapon_hands_sh")
			host:StripWeapon(class)
		end
		Done()
	end)
end

ToolScene("fh_crowbar", "weapon_hg_crowbar")
ToolScene("fh_gordon", "weapon_hg_crowbar_gordon")
ToolScene("fh_axe", "weapon_hg_axe")
ToolScene("fh_hatchet", "weapon_hatchet")
ToolScene("fh_tomahawk", "weapon_tomahawk")
