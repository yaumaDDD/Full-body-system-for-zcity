-- Test scenes of the free-hand module, fourth part: what the mouse does to an arm, and what the
-- player sees of the body the arms are on (developer tool; see sv_selftest.lua for when these
-- exist at all, and docs/FREEHAND_TESTING.md for what they measure).

local FH = FreeHand
if not (istable(ABL) and istable(ABL.SelfTest)) or not FH.Test then return end
local S = ABL.SelfTest
local Log, Wait = S.Log, S.Wait
local C, M, B, Sim = FH.Config, FH.Math, FH.Body, FH.Sim
local T = FH.Test
local Ask, Check, Tally = T.Ask, T.Check, T.Tally
local sqrt, abs = math.sqrt, math.abs

-- The host with its fists up at a spot in the open, looking along +x.
local function HostAt(pitch)
	local host = S.Host()
	local p = S.FindSpot({ open = 170, outdoor = true })
	-- (in the open, with room to walk the way it looks: a spot is clear in seven of eight
	-- directions only, and in run fh53 the eighth was a wall in front of the host)
	T.HostAlone(host, p, { ahead = 120 })
	p = host:GetPos()
	host:SetEyeAngles(Angle(pitch or 6, 0, 0))
	for class in pairs(C.Classes) do
		if class ~= "weapon_hands_sh" and host:HasWeapon(class) then host:StripWeapon(class) end
	end
	host:SelectWeapon("weapon_hands_sh")
	Wait(0.6)
	local wep = host:GetActiveWeapon()
	if IsValid(wep) and wep.SetFists then wep:SetFists(true) end
	S.Client("fhinput", {})
	T.Rested(host)
	Wait(1.2)
	return host, p, FH.State(host)
end

-- A hand's place and its guard's, about the feet (so that walking does not count).
-- (a scene's running costs Z-City's stamina; tired arms are weaker, and the next scene's too)
function T.Rested(ply)
	local org = ply.organism
	local sta = istable(org) and org.stamina
	if istable(sta) and tonumber(sta.max) then sta[1] = sta.max end
end

local function FromGuard(st, i)
	local h = st.h[i]
	local gf, gl, gu = Sim.GuardTarget(st, st.prof, i)
	local gx, gy, gz = B.ToWorld(st, gf, gl, gu)
	return sqrt((h.px - gx) ^ 2 + (h.py - gy) ^ 2 + (h.pz - gz) ^ 2)
end

------------------------------------------------------------------------------------------
-- fh_arm: the mouse and an arm. Which button holds which arm (the real buttons, through the
-- command); an arm that is held stays where it was sent, one that is let go comes home by
-- itself and without a jump; a fist's reach follows the gesture; a quick turn of the view
-- takes the hands along as fast as arms can go.
------------------------------------------------------------------------------------------
local function ArmScene()
	local host, p, st = HostAt(6)
	Check("the module holds the host's fists", st.active == true and st.prof ~= nil and st.prof.kind == "fists")
	if not st.prof then return end

	Log("-- which button holds which arm")
	local function Held(buttons)
		local l, r, n = 0, 0, 0
		FH.OnCmd = function(ply, cmd, inp, s)
			if ply ~= host then return end
			n = n + 1
			if s.h[1].on then l = l + 1 end
			if s.h[2].on then r = r + 1 end
		end
		S.Client("fhinput", { moves = { { buttons = buttons, n = 14 }, { n = 4 } } })
		Wait(0.6)
		FH.OnCmd = nil
		return l, r, n
	end
	local l, r = Held(IN_ATTACK2)
	Check("the secondary mouse button holds the right arm, and only it", r >= 10 and l == 0, string.format("right arm held in %d commands, left in %d", r, l))
	l, r = Held(IN_ATTACK)
	Check("the primary mouse button holds the left arm, and only it", l >= 10 and r == 0, string.format("left arm held in %d commands, right in %d", l, r))
	l, r = Held(IN_ATTACK + IN_ATTACK2)
	Check("both buttons hold both", l >= 10 and r >= 10, string.format("left %d, right %d", l, r))
	Log("-- the settings: the two keys exchanged; a key that is none; two arms on one key")
	T.Prefs(host, { fh_bind_right_arm = "attack", fh_bind_left_arm = "attack2" })
	l, r = Held(IN_ATTACK)
	Check("with the two keys exchanged the primary button holds the right arm", r >= 10 and l == 0, string.format("left %d, right %d", l, r))
	T.Prefs(host, { fh_bind_right_arm = "zoom", fh_bind_left_arm = "attack" })
	l, r = Held(IN_ZOOM)
	local l2, r2 = Held(IN_ATTACK2)
	Check("an arm can be put on another key, and its old key then holds nothing", r >= 10 and l == 0 and l2 == 0 and r2 == 0, string.format("on the new key: left %d, right %d; on the old: left %d, right %d", l, r, l2, r2))
	T.Prefs(host, { fh_bind_right_arm = "no such key", fh_bind_left_arm = "attack" })
	l, r = Held(IN_ATTACK2)
	Check("a key that is no key is its default", r >= 10 and l == 0, string.format("left %d, right %d", l, r))
	T.Prefs(host, { fh_bind_right_arm = "attack", fh_bind_left_arm = "attack" })
	l, r = Held(IN_ATTACK2)
	l2, r2 = Held(IN_ATTACK)
	Check("two arms on one key: the defaults are used", r >= 10 and l == 0 and l2 >= 10 and r2 == 0, string.format("secondary: left %d, right %d; primary: left %d, right %d", l, r, l2, r2))
	-- numbers out of their range, and none at all
	T.Prefs(host, { fh_bind_right_arm = "attack2", fh_bind_left_arm = "attack", fh_sensitivity = "banana", fh_reach = "0.2", fh_smoothing = "7" })
	local pr = FH.Sim.Prefs(host)
	Log("  the server has: sensitivity %s, reach %s, smoothing %s", tostring(pr.sens), tostring(pr.reach), tostring(pr.smooth))
	Check("a number that is none is its default, one out of its range is brought into it", pr.sens >= 0.2 and pr.sens <= 4 and pr.reach == 0.85 and pr.smooth == 1)
	T.Prefs(host)

	Log("-- an arm that is held, and let go")
	local rec = {}
	local lx, ly, lz
	FH.OnCmd = function(ply, cmd, inp, s)
		if ply ~= host then return end
		local h = s.h[2]
		local jump = lx and sqrt((h.px - s.bx - lx) ^ 2 + (h.py - s.by - ly) ^ 2 + (h.pz - s.bz - lz) ^ 2) or 0
		lx, ly, lz = h.px - s.bx, h.py - s.by, h.pz - s.bz
		rec[#rec + 1] = { on = h.on, d = FromGuard(s, 2), jump = jump, t = CurTime(), yaw = inp.yaw, pitch = inp.pitch }
	end
	S.Client("fhinput", { moves = { { R = true, mx = -40, my = -60, n = 14 }, { R = true, n = 30 }, { n = 110 } } })
	Wait(2.8)
	FH.OnCmd = nil
	local held, out, tRel, half, home, jump = 0, 0, nil, nil, nil, 0
	for i, e in ipairs(rec) do
		if e.on then held, out = held + 1, e.d
		elseif held > 0 then
			tRel = tRel or e.t
			jump = math.max(jump, e.jump)
			if not half and e.d < out * 0.5 then half = e.t - tRel end
			if not home and e.d < 1.0 then home = e.t - tRel end
		end
	end
	-- (the last ticks it was held: has it come to rest out there)
	local drift, lastOn = 0, 0
	for i, e in ipairs(rec) do if e.on then lastOn = i end end
	for i = math.max(lastOn - 8, 2), lastOn do
		if rec[i].on and rec[i - 1].on then drift = math.max(drift, abs(rec[i].d - rec[i - 1].d)) end
	end
	-- (what the server had, command by command: held or not, and how far from the guard)
	do
		local parts, from, state = {}, 1, rec[1] and rec[1].on
		for i = 2, #rec + 1 do
			local e = rec[i]
			if not e or e.on ~= state then
				parts[#parts + 1] = string.format("%s x%d (%.1f to %.1f)", state and "held" or "free", i - from, rec[from].d, rec[i - 1].d)
				from, state = i, e and e.on
			end
		end
		Log("  commands: %s", table.concat(parts, ", "))
	end
	Log("  held for %d commands: the hand came to %.1f units from its guard and lay still there (%.3f units a tick at the most at the end)", held, out, drift)
	Log("  let go: half way home after %s s, within a unit of its guard after %s s; furthest in one tick %.2f units",
		half and string.format("%.2f", half) or "never", home and string.format("%.2f", home) or "never", jump)
	Check("a held arm stays where it was sent", out > 5 and drift < 0.2, string.format("%.1f units out", out))
	-- (the mouse went 840 counts across and 1260 up meanwhile: 12 and 19 degrees of a view)
	local eyeMoved, y0, p0 = 0, nil, nil
	for _, e in ipairs(rec) do
		if e.on then
			y0, p0 = y0 or e.yaw, p0 or e.pitch
			eyeMoved = math.max(eyeMoved, abs(math.AngleDifference(e.yaw, y0)), abs(math.AngleDifference(e.pitch, p0)))
		end
	end
	Check("the eye stands still while the mouse moves a held arm", eyeMoved < 0.05, string.format("the eye in the server's commands moved %.3f degrees", eyeMoved))
	Check("an arm that is let go comes home by itself", home ~= nil and home < 1.4, home and string.format("%.2f s", home) or "it did not")
	Check("and not in an instant", half ~= nil and half > 0.12, half and string.format("half way after %.2f s", half) or "")
	-- (a jump would be further in one tick than an arm can go at all)
	Check("without a jump", jump / engine.TickInterval() * FH.U2M < C.Arm.maxSpeed * 0.5, string.format("%.2f units in a tick at most, %.1f m/s", jump, jump / engine.TickInterval() * FH.U2M))

	Log("-- the reach of a fist follows the gesture")
	local L = B.ArmLength()
	local function Reach() local _, _, ext = B.TargetPolar(2, st.h[2].tf, st.h[2].tl, st.h[2].tu) return ext / L end
	local r0 = Reach()
	Log("  (the right hand is %.2f units from its guard, its target across, up and out %s)", FromGuard(st, 2), string.format("%.1f %.1f %.2f", B.TargetPolar(2, st.h[2].tf, st.h[2].tl, st.h[2].tu)))
	S.Client("fhinput", { moves = { { R = true, mx = 60, my = 0, n = 20 }, { R = true, n = 40 } } })
	Wait(0.7)
	local r1 = Reach()
	S.Client("fhinput", {})
	Wait(1.6)
	local r2 = Reach()
	Log("  the right fist's target: %.2f of the arm at its guard, %.2f swung 36 degrees out to the side, %.2f at its guard again", r0, r1, r2)
	Check("a fist swung away from its guard reaches further", r1 > r0 + 0.08 and abs(r2 - r0) < 0.02, string.format("%.2f against %.2f", r1, r0))

	Log("-- a quick turn of the view")
	rec, lx = {}, nil
	local turned
	FH.OnCmd = function(ply, cmd, inp, s)
		if ply ~= host then return end
		local h = s.h[2]
		local jump = lx and sqrt((h.px - lx) ^ 2 + (h.py - ly) ^ 2 + (h.pz - lz) ^ 2) or 0
		lx, ly, lz = h.px, h.py, h.pz
		rec[#rec + 1] = { d = FromGuard(s, 2), jump = jump, t = CurTime(), yaw = inp.yaw }
	end
	Wait(0.3)
	host:SetEyeAngles(Angle(6, 110, 0))
	turned = CurTime()
	Wait(1.6)
	FH.OnCmd = nil
	local worst, far, settle = 0, 0, nil
	local every, nextT = {}, turned
	for _, e in ipairs(rec) do
		if e.t >= turned then
			worst, far = math.max(worst, e.jump), math.max(far, e.d)
			if not settle and far > 3 and e.d < 1.0 then settle = e.t - turned end
			if e.t >= nextT then
				every[#every + 1] = string.format("%.0f", e.d)
				nextT = nextT + 0.15
			end
		end
	end
	Log("  units from its guard every 0.15 s after the turn: %s", table.concat(every, " "))
	Log("  the view turned 110 degrees at once: the right hand was %.1f units behind its guard at the most, went %.2f units in a tick at the fastest (%.1f m/s), and was at its guard again after %s s",
		far, worst, worst / engine.TickInterval() * FH.U2M, settle and string.format("%.2f", settle) or "more than 1.6")
	-- (Until phase 41 the hands were left to catch up with a view that had turned: they were
	-- behind their owner's back for a moment after every quick look round. They go round with
	-- the body now, and the turn gives them no speed of their own.)
	local h2 = st.h[2]
	local rel = math.sqrt((h2.vx - st.bvx) ^ 2 + (h2.vy - st.bvy) ^ 2 + (h2.vz - st.bvz) ^ 2) * FH.U2M
	Check("the hands go round with the body: never far from their guard", far < 3, string.format("%.1f units at the most", far))
	Check("and are at rest there when the view is", rel < 0.5, string.format("%.2f m/s", rel))
	host:SetEyeAngles(Angle(6, 0, 0))
end

S.Add("fh_arm", function()
	-- (whatever happens in it, the setting is not left turned round: it is a saved one)
	local ok, err = pcall(ArmScene)
	FH.OnCmd = nil
	T.Prefs(S.Host())
	S.Client("fhinput", {})
	if not ok then Log("  the scene failed: %s", tostring(err)) Check("the scene ran through", false) end
	Tally("fh_arm")
end)

------------------------------------------------------------------------------------------
-- fh_bodycam: what the player sees of the body the arms are on, through Z-City's own
-- first-person camera. Looking ahead, down, up; crouched; walking; in a blow; with a crowbar.
-- For each: where the hands, the elbows, the shoulders and the chest are from the eye (how far,
-- and whether inside the picture), and a picture.
------------------------------------------------------------------------------------------
local function Look(host, name, pitch, wait)
	if pitch then host:SetEyeAngles(Angle(pitch, 0, 0)) end
	Wait(wait or 0.9)
	local r = Ask("fhbody", {}, "body_" .. name, 3)
	S.Shot("fh_bodycam_" .. name)
	if not r or not r.pts then Log("  %s: no answer", name) return nil end
	local function P(k)
		local e = r.pts[k]
		if not e then return "-" end
		return string.format("%.0f units, %+.0f right %+.0f up%s", e.d, e.right, e.up, e.seen and "" or " (outside)")
	end
	Log("  %-12s eye %.1f over the feet, looking %+.0f | hands: left %s; right %s | elbows: left %s; right %s | shoulders: left %s; right %s | chest %s",
		name, r.eyeUp, -r.pitch, P("lh"), P("rh"), P("le"), P("re"), P("ls"), P("rs"), P("chest"))
	-- (the same in units about the feet, in the eye's frame: what the server has, what the client
	-- draws, and the eye of the picture)
	local st = FH.State(host)
	local function V3(v) return v and string.format("(%.1f %.1f %.1f)", v[1], v[2], v[3]) or "-" end
	local function Sv(i)
		local h = st.h[i]
		local dx, dy, y = h.px - st.bx, h.py - st.by, math.rad(st.yaw)
		return string.format("(%.1f %.1f %.1f) %.1f from its guard", dx * math.cos(y) + dy * math.sin(y), -dx * math.sin(y) + dy * math.cos(y), h.pz - st.bz, FromGuard(st, i))
	end
	Log("  %-12s the server's hands: left %s, right %s | drawn: left %s, right %s | the picture's eye %s, looking %.1f to the left of the eye (the model is drawn %.1f to its left)",
		"", Sv(1), Sv(2), V3(r.drawn and r.drawn[1]), V3(r.drawn and r.drawn[2]), V3(r.cam), math.AngleDifference(r.viewYaw or 0, r.eyeYaw or 0), math.AngleDifference(r.drawnYaw or 0, r.eyeYaw or 0))
	return r
end

local function Nearest(r)
	local d = math.huge
	for _, k in ipairs({ "lh", "rh", "le", "re" }) do if r.pts[k] then d = math.min(d, r.pts[k].d) end end
	return d
end

local function BodycamScene()
	local host, p, st = HostAt(6)
	S.Client("fhmeasure", { on = true })
	S.Client("view", {})
	S.Client("zview", { on = true })
	Wait(2.0)
	Check("the module holds the host's fists", st.active == true)

	Log("-- fists at their guard")
	local r = Look(host, "ahead", 6)
	if r then
		Check("looking ahead, both fists are in the picture", r.pts.lh and r.pts.rh and r.pts.lh.seen and r.pts.rh.seen)
		Check("and under its middle", r.pts.lh.up < -3 and r.pts.rh.up < -3, string.format("%.0f and %.0f degrees under it", -r.pts.lh.up, -r.pts.rh.up))
		Check("one to each side of it", r.pts.lh.right < 0 and r.pts.rh.right > 0, string.format("%.0f and %.0f degrees to the right", r.pts.lh.right, r.pts.rh.right))
		Check("nothing of an arm is at the lens", Nearest(r) > 6, string.format("nearest %.1f units", Nearest(r)))
	end
	r = Look(host, "down", 62)
	if r then
		-- (the eye is in front of the chest: the chest is never in the picture, the legs are)
		Log("  (the player's own feet in the picture: left %s, right %s)", tostring(r.pts.lf and r.pts.lf.seen), tostring(r.pts.rf and r.pts.rf.seen))
		Check("the arms come from under the eye", r.pts.ls and r.pts.rs and r.pts.ls.d < 16 and r.pts.rs.d < 16 and r.pts.ls.right < 0 and r.pts.rs.right > 0,
			r.pts.ls and string.format("shoulders %.0f and %.0f units from the eye, left and right of it", r.pts.ls.d, r.pts.rs.d) or "")
		Check("both forearms are in the picture", r.pts.le and r.pts.re and (r.pts.le.seen or r.pts.lh.seen) and (r.pts.re.seen or r.pts.rh.seen))
		Check("nothing of an arm is at the lens", Nearest(r) > 6, string.format("nearest %.1f units", Nearest(r)))
	end
	r = Look(host, "up", -45)
	if r then Check("looking up, nothing of an arm is at the lens", Nearest(r) > 6, string.format("nearest %.1f units", Nearest(r))) end

	Log("-- crouched, walking, running")
	host:SetEyeAngles(Angle(20, 0, 0))
	S.Client("fhinput", { moves = { { duck = true, n = 200 } } })
	r = Look(host, "crouched", nil, 1.2)
	if r then
		Check("crouched, the eye is lower and the fists are still in the picture", r.eyeUp < 52 and r.pts.lh.seen and r.pts.rh.seen, string.format("eye %.1f over the feet", r.eyeUp))
		Check("nothing of an arm is at the lens", Nearest(r) > 6, string.format("nearest %.1f units", Nearest(r)))
	end
	S.Client("fhinput", {})
	Wait(0.8)
	host:SetPos(p)
	S.Client("fhinput", { moves = { { fwd = 10000, n = 200 } } })
	r = Look(host, "walking", 6, 0.7)
	local speed = host:GetVelocity():Length2D()
	if r then
		Check("walking, the fists stay in the picture", speed > 40 and r.pts.lh.seen and r.pts.rh.seen, string.format("%.0f units/s", speed))
		Check("nothing of an arm is at the lens", Nearest(r) > 6, string.format("nearest %.1f units", Nearest(r)))
	end
	S.Client("fhinput", {})
	Wait(0.6)
	host:SetPos(p)
	-- (Z-City lowers the fists of whoever holds the run key: they are its own then)
	S.Client("fhinput", { moves = { { fwd = 10000, run = true, n = 200 } } })
	Wait(0.8)
	S.Shot("fh_bodycam_running_fists")
	local wepNow = host:GetActiveWeapon()
	Log("  the run key held: fists up %s, the module holds them %s, %.0f units/s", tostring(IsValid(wepNow) and wepNow.GetFists and wepNow:GetFists()), tostring(FH.Applies(host) ~= nil), host:GetVelocity():Length2D())
	Check("fists that Z-City lowers for running are Z-City's again", FH.Applies(host) == nil or (IsValid(wepNow) and wepNow:GetFists() == true))
	S.Client("fhinput", {})
	Wait(0.8)
	host:SetPos(p)
	host:SetLocalVelocity(Vector(0, 0, 0))
	if IsValid(wepNow) and wepNow.SetFists then wepNow:SetFists(true) end
	Wait(1.2)

	Log("-- an arm sent out, and a turn")
	S.Client("fhinput", { moves = { { R = true, mx = -30, my = -50, n = 12 }, { R = true, n = 200 } } })
	r = Look(host, "right_out", 6, 0.6)
	if r then Check("the right arm sent up and across is in the picture, the left fist where it was", r.pts.rh.seen and r.pts.lh.seen and r.pts.rh.up > r.pts.lh.up + 5,
		string.format("right %+.0f up, left %+.0f", r.pts.rh.up, r.pts.lh.up)) end
	S.Client("fhinput", {})
	Wait(1.2)
	host:SetEyeAngles(Angle(6, 100, 0))
	Wait(0.09)
	S.Shot("fh_bodycam_turning")
	Wait(1.0)
	host:SetEyeAngles(Angle(6, 0, 0))
	Wait(1.0)

	Log("-- the crowbar")
	local class = "weapon_hg_crowbar"
	if not host:HasWeapon(class) then host:Give(class) end
	host:SelectWeapon(class)
	-- (does the weapon come to rest in the hands: both hands' way from their guards, four times a second)
	do
		local rows = {}
		for n = 1, 10 do
			Wait(0.25)
			if st.prof and st.prof.kind == "tool" and st.w then
				rows[#rows + 1] = string.format("%.1f/%.1f", FromGuard(st, 1), FromGuard(st, 2))
			else
				rows[#rows + 1] = "-"
			end
		end
		Log("  the crowbar taken: left/right hand from their guards every 0.25 s: %s | two hands %s, left hand on it %s, held L %s R %s, the eye at %.1f %.1f",
			table.concat(rows, " "), tostring(st.twoHand), tostring(st.h[1].grip), tostring(st.h[1].on), tostring(st.h[2].on), st.yaw, st.pitch)
	end
	r = Look(host, "crowbar_ahead", 6)
	-- (its guard is low: the right hand and the bar are in the picture, the left hand at the
	-- butt is under its lower edge until the weapon is raised)
	if r then Check("the crowbar's leading hand is in the picture", r.pts.rh.seen) end
	-- (raised to the height of the head: raised over it, the hands leave the top of the picture
	-- as they do for anybody, and since phase 42 the view does not go up after them by much)
	S.Client("fhinput", { moves = { { L = true, R = true, mx = 0, my = -30, n = 22 }, { L = true, R = true, n = 200 } } })
	r = Look(host, "crowbar_raised", nil, 1.0)
	-- (the left hand is at the butt, a forearm's length under the right one: it comes into the
	-- picture only when the weapon is carried high)
	if r then Check("raised, the leading hand is in the picture and higher", r.pts.rh.seen and r.pts.rh.up > -15, string.format("%+.0f degrees", r.pts.rh.up)) end
	S.Client("fhinput", {})
	Wait(1.2)
	r = Look(host, "crowbar_down", 62)
	if r then
		Check("looking down, the leading hand is in the picture", r.pts.rh.seen)
		Check("nothing of an arm is at the lens", Nearest(r) > 6, string.format("nearest %.1f units", Nearest(r)))
	end
	host:SetEyeAngles(Angle(6, 0, 0))
	Wait(0.6)
	S.Client("fhinput", { moves = { { fwd = 10000, run = true, n = 200 } } })
	r = Look(host, "crowbar_running", 6, 0.9)
	speed = host:GetVelocity():Length2D()
	if r then
		Log("  running with the crowbar: %.0f units/s, the module holds it %s", speed, tostring(FH.Applies(host) ~= nil))
		-- (how fast Z-City lets the host run here differs from run to run, and is its own)
		Check("with the run key held the crowbar stays in the hands", FH.Applies(host) ~= nil, string.format("%.0f units/s", speed))
		Check("nothing of an arm is at the lens", Nearest(r) > 6, string.format("nearest %.1f units", Nearest(r)))
	end
	S.Client("fhinput", {})
	Wait(0.8)
	host:SetPos(p)
	host:SetLocalVelocity(Vector(0, 0, 0))
	Wait(0.6)
	S.Client("fhinput", { moves = { { R = true, mx = -180, my = 300, n = 8 }, { R = true, n = 200 } } })
	Wait(0.12)
	S.Shot("fh_bodycam_crowbar_blow")
	Wait(0.8)
	S.Client("fhinput", {})
	host:SelectWeapon("weapon_hands_sh")
	host:StripWeapon(class)
	T.Rested(host)
end

S.Add("fh_bodycam", function()
	local ok, err = pcall(BodycamScene)
	S.Client("fhinput", {})
	S.Client("fhmeasure", { on = false })
	S.Client("zview", { on = false })
	if not ok then Log("  the scene failed: %s", tostring(err)) Check("the scene ran through", false) end
	Tally("fh_bodycam")
end)

------------------------------------------------------------------------------------------
-- fh_probe_turn: no judgement, numbers. The host turns its view on the spot, step by step:
-- which way the model is drawn, and where the eye of the picture, the head and the shoulders
-- are about the feet, in the frame of the eye's yaw, beside where the simulation has the
-- shoulders. (sh_config.lua's shoulders are from this scene.)
------------------------------------------------------------------------------------------
local function TurnRow(host, yaw, wait)
	if yaw then host:SetEyeAngles(Angle(6, yaw, 0)) end
	Wait(wait or 0.9)
	local r = Ask("fhturn", {}, "turn", 3)
	if not r or not r.eyeYaw then Log("  no answer") return end
	local function P(v) return v and string.format("(%5.1f %5.1f %5.1f)", v[1], v[2], v[3]) or "-" end
	local st = FH.State(host)
	-- (the simulation's own shoulders, in the same frame)
	local s1, s2 = st.h[1], st.h[2]
	local function Sim(h)
		local dx, dy = h.sx - st.bx, h.sy - st.by
		local y = math.rad(r.eyeYaw)
		return string.format("(%5.1f %5.1f %5.1f)", dx * math.cos(y) + dy * math.sin(y), -dx * math.sin(y) + dy * math.cos(y), h.sz - st.bz)
	end
	Log("  eye %4.0f | drawn %6.1f (behind the eye by %5.1f) aim_yaw %5.2f | picture's eye %s eyes %s head %s | shoulders L %s R %s, the simulation's L %s R %s | arms short by %.1f %.1f",
		r.eyeYaw, r.renderYaw, math.AngleDifference(r.eyeYaw, r.renderYaw), r.aim or -1, P(r.view), P(r.eyes), P(r.head), P(r.ls), P(r.rs), Sim(s1), Sim(s2),
		r.short and r.short[1] or -1, r.short and r.short[2] or -1)
end

S.Add("fh_probe_turn", function()
	local host, p, st = HostAt(6)
	S.Client("fhmeasure", { on = true })
	S.Client("view", {})
	S.Client("zview", { on = true })
	Wait(2.0)
	-- first a few steps forward: the feet are under the eye then
	host:SetPos(p)
	host:SetEyeAngles(Angle(6, 0, 0))
	S.Client("fhinput", { moves = { { fwd = 10000, n = 30 } } })
	Wait(1.2)
	for _, yaw in ipairs({ 0, 20, 40, 60, 90, 60, 30, 0, -30, -60, 0 }) do TurnRow(host, yaw) end
	S.Client("fhinput", {})
	S.Client("fhmeasure", { on = false })
	S.Client("zview", { on = false })
	host:SetEyeAngles(Angle(6, 0, 0))
end)

------------------------------------------------------------------------------------------
-- fh_camera: the view while an arm is held (cl_camera.lua), through Z-City's own first-person
-- camera. A hand moved inside the zone leaves the view alone; a hand sent to the edge of the
-- picture is followed, smoothly, no further than it may, without going past what was asked;
-- let go, the view comes back; the eye itself (the aim, what the server hears) never moves by
-- it; and with nothing held the mouse turns the eye as it always did.
------------------------------------------------------------------------------------------
local function CamRun(moves, wait)
	S.Client("fhcam", { on = true })
	if moves then S.Client("fhinput", { moves = moves }) end
	Wait(wait)
	return Ask("fhcam", {}, "cam", 3) or {}
end
local function CamLog(what, r)
	Log("  %s: over %d frames (%.1f s) the view was turned %.1f right / %.1f left / %.1f up / %.1f down at the most; while held last %.2f right and %.2f up (asked: %.2f, %.2f; the hand %.0f right, %.0f up of the eye's line); at the end %.2f and %.2f; %.0f degrees a second at the fastest (%.2f in one frame); %.2f past what was asked; changed its direction %d times; the eye itself moved %.3f degrees",
		what, r.n or 0, r.secs or 0, r.yawMax or 0, -(r.yawMin or 0), r.pitchMax or 0, -(r.pitchMin or 0), r.heldYaw or 0, r.heldPitch or 0, r.heldWant or 0, r.heldWantP or 0, r.heldAz or 0, r.heldEl or 0,
		r.yaw or 0, r.pitch or 0, r.rate or 0, r.step or 0, r.over or 0, r.turns or 0, r.eyeMoved or 0)
end

local function CameraScene()
	local host, p, st = HostAt(6)
	S.Client("fhmeasure", { on = true })
	S.Client("view", {})
	S.Client("zview", { on = true })
	Wait(2.0)
	Check("the module holds the host's fists", st.active == true)
	-- (what the view may turn by with the setting at its default)
	local most = C.Cam.max * 0.4

	Log("-- a hand moved inside the zone")
	local r = CamRun({ { R = true, mx = 40, my = 0, n = 6 }, { R = true, mx = -40, my = -30, n = 8 }, { R = true, n = 200 } }, 1.0)
	CamLog("the right fist moved a hand's width about its guard", r)
	Check("a hand moved near the middle of the picture leaves the view alone", (r.n or 0) > 10 and math.max(r.yawMax, -r.yawMin, r.pitchMax, -r.pitchMin) < 0.3)
	Check("and the eye", (r.eyeMoved or 9) < 0.05)
	S.Client("fhinput", {})
	Wait(1.4)

	Log("-- a hand sent to the right edge of the picture, and held there")
	r = CamRun({ { R = true, mx = 120, my = 0, n = 14 }, { R = true, n = 300 } }, 1.6)
	CamLog("the right fist 50 degrees out to the right", r)
	S.Shot("fh_camera_right")
	Check("the view turns after it", (r.yaw or 0) > 3, string.format("%.1f degrees to the right", r.yaw or 0))
	Check("no further than it may", (r.yawMax or 99) <= most + 0.05)
	Check("as far as brings the hand back to the edge of the zone, or as far as it may", math.abs((r.yaw or 0) - (r.heldWant or 99)) < 0.5, string.format("turned %.1f, asked %.1f", r.yaw or 0, r.heldWant or 0))
	Check("smoothly", (r.rate or 999) < 120, string.format("%.0f degrees a second at the fastest", r.rate or 999))
	Check("without going past what was asked, and without swinging back", (r.over or 9) < 0.3 and (r.turns or 9) <= 1, string.format("%.2f degrees past, %d changes of direction", r.over or 9, r.turns or 9))
	Check("the eye itself has not moved", (r.eyeMoved or 9) < 0.05, string.format("%.3f degrees", r.eyeMoved or 9))

	Log("-- let go")
	r = CamRun({ { n = 2 } }, 1.8)
	CamLog("the fist let go", r)
	Check("the view comes back to the eye", math.abs(r.yaw or 9) < 0.5 and math.abs(r.pitch or 9) < 0.5, string.format("%.2f degrees left of it after %.1f s", r.yaw or 9, r.secs or 0))
	Check("smoothly, and not past it", (r.rate or 999) < 120 and (r.yawMin or -9) > -0.3)
	S.Client("fhinput", {})
	Wait(1.2)

	Log("-- a hand sent up")
	r = CamRun({ { R = true, mx = 0, my = -130, n = 14 }, { R = true, n = 300 } }, 1.4)
	CamLog("the right fist 55 degrees up", r)
	Check("the view tilts up after it", (r.pitch or 0) > 1.5 and (r.eyeMoved or 9) < 0.05, string.format("%.1f degrees up", r.pitch or 0))
	S.Client("fhinput", {})
	Wait(1.6)

	Log("-- to the left with the other arm")
	r = CamRun({ { L = true, mx = -120, my = 0, n = 14 }, { L = true, n = 300 } }, 1.4)
	CamLog("the left fist 50 degrees out to the left", r)
	Check("the view turns left after the left fist", (r.yaw or 0) < -3 and (r.over or 9) < 0.3, string.format("%.1f degrees", r.yaw or 0))
	S.Client("fhinput", {})
	Wait(1.6)

	Log("-- nothing held: the mouse is the eye's again")
	S.Client("fhcam", { on = true })
	host:SetEyeAngles(Angle(6, 35, 0))
	Wait(0.8)
	r = Ask("fhcam", {}, "cam", 3) or {}
	CamLog("the eye turned 35 degrees to the left with nothing held", r)
	Check("the view goes where the eye goes, and nothing is added to it", (r.eyeMoved or 0) > 30 and math.max(r.yawMax or 9, -(r.yawMin or -9)) < 0.3)
	host:SetEyeAngles(Angle(6, 0, 0))
	Wait(0.8)

	Log("-- the crowbar swung to the left with both buttons")
	local class = "weapon_hg_crowbar"
	if not host:HasWeapon(class) then host:Give(class) end
	host:SelectWeapon(class)
	Wait(2.2)
	r = CamRun({ { L = true, R = true, mx = -150, my = 0, n = 12 }, { L = true, R = true, n = 300 } }, 1.5)
	CamLog("the crowbar swung to the left as far as it goes", r)
	S.Shot("fh_camera_crowbar_left")
	-- (Until phase 42 the view went after the weapon's head, 22 degrees in every full swing.
	-- A weapon's head leaves the picture in a swing; the view does not go after it.)
	Check("a full swing of the crowbar takes the view with it by half of what a fist may, at the most", math.max(r.yawMax or 9, -(r.yawMin or -9), r.pitchMax or 9, -(r.pitchMin or -9)) <= most * C.Cam.toolShare + 0.1,
		string.format("%.2f degrees at the most (it may: %.2f)", math.max(r.yawMax or 9, -(r.yawMin or -9), r.pitchMax or 9, -(r.pitchMin or -9)), most * C.Cam.toolShare))
	Check("and the eye is still", (r.eyeMoved or 9) < 0.05, string.format("%.3f degrees", r.eyeMoved or 9))
	S.Client("fhinput", {})
	Wait(1.6)
	host:SelectWeapon("weapon_hands_sh")
	host:StripWeapon(class)
end

S.Add("fh_camera", function()
	local ok, err = pcall(CameraScene)
	S.Client("fhinput", {})
	S.Client("fhmeasure", { on = false })
	S.Client("zview", { on = false })
	if not ok then Log("  the scene failed: %s", tostring(err)) Check("the scene ran through", false) end
	Tally("fh_camera")
end)

------------------------------------------------------------------------------------------
-- fh_traj: does the striking place go where the mouse goes? A bot with fists, then a crowbar,
-- then an axe; the leading arm alone, the other alone, both. The mouse is moved right, left,
-- up, down and along the four diagonals from the guard, and the way the striking place then
-- goes, seen from the bot's own eye, is compared with the mouse's. Then an axe raised and
-- brought down, and a swing turned round in its middle.
------------------------------------------------------------------------------------------
local function StrikeAt(st, hand)
	local prof = st.prof
	if prof.kind == "tool" and st.w then
		local b = st.w
		local us = prof.usamples[#prof.usamples - (prof.edge and 1 or 0)]
		local x, y, z = FH.Weapon.Point(prof, b, us.at, us.off)
		return b.x + x - st.bx, b.y + y - st.by, b.z + z - st.bz
	end
	local h = st.h[hand]
	return (h.kx or h.px) - st.bx, (h.ky or h.py) - st.by, (h.kz or h.pz) - st.bz
end

local function TrajFor(class, label)
	local p = S.FindSpot({ open = 170, outdoor = true })
	local bot = T.Fighter(p, 0, class)
	if not IsValid(bot) then Log("no bot") return end
	local st = FH.State(bot)
	S.View(p + Vector(60, -70, 70), p + Vector(8, 0, 52))
	Wait(1.0)
	local function Home()
		FH.TestInput[bot] = function() return nil end
		Wait(1.3)
	end
	local modes = { { "the leading arm", false, true, 2 }, { "the other arm", true, false, 1 }, { "both", true, true, 2 } }
	local dirs = { { "right", 1, 0 }, { "up-right", 1, 1 }, { "up", 0, 1 }, { "up-left", -1, 1 }, { "left", -1, 0 }, { "down-left", -1, -1 }, { "down", 0, -1 }, { "down-right", 1, -1 } }
	for _, m in ipairs(modes) do
		local cells, worst, least = {}, 0, 99
		for _, d in ipairs(dirs) do
			Home()
			local x0, y0, z0 = StrikeAt(st, m[4])
			local l = sqrt(d[2] * d[2] + d[3] * d[3])
			local far, by, bz = 0, 0, 0
			FH.OnCmd = function(ply, cmd, inp, s)
				if ply ~= bot then return end
				local x, y, z = StrikeAt(s, m[4])
				-- (the bot looks along +x: to its right is -y)
				local r, u = -(y - y0), z - z0
				if r * r + u * u > far then far, by, bz = r * r + u * u, r, u end
			end
			T.WaitFor(T.Play(bot, { { L = m[2], R = m[3], mx = math.Round(d[2] / l * 100), my = math.Round(-d[3] / l * 100), n = 10 }, { L = m[2], R = m[3], n = 8 } }, true), 2)
			FH.OnCmd = nil
			local off = math.deg(math.atan2(bz, by)) - math.deg(math.atan2(d[3], d[2]))
			off = (off + 180) % 360 - 180
			worst, least = math.max(worst, abs(off)), math.min(least, sqrt(far))
			cells[#cells + 1] = string.format("%s %+.0f (%.0f)", d[1], off, sqrt(far))
		end
		Log("  %s, %s: degrees off the mouse's way (and units gone) %s", label, m[1], table.concat(cells, "; "))
		Check(string.format("%s, %s: the striking place goes the mouse's way", label, m[1]), worst < 45 and least > 2.5, string.format("%.0f degrees off at the worst, %.1f units at the least", worst, least))
	end
	Home()
	return bot, st
end

S.Add("fh_traj", function()
	Log("-- fists")
	TrajFor("weapon_hands_sh", "fists")
	Log("-- the crowbar")
	TrajFor("weapon_hg_crowbar", "the crowbar")
	Log("-- the woodcutting axe")
	local bot, st = TrajFor("weapon_hg_axe", "the axe")
	if IsValid(bot) then
		Log("-- the axe raised and brought down (both buttons): up for 10 ticks of 150 counts, held, down for 10 of 300")
		local x0, y0, z0 = StrikeAt(st, 2)
		T.WaitFor(T.Play(bot, { { L = true, R = true, mx = 0, my = -150, n = 10 }, { L = true, R = true, n = 10 } }, true), 2)
		local x1, y1, z1 = StrikeAt(st, 2)
		local best, bv, lx, ly, lz, jump = 0, Vector(0, 0, 0), nil, nil, nil, 0
		local tick = engine.TickInterval()
		FH.OnCmd = function(ply, cmd, inp, s)
			if ply ~= bot then return end
			local x, y, z = StrikeAt(s, 2)
			if lx then
				local v = Vector(x - lx, y - ly, z - lz) / tick * FH.U2M
				jump = math.max(jump, v:Length() * tick * FH.M2U)
				if v:Length() > best then best, bv = v:Length(), v end
			end
			lx, ly, lz = x, y, z
		end
		T.WaitFor(T.Play(bot, { { L = true, R = true, mx = 0, my = 300, n = 10 }, { L = true, R = true, n = 10 } }, true), 2)
		FH.OnCmd = nil
		local x2, y2, z2 = StrikeAt(st, 2)
		Log("  raised by %.1f units; brought down by %.1f; fastest %.1f m/s, going (forward %.1f, left %.1f, up %.1f); %.1f units in a tick at the most",
			z1 - z0, z1 - z2, best, bv.x, bv.y, bv.z, jump)
		Check("moving the mouse up raises the axe", z1 - z0 > 5, string.format("%.1f units", z1 - z0))
		Check("moving it down then brings the head down in a swing", z1 - z2 > 15 and best > 4 and bv.z < -0.5 * best, string.format("%.1f units down, %.1f m/s, %.0f %% of it downward", z1 - z2, best, -bv.z / math.max(best, 0.01) * 100))
		Check("faster than the hands that bring it down", best > 4)
		FH.TestInput[bot] = function() return nil end
		Wait(1.4)

		Log("-- a swing turned round in its middle (both buttons): left for 8 ticks of 300 counts, then right")
		lx = nil
		local peakL, stillLeft, t, turnedAt, worstJump, lastV, kick = 0, 0, 0, nil, 0, nil, 0
		local phase = 1
		FH.OnCmd = function(ply, cmd, inp, s)
			if ply ~= bot then return end
			local x, y, z = StrikeAt(s, 2)
			if lx then
				local v = Vector(x - lx, y - ly, z - lz) / tick * FH.U2M
				worstJump = math.max(worstJump, v:Length() * tick * FH.M2U)
				if lastV then kick = math.max(kick, (v - lastV):Length()) end
				lastV = v
				if phase == 1 then peakL = math.max(peakL, v.y) else
					t = t + tick
					if not turnedAt and v.y < 0 then turnedAt = t end
				end
			end
			lx, ly, lz = x, y, z
		end
		T.WaitFor(T.Play(bot, { { L = true, R = true, mx = -300, my = 0, n = 8 } }, true), 2)
		phase = 2
		T.WaitFor(T.Play(bot, { { L = true, R = true, mx = 300, my = 0, n = 8 }, { L = true, R = true, n = 20 } }, true), 2)
		FH.OnCmd = nil
		Log("  going left at %.1f m/s; still going left %s ms after the mouse turned; its speed changed by %.1f m/s in a tick at the most; %.1f units in a tick at the most",
			peakL, turnedAt and string.format("%.0f", turnedAt * 1000) or "more than 400", kick, worstJump)
		-- (with the arms at their full force in free air, phase 41, the head of an axe in two hands turns round within a tick or two)
		Check("the head goes on a moment after the mouse has turned", turnedAt ~= nil and turnedAt >= tick * 0.9, turnedAt and string.format("%.0f ms", turnedAt * 1000) or "it never turned")
		Check("and is not thrown to the other side", worstJump < 12 and kick < 8, string.format("%.1f units and %.1f m/s in a tick at the most", worstJump, kick))
	end
	FH.OnCmd = nil
	Tally("fh_traj")
end)

------------------------------------------------------------------------------------------
-- fh_motion: the host's own arms while they move, as they are drawn, frame by frame. What the
-- scenes before this one looked at was arms at rest after a movement, or the server's numbers.
-- This one looks at the drawn chain in a steady sweep: does the elbow go with the hand, does
-- the shoulder, how evenly does the drawn hand go from frame to frame (three ways of drawing
-- between two ticks, side by side), is a held handle in the palm while it moves, does the hand
-- that supports a weapon move with it.
------------------------------------------------------------------------------------------
local function MotionRun(moves, wait)
	S.Client("fhmotion", { on = true })
	S.Client("fhinput", { moves = moves })
	Wait(wait)
	local r = Ask("fhmotion", { get = true }, "motion", 3) or {}
	S.Client("fhinput", {})
	return r
end
local function ArmLine(r, i)
	local a = r.arm and r.arm[i] or {}
	return string.format("the hand bone went %.1f units, the elbow %.1f, the upper arm's joint %.1f; the drawn hand at %.0f units/s, uneven by %.0f %% from frame to frame; the bone %.2f units from the simulated hand at the most",
		a.hand or 0, a.elbow or 0, a.joint or 0, a.speed or 0, (a.spread or 0) * 100, a.off or 0)
end

local function MotionScene()
	local host, p, st = HostAt(6)
	Log("  (%s)", T.HostPlace(host, p))
	S.Client("fhmeasure", { on = true })
	S.Client("view", {})
	S.Client("zview", { on = true })
	Wait(2.0)
	Check("the module holds the host's fists", st.active == true)

	Log("-- the right fist swept out and up, steadily (70 ticks of 18 counts across, 8 up): three ways of drawing between two ticks")
	local names = { [0] = "by the wall clock since the last step (as it was)", [1] = "by the game's own clock", [2] = "the last tick as it is" }
	local res = {}
	for _, mode in ipairs({ 0, 1, 2 }) do
		S.Client("fhmotion", { interp = mode })
		Wait(1.4)
		local r = MotionRun({ { R = true, mx = 18, my = -8, n = 70 }, { R = true, n = 6 } }, 1.2)
		res[mode] = r
		Log("  %s: %d frames at %.0f a second (between the ticks: %.2f to %.2f; the clock %.2f to %.2f) | right arm: %s", names[mode], r.n or 0, r.fps or 0, r.kMin or 0, r.kMax or 0, r.rawMin or 0, r.rawMax or 0, ArmLine(r, 2))
		Wait(1.2)
	end
	S.Client("fhmotion", { interp = 1 })
	local a0, a1 = res[0].arm and res[0].arm[2] or {}, res[1].arm and res[1].arm[2] or {}
	Check("drawn by the game's own clock the hand goes no less evenly than it did", (a1.spread or 9) <= (a0.spread or 0) + 0.03, string.format("uneven by %.0f %% now, %.0f %% as it was", (a1.spread or 0) * 100, (a0.spread or 0) * 100))
	Check("the hand bone is on the simulated hand while it moves", (a1.off or 9) < 0.6, string.format("%.2f units at the most", a1.off or 9))
	Check("the elbow goes with the hand", (a1.elbow or 0) > (a1.hand or 99) * 0.3, string.format("%.1f units for the hand's %.1f", a1.elbow or 0, a1.hand or 0))
	Wait(1.2)

	Log("-- the right fist raised high")
	local r = MotionRun({ { R = true, mx = 0, my = -30, n = 50 }, { R = true, n = 20 } }, 1.2)
	Log("  right arm: %s", ArmLine(r, 2))
	Check("the shoulder goes up with a raised arm", (r.arm and r.arm[2] and r.arm[2].joint or 0) > 1.0, string.format("the upper arm's joint went %.1f units", r.arm and r.arm[2] and r.arm[2].joint or 0))
	S.Shot("fh_motion_raised")
	Wait(1.4)

	Log("-- the crowbar swept to the left with both buttons, then raised")
	local class = "weapon_hg_crowbar"
	if not host:HasWeapon(class) then host:Give(class) end
	host:SelectWeapon(class)
	Wait(2.2)
	r = MotionRun({ { L = true, R = true, mx = -14, my = 0, n = 60 }, { L = true, R = true, n = 6 } }, 1.1)
	Log("  right arm: %s; the handle %.2f units from its palm at the most", ArmLine(r, 2), r.arm and r.arm[2] and r.arm[2].gap or -1)
	Log("  left arm:  %s; the handle %.2f units from its palm at the most", ArmLine(r, 1), r.arm and r.arm[1] and r.arm[1].gap or -1)
	local ar, al = r.arm and r.arm[2] or {}, r.arm and r.arm[1] or {}
	Check("the handle stays in both palms while the weapon moves", (ar.gap or 9) < 1.5 and (al.gap or 9) < 1.5, string.format("%.2f and %.2f units at the most", ar.gap or 9, al.gap or 9))
	Check("the hand that supports the weapon moves with it", (al.hand or 0) > 2 and (al.elbow or 0) > 0.5, string.format("the left hand went %.1f units, its elbow %.1f", al.hand or 0, al.elbow or 0))
	Check("both elbows go with their hands", (ar.elbow or 0) > (ar.hand or 99) * 0.25 and (al.elbow or 0) > (al.hand or 99) * 0.2)
	S.Shot("fh_motion_crowbar_left")
	Wait(1.4)
	r = MotionRun({ { L = true, R = true, mx = 0, my = -22, n = 50 }, { L = true, R = true, n = 20 } }, 1.2)
	Log("  raised: right arm: %s", ArmLine(r, 2))
	Log("  raised: left arm:  %s", ArmLine(r, 1))
	S.Shot("fh_motion_crowbar_raised")
	Check("raised, the handle is still in both palms", ((r.arm and r.arm[2] and r.arm[2].gap) or 9) < 1.5 and ((r.arm and r.arm[1] and r.arm[1].gap) or 9) < 1.5)
	Wait(1.2)
	host:SelectWeapon("weapon_hands_sh")
	host:StripWeapon(class)
end

S.Add("fh_motion", function()
	local ok, err = pcall(MotionScene)
	S.Client("fhinput", {})
	S.Client("fhmotion", { interp = 1 })
	S.Client("fhmeasure", { on = false })
	S.Client("zview", { on = false })
	if not ok then Log("  the scene failed: %s", tostring(err)) Check("the scene ran through", false) end
	Tally("fh_motion")
end)

------------------------------------------------------------------------------------------
-- fh_look: looking and swinging are two things. The mouse's movement is sent the game's own
-- way here (through Z-City's hook on InputMouseApply and everything it hands the movement to),
-- not written into the command as in every other scene. With no arm held it turns the eye and
-- the weapon stays in its guard; with an arm held it moves that arm and neither the eye nor
-- the picture goes with it; let go while the mouse still moves, the eye takes over without a
-- jump. The same swing with the mouse taken the way it was until phase 42 is logged beside it.
-- Then the panel, the printed help and the hint.
------------------------------------------------------------------------------------------
local function LookScene()
	local host, p, st = HostAt(6)
	Log("  (%s)", T.HostPlace(host, p))
	S.Client("fhmeasure", { on = true })
	S.Client("view", {})
	S.Client("zview", { on = true })
	local class = "weapon_hg_crowbar"
	if not host:HasWeapon(class) then host:Give(class) end
	host:SelectWeapon(class)
	Wait(2.4)
	Check("the module holds the host's crowbar", st.active == true and st.w ~= nil)
	local AD = math.AngleDifference
	-- one stretch: the server's side of it (the eye in the commands, the hands from their guard)
	local function Stretch(name, moves, wait)
		local rec = {}
		S.Client("fhlook", { seg = name })
		FH.OnCmd = function(ply, cmd, inp, s)
			if ply ~= host then return end
			local _, hl = B.ToAim(s, s.h[2].px, s.h[2].py, s.h[2].pz)
			local _, ll = B.ToAim(s, s.h[1].px, s.h[1].py, s.h[1].pz)
			rec[#rec + 1] = { yaw = inp.yaw, pitch = inp.pitch, r = s.h[2].on, l = s.h[1].on, dr = FromGuard(s, 2), dl = FromGuard(s, 1), hl = hl, ll = ll }
		end
		S.Client("fhinput", { moves = moves })
		Wait(wait)
		FH.OnCmd = nil
		S.Client("fhinput", {})
		-- (what comes now, the view put back for the next stretch, is no part of this one)
		S.Client("fhlook", { seg = "between" })
		local o = { n = #rec, turn = 0, turnHeld = 0, far = 0, farHeld = 0, went = 0, wentL = 0, after = 0, moved = 0 }
		local y0, yRel
		for i, e in ipairs(rec) do
			y0 = y0 or e.yaw
			local held = e.r or e.l
			if held then
				o.heldFrom = o.heldFrom or e.yaw
				o.turnHeld = math.max(o.turnHeld, math.abs(AD(e.yaw, o.heldFrom)))
				o.hl0, o.ll0 = o.hl0 or e.hl, o.ll0 or e.ll
				o.went, o.wentL = e.hl - o.hl0, e.ll - o.ll0
				o.moved = math.max(o.moved, math.abs(o.went), math.abs(o.wentL))
				yRel = e.yaw
			elseif yRel then
				o.after = AD(e.yaw, yRel)
			else
				o.far = math.max(o.far, e.dr, e.dl)
			end
			o.turn = AD(e.yaw, y0)
		end
		return o
	end
	local function Rest()
		host:SetEyeAngles(Angle(6, 0, 0))
		Wait(1.8)
	end

	Log("-- LOOK: no arm held, the mouse moved 100 counts a command to the right for 20 commands")
	local a = Stretch("look", { { real = { 100, 0 }, n = 20 }, { n = 30 } }, 1.1)
	Rest()
	Log("-- SWING: the right arm held, the mouse moved 100 counts a command to the left for 30 commands")
	local b = Stretch("swing", { { R = true, n = 4 }, { R = true, real = { -100, 0 }, n = 30 }, { R = true, n = 20 } }, 1.2)
	Rest()
	Log("-- the same with the left arm, and with both")
	local c = Stretch("left", { { L = true, n = 4 }, { L = true, real = { 100, 0 }, n = 30 }, { L = true, n = 20 } }, 1.2)
	Rest()
	local d = Stretch("both", { { L = true, R = true, n = 4 }, { L = true, R = true, real = { -100, -40 }, n = 30 }, { L = true, R = true, n = 20 } }, 1.2)
	Rest()
	Log("-- let go while the mouse still moves to the left")
	local e = Stretch("release", { { R = true, n = 4 }, { R = true, real = { -100, 0 }, n = 20 }, { real = { -100, 0 }, n = 20 }, { n = 30 } }, 1.5)
	Rest()
	Log("-- the swing again with the mouse taken the way it was until phase 42")
	S.Client("fhlook", { nowrap = true })
	local g = Stretch("as it was", { { R = true, n = 4 }, { R = true, real = { -100, 0 }, n = 30 }, { R = true, n = 20 } }, 1.2)
	local v = Ask("fhlook", { get = true }, "look", 3) or {}
	Rest()
	local function Pic(name)
		local s = v[name] or {}
		return string.format("the picture over %d frames: turned %.2f left / %.2f right at the most, tilted %.2f up / %.2f down, rolled %.2f / %.2f; its largest steps in one frame %.2f left, %.2f right",
			s.n or 0, s.vyMax or 0, -(s.vyMin or 0), -(s.vpMin or 0), s.vpMax or 0, s.vrMax or 0, -(s.vrMin or 0), s.stepMax or 0, -(s.stepMin or 0)), s
	end
	local text, s = Pic("look")
	Log("  look: the eye turned %.1f degrees (%d commands); the hands were %.2f units from their guard at the most; %s", a.turn, a.n, a.far, text)
	Check("with no arm held the mouse turns the eye", a.turn < -25, string.format("%.1f degrees to the right", -a.turn))
	Check("and the weapon stays in its guard while the view turns", a.far < 1.5, string.format("%.2f units at the most", a.far))
	text, s = Pic("swing")
	Log("  swing, right arm: the eye turned %.3f degrees at the most while the arm was held; the right hand went %.1f units to the left; %s", b.turnHeld, b.went, text)
	Check("with the right arm held the mouse moves the arm", b.went > 4, string.format("%.1f units to the left", b.went))
	Check("and not the eye", b.turnHeld < 0.15, string.format("%.3f degrees", b.turnHeld))
	local wob = math.max(s.vyMax or 9, -(s.vyMin or -9), s.vpMax or 9, -(s.vpMin or -9), s.vrMax or 9, -(s.vrMin or -9))
	Check("nor the picture, beyond what the view may follow a hand by", wob <= C.Cam.max * 0.4 + 0.6, string.format("%.2f degrees at the most, in any direction", wob))
	text, s = Pic("left")
	Log("  swing, left arm: the eye turned %.3f degrees at the most; the left hand went %.1f units to the right and the right %.1f (the arm at the butt turns the weapon about the other hand); %s", c.turnHeld, -c.wentL, -c.went, text)
	Check("with the left arm held the mouse moves the weapon and not the eye", c.moved > 3 and c.turnHeld < 0.15, string.format("a hand went %.1f units, the eye %.3f degrees", c.moved, c.turnHeld))
	text, s = Pic("both")
	Log("  swing, both arms: the eye turned %.3f degrees at the most; the right hand went %.1f units to the left, the left %.1f; %s", d.turnHeld, d.went, d.wentL, text)
	Check("with both held the weapon goes, and not the eye", d.moved > 4 and d.turnHeld < 0.15, string.format("a hand went %.1f units, the eye %.3f degrees", d.moved, d.turnHeld))
	text, s = Pic("release")
	Log("  let go: the eye turned %.3f degrees while held and %.1f after; %s", e.turnHeld, e.after, text)
	Check("let go, the mouse is the eye's again", e.turnHeld < 0.15 and e.after > 25, string.format("%.1f degrees to the left after the release", e.after))
	Check("and the picture does not jump back", (s.stepMin or -99) > -1.5, string.format("%.2f degrees against the turn in one frame at the most", -(s.stepMin or -99)))
	text, s = Pic("as it was")
	Log("  as it was until phase 42: the eye turned %.3f degrees at the most while the arm was held; %s", g.turnHeld, text)

	Log("-- the panel, the printed help, the hint")
	S.Client("fhmenu", { open = true })
	Wait(0.8)
	local m = Ask("fhmenu", {}, "menu", 3) or {}
	S.Client("fhmenu", { shot = "fh_look_menu" })
	Wait(0.5)
	S.Client("fhmenu", { close = true })
	Check("fh_menu opens a panel", (m.panels or 0) >= 1, string.format("%d panel(s)", m.panels or 0))
	Log("  the keys as the player is told them: right arm on %s, left arm on %s", tostring(m.right), tostring(m.left))
	S.Client("fhmenu", { hint = true })
	Wait(1.2)
	local m2 = Ask("fhmenu", {}, "menu", 3) or {}
	S.Shot("fh_look_hint")
	S.Client("fhmenu", { hint = false })
	Check("the hint is shown when a weapon of the module is in hand", (m2.hints or 0) > (m.hints or 0))
	host:SelectWeapon("weapon_hands_sh")
	host:StripWeapon(class)
end

S.Add("fh_look", function()
	local ok, err = pcall(LookScene)
	FH.OnCmd = nil
	S.Client("fhinput", {})
	S.Client("fhlook", { nowrap = false })
	S.Client("fhmenu", { hint = false })
	S.Client("fhmeasure", { on = false })
	S.Client("zview", { on = false })
	if not ok then Log("  the scene failed: %s", tostring(err)) Check("the scene ran through", false) end
	Tally("fh_look")
end)
